//
//  AppDetails.swift
//  PaytronixApps
//
//  Created by mac on 11/12/17.
//  Copyright © 2017 Paytronix Systems Inc. All rights reserved.
//

import UIKit
import StoreKit
import UserNotifications
import Gifu

let k_WelcomeUsername = "WelcomeUsername"
let k_OloUserAuthToken = "OloUserAuthToken"
let k_pxsCheckinDate = "PXSCheckinDate"
let k_pxsCheckinStatus = "PXSCheckinStatus"
let k_pxsCheckinCode = "PXSCheckinCode"
let kPXShortCardNumberExpired = "kPXShortCardNumberExpired"
let kCurrentAccountWasChangedNotification = "kCurrentAccountWasChangedNotification"
let kOloStoryBoardName = "NativeOlo"
let k_MMRecentOrders = "MMRecentOrders"
let k_OlOReorderPopupRemainder = "OlOReorderPopupRemainder"
let k_rewardsCount = "rewardsCount"
let APPSHARE = UIApplication.shared.delegate as! PaytronixAppDelegate
var notificationCount = UILabel()
let isiPhoneXSeries:Bool = (UIDevice().userInterfaceIdiom == .phone && UIScreen.main.bounds.size.height >= 812)
class AppDetails: NSObject {
    //MARK:- Variable
    //SharedInstance
    @objc static let shared:AppDetails = AppDetails()
    //Cart Details
    var isCartStatus:Bool = false
    var cartFoodID:[String] = []
    var storeID:String = ""
    //Filter
    var oloFilter:OloViewFilter?
    //Coupon
    var oloCoupon:OLOAddorDeleteCouponUIView?
    var oloCouponDelete: OLODeleteCouponView?
    var oloAlertMessage: OloFavoritePopUp?
    //UserInformation
    @objc var userInformation:PXUserInformation?
    //Facebook
    @objc var faceBookDetails:[String:Any] = [:]
    //WelcomeUsername
    @objc var welcomeUsername:String = ""
    //Location Page
    @objc var locationPageTitle:String = ""
    //ModelBasketScreen
    var basketModel:ModelBasketScreen = ModelBasketScreen()
    var oloUserAuthToken:String = ""
    var oloUserAuthTokenList:[String:String] = [:]
    var appCurrency:String = "$"
    //Fav
    var arrayOloStoreList:[[String:Any]] = []
    //Loader
    var viewLoader:UIView?
    var gitViewLoader:GIFImageView?
    var oloReorder:OLOReorderPopUp?
    var arrayOloFavouriteStoreList:[ModelFavelocation] = []
    //MM
    var modelOlOStoreList:[Restaurant] = []
    var modelMMStoreList:[Restaurant] = []
    var isGetOlOAllStore:Bool = false
    var modelMultipleProvidersStore:[ModelOrderServices] = []
    var localMenuList:(storeCode:String?,menuListOlO:ModelMenu?,menuListMM:[Int:ModelMenu]?) = ("",nil,[:])
    var postalCode: String = ""
    //ReOrder popup
    var oloRecentOrderList:[ModelOrderstatus] = []
    var isCallRecentOrderApiToLocalOnce:Bool = true
    //DeliveryAddress
    var pxsStoreGroupStoresList:[PXStoreInformation] = []
    //MARK:- Init
    override init() {
        super.init()
        //Username
        if let userName = UserDefaults.standard.object(forKey: k_WelcomeUsername) as? String, userName.count > 0 {
            self.welcomeUsername = userName
        }else {
            self.welcomeUsername = "USER"
        }
        //AuthToken
        if let authTokenList = UserDefaults.standard.object(forKey: k_OloUserAuthToken) as? [String:String], authTokenList.count > 0, APPSHARE.currentAccount != nil {
            oloUserAuthTokenList = authTokenList
            _ = self.oloSwitchUser(currentAccount: APPSHARE.currentAccount)
        }else {
            oloUserAuthTokenList = [:]
            oloUserAuthToken = ""
        }
    }
    //MARK:- Cart Details
    @objc func setCartDetails(foodID:String, storeID:String) {
        self.storeID = storeID
        self.isCartStatus = true
        self.cartFoodID = []
        self.cartFoodID = [foodID]
    }
    @objc func deleteCartDetails() {
        self.storeID = ""
        self.isCartStatus = false
        self.cartFoodID = []
    }
    @objc func checkSameStoreAndRemove(storeID:String) -> Bool {
        if self.storeID != storeID {
            self.deleteCartDetails()
            return false
        }else {
            return true
        }
    }
    //MARK:- Filter
    @objc func showFilterPopUp(currentRange:Double, handler:((Float) -> Void)?) {
        if oloFilter == nil {
            oloFilter = OloViewFilter.loadNib()
            oloFilter?.isHidden = true
            APPSHARE.window.addSubview(oloFilter!)
            oloFilter?.translatesAutoresizingMaskIntoConstraints = false
            APPSHARE.window.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[oloFilter]-0-|", options: [], metrics: [:], views: ["oloFilter" : oloFilter!]))
            APPSHARE.window.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[oloFilter]-0-|", options: [], metrics: [:], views: ["oloFilter" : oloFilter!]))
            APPSHARE.window.bringSubviewToFront(oloFilter!)
            oloFilter?.showFilterPopView(currentRange: currentRange, handler: handler)
        }else {
            APPSHARE.window.bringSubviewToFront(oloFilter!)
            oloFilter?.showFilterPopView(currentRange: currentRange, handler: handler)
        }
    }
    //MARK:- Coupon
    @objc func showCouponPopUp(handler:((String) -> Void)?) {
        if oloCoupon == nil {
            oloCoupon = OLOAddorDeleteCouponUIView.loadNib()
            oloCoupon?.isHidden = true
            APPSHARE.window.addSubview(oloCoupon!)
            oloCoupon?.translatesAutoresizingMaskIntoConstraints = false
            APPSHARE.window.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[oloCoupon]-0-|", options: [], metrics: [:], views: ["oloCoupon" : oloCoupon!]))
            APPSHARE.window.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[oloCoupon]-0-|", options: [], metrics: [:], views: ["oloCoupon" : oloCoupon!]))
            oloCoupon?.showCouponPopView(handler: handler)
        }else {
            oloCoupon?.showCouponPopView(handler: handler)
        }
    }
    @objc func showCouponPopUpDelete(handler:((Float) -> Void)?) {
        if oloCouponDelete == nil {
            oloCouponDelete = OLODeleteCouponView.loadNib()
            oloCoupon?.isHidden = true
            APPSHARE.window.addSubview(oloCouponDelete!)
            oloCouponDelete?.translatesAutoresizingMaskIntoConstraints = false
            APPSHARE.window.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[oloCoupon]-0-|", options: [], metrics: [:], views: ["oloCoupon" : oloCouponDelete!]))
            APPSHARE.window.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[oloCoupon]-0-|", options: [], metrics: [:], views: ["oloCoupon" : oloCouponDelete!]))
            APPSHARE.window.bringSubviewToFront(oloCouponDelete!)
            oloCouponDelete?.showCouponPopDeleteView()
        }else {
            APPSHARE.window.bringSubviewToFront(oloCouponDelete!)
            oloCouponDelete?.showCouponPopDeleteView()
        }
    }
    //Favourite
    @objc func showFavouriteSavePopUp(handler:((String) -> Void)?) {
        if oloCoupon == nil {
            oloCoupon = OLOAddorDeleteCouponUIView.loadNib()
            oloCoupon?.isHidden = true
            APPSHARE.window.addSubview(oloCoupon!)
            oloCoupon?.translatesAutoresizingMaskIntoConstraints = false
            APPSHARE.window.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[oloCoupon]-0-|", options: [], metrics: [:], views: ["oloCoupon" : oloCoupon!]))
            APPSHARE.window.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[oloCoupon]-0-|", options: [], metrics: [:], views: ["oloCoupon" : oloCoupon!]))
            oloCoupon?.showFavouriteSavePopView(handler: handler)
        }else {
            oloCoupon?.showFavouriteSavePopView(handler: handler)
        }
    }
    @objc func showAlertMessageOlo(message:String, handler:(() -> Void)?) {
        if oloAlertMessage == nil {
            oloAlertMessage = OloFavoritePopUp.loadNib()
            oloAlertMessage?.isHidden = true
            APPSHARE.window.addSubview(oloAlertMessage!)
            oloAlertMessage?.translatesAutoresizingMaskIntoConstraints = false
            APPSHARE.window.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[oloAlertMessage]-0-|", options: [], metrics: [:], views: ["oloAlertMessage" : oloAlertMessage!]))
            APPSHARE.window.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[oloAlertMessage]-0-|", options: [], metrics: [:], views: ["oloAlertMessage" : oloAlertMessage!]))
            APPSHARE.window.bringSubviewToFront(oloAlertMessage!)
            oloAlertMessage?.showPopup(message: message, handler: handler)
        }else {
            APPSHARE.window.bringSubviewToFront(oloAlertMessage!)
            oloAlertMessage?.showPopup(message: message, handler: handler)
        }
    }
    //MARK: WelcomeUsername
    @objc func welcomeUserName(userName:String) {
        var newUserName = "USER"
        if userName.count > 0 {
            newUserName = userName.uppercased()
        }
        self.welcomeUsername = newUserName
        UserDefaults.standard.set(newUserName, forKey: k_WelcomeUsername)
        UserDefaults.standard.synchronize()
    }
    @objc func logoutFromAccount(_ removeBasket:Bool = false) {
        AppDetails.shared.userInformation = nil
        AppDetails.shared.welcomeUserName(userName: "")
        oloUserAuthToken = ""
        oloUserAuthTokenList = [:]
        if removeBasket {
            self.basketModel = ModelBasketScreen.init(0, basketID: "")
        }
        UserDefaults.standard.set([:], forKey: k_OloUserAuthToken)
        UserDefaults.standard.synchronize()
        AppDetails.shared.isCallRecentOrderApiToLocalOnce = true
        AppDetails.shared.oloRecentOrderList = []
        oloReorder = nil
        //Kochava
        if (AppSettings.shared()?.isKochavaTrackerEnabled() ?? false) {
            //Kochava: Set Indentity link when log out
            KochavaTrackerHelper.shared.kochavaSetIdentityLink()
            //Kochava: Remove Registered device Token Data
            if !(AppSettings.shared()?.isKochavaTrackerPushNotificationEnableForGuest() ?? false) {
                KochavaTrackerHelper.shared.kochavaRemoveRemoteNotificationsDeviceToken()
            }
        }
    }
    //MARK: Olo Auth Token
    @objc func oloAuthToken(authToken:String, printedCardNumber:String, isDefault:Bool) {
        if authToken.count > 0 {
            oloUserAuthTokenList[printedCardNumber] = authToken
            oloUserAuthToken = authToken
            if isDefault {
                self.basketModel = ModelBasketScreen.init(0, basketID: "")
                AppDetails.shared.isCallRecentOrderApiToLocalOnce = true
            }
        }
        UserDefaults.standard.set(oloUserAuthTokenList, forKey: k_OloUserAuthToken)
        UserDefaults.standard.synchronize()
    }
    @objc func oloSwitchUser(currentAccount:PXStoredAccount) -> Bool {
        if oloUserAuthTokenList.count > 0, let authToken = oloUserAuthTokenList[currentAccount.printedCardNumber] {
            if currentAccount != APPSHARE.currentAccount {
                APPSHARE.currentAccount = currentAccount
                self.basketModel = ModelBasketScreen.init(0, basketID: "")
                AppDetails.shared.isCallRecentOrderApiToLocalOnce = true
            }
            oloUserAuthToken = authToken
            return true
        }
        return false
    }
    //MARK: Reorder Popup
    func showReorderPopUp(orderStatus:ModelOrderstatus, delegate:UIViewController) {
        if AppDetails.shared.oloRecentOrderList.count > 0 && PaytronixAppDelegate.api().storedAccounts.count > 0 && orderStatus.products.count > 0 {
            if oloReorder == nil {
                oloReorder = OLOReorderPopUp.loadNib()
                oloReorder?.isHidden = true
                APPSHARE.window.addSubview(oloReorder!)
                oloReorder?.translatesAutoresizingMaskIntoConstraints = false
                oloReorder?.window?.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[oloReorder]-0-|", options: [], metrics: [:], views: ["oloReorder" : oloReorder!]))
                oloReorder?.window?.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[oloReorder]-0-|", options: [], metrics: [:], views: ["oloReorder" : oloReorder!]))
                APPSHARE.window?.bringSubviewToFront(oloReorder!)
                oloReorder?.showReorderPopView(orderStatus: orderStatus, delegate: delegate)
            }else {
                APPSHARE.window?.bringSubviewToFront(oloReorder!)
                oloReorder?.showReorderPopView(orderStatus: orderStatus, delegate: delegate)
            }
        }
    }
    //Set Re-Order popup
    func setOlOReorderPopupRemainder(orderStatus:ModelOrderstatus, remainder:[ModelNextReminder]){
        var modelReorderList = getOlOReorderPopupRemainder()
        if let index = modelReorderList?.lastIndex(where: {$0.printedCardNumber == PaytronixAppDelegate.currentAccount()?.printedCardNumber}) {
            modelReorderList?.remove(at: index)
        }
        modelReorderList?.append(ModelReorderDetails.init(orderID: orderStatus.oloid, reminder: remainder, printedCardNumber: (PaytronixAppDelegate.currentAccount()?.printedCardNumber)!))
        if OloValues.reorderReminderDaysIntervalList().count > 0 {
            do {
                let encodedData = try JSONEncoder().encode(modelReorderList)
                UserDefaults.standard.set(encodedData, forKey: k_OlOReorderPopupRemainder)
                UserDefaults.standard.synchronize()
            }catch {
            }
        }
    }
    //Get Re-Order List
    func getOlOReorderPopupRemainder() -> [ModelReorderDetails]? {
        if let jsonData = UserDefaults.standard.object(forKey: k_OlOReorderPopupRemainder) as? Data {
            do {
                let decoder = try JSONDecoder().decode([ModelReorderDetails].self, from: jsonData)
                return decoder
            }catch {
                return []
            }
        }else {
            return []
        }
    }
    
    func getOlOReorderDetailsUsingPrintedCardNumber() -> ModelReorderDetails? {
        var modelReorderList = getOlOReorderPopupRemainder()
        if let index = modelReorderList?.lastIndex(where: {$0.printedCardNumber == PaytronixAppDelegate.currentAccount()?.printedCardNumber}) {
            return modelReorderList?[index]
        }
        return nil
    }
    
    func checkRecentOrder(delegate:UIViewController) {
        if AppDetails.shared.oloRecentOrderList.count > 0 {
            let lastOrder = AppDetails.shared.oloRecentOrderList.first
            if let orderRemainder = AppDetails.shared.getOlOReorderDetailsUsingPrintedCardNumber(), orderRemainder.orderID == lastOrder?.oloid, orderRemainder.printedCardNumber == PaytronixAppDelegate.currentAccount()?.printedCardNumber {
                print("OLOID:\(lastOrder?.oloid ?? "dd")")
                print("OrderID:\(orderRemainder.orderID)")
                var intervalCount:Int = 0
                var list:[ModelNextReminder]? = [ModelNextReminder]()
                for remainder in orderRemainder.reminder {
                    if checkRemainderDate(daysInterval: remainder.nextRemiderDays, orderDate: (lastOrder?.timeplaced)!) {// To check current date to next remainder date
                        if !remainder.isPopupAlreadyShown {// To check popup shown or not
                            intervalCount = intervalCount + 1
                        }
                        list?.append(ModelNextReminder.init(nextRemiderDays: remainder.nextRemiderDays, isPopupAlreadyShown: true))
                    } else {
                        if !remainder.isPopupAlreadyShown {// To check popup shown or not
                            list?.append(ModelNextReminder.init(nextRemiderDays: remainder.nextRemiderDays, isPopupAlreadyShown: false))
                        } else {
                            list?.append(ModelNextReminder.init(nextRemiderDays: remainder.nextRemiderDays, isPopupAlreadyShown: true))
                        }
                    }
                }
                if intervalCount > 0 {
                    AppDetails.shared.showReorderPopUp(orderStatus:lastOrder!, delegate: delegate)
                }
                setOlOReorderPopupRemainder(orderStatus: lastOrder!, remainder: list!)
            } else {
                var list:[ModelNextReminder]? = [ModelNextReminder]()
                for value in OloValues.reorderReminderDaysIntervalList() {
                    list?.append(ModelNextReminder.init(nextRemiderDays: value, isPopupAlreadyShown: false))
                }
                setOlOReorderPopupRemainder(orderStatus: lastOrder!, remainder: list!)
                checkRecentOrder(delegate: delegate)
            }
        }
    }
    // To check current date to next remainder date
    func checkRemainderDate(daysInterval:Int, orderDate:String) -> Bool {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyyMMdd HH:mm"
        let nextDate:Date = Calendar.current.date(byAdding: .day, value: daysInterval, to: dateFormatter.date(from: orderDate)!)!
        let order = NSCalendar.current.compare(Date(), to: nextDate, toGranularity: .day)
        switch order {
        case .orderedAscending://Next remainder smaller than current date
            return false
        case .orderedDescending://Next remainder greater than Current date
            return true
        case .orderedSame://Same dates
            return true
        default:
            return false
        }
    }
    //MARK: Loader
    @objc func showOloLoader(message:String, status:Bool) {
        if viewLoader == nil {
            //viewLoader
            viewLoader = UIView.init()
            viewLoader?.backgroundColor = UIColor.black.withAlphaComponent(0.2)
            APPSHARE.window.addSubview(viewLoader!)
            viewLoader?.translatesAutoresizingMaskIntoConstraints = false
            APPSHARE.window.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[viewLoader]-0-|", options: [], metrics: [:], views: ["viewLoader" : viewLoader!]))
            APPSHARE.window.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[viewLoader]-0-|", options: [], metrics: [:], views: ["viewLoader" : viewLoader!]))
            APPSHARE.window.bringSubviewToFront(viewLoader!)
            //indicator
            let indicator = UIView.init()
            indicator.backgroundColor = UIColor.white.withAlphaComponent(0.7)
            indicator.setCornerRadious(cornerRadious: 10, borderColor: .black, borderWidth: 0)
            indicator.translatesAutoresizingMaskIntoConstraints = false
            viewLoader?.addSubview(indicator)
            viewLoader?.addConstraint(NSLayoutConstraint.init(item: indicator, attribute: .centerX, relatedBy: .equal, toItem: viewLoader, attribute: .centerX, multiplier: 1, constant: 0))
            viewLoader?.addConstraint(NSLayoutConstraint.init(item: indicator, attribute: .centerY, relatedBy: .equal, toItem: viewLoader, attribute: .centerY, multiplier: 1, constant: 0))
            indicator.addConstraint(NSLayoutConstraint.init(item: indicator, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 100))
            indicator.addConstraint(NSLayoutConstraint.init(item: indicator, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 100))
            APPSHARE.window.bringSubviewToFront(viewLoader!)
            //Gif
            self.gitViewLoader = GIFImageView.init()
            self.gitViewLoader?.contentMode = .scaleAspectFill
            gitViewLoader?.translatesAutoresizingMaskIntoConstraints = false
            indicator.addSubview(gitViewLoader!)
            indicator.addConstraint(NSLayoutConstraint.init(item: gitViewLoader!, attribute: .centerX, relatedBy: .equal, toItem: indicator, attribute: .centerX, multiplier: 1, constant: 0))
            indicator.addConstraint(NSLayoutConstraint.init(item: gitViewLoader!, attribute: .centerY, relatedBy: .equal, toItem: indicator, attribute: .centerY, multiplier: 1, constant: 0))
            gitViewLoader?.addConstraint(NSLayoutConstraint.init(item: gitViewLoader!, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 100))
            gitViewLoader?.addConstraint(NSLayoutConstraint.init(item: gitViewLoader!, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 100))
            self.gitViewLoader?.prepareForAnimation(withGIFNamed:AppSettings.shared().loderGifImage())
            self.gitViewLoader?.startAnimatingGIF()
        }else {
            viewLoader?.isHidden = false
            APPSHARE.window.bringSubviewToFront(viewLoader!)
            self.gitViewLoader?.startAnimatingGIF()
        }
    }
    @objc func hideOloLoader(message:String = "", status:Bool = true) {
        viewLoader?.isHidden = true
    }
    
    
    //MM Recent Order
    func setMMRecentOrders(orderStatus:ModelOrderstatus) {
        var modelMMRecentOrderList = getMMRecentOrders()
        if let index = modelMMRecentOrderList.lastIndex(where: {$0.oloid == orderStatus.oloid}) {
            modelMMRecentOrderList.remove(at: [index])
        }
        modelMMRecentOrderList.append(orderStatus)
        do {
            let encodedData = try JSONEncoder().encode(modelMMRecentOrderList)
            UserDefaults.standard.set(encodedData, forKey: k_MMRecentOrders)
            UserDefaults.standard.synchronize()
        }catch {
            print("Error: encode ModelStoreServiceChannel - \(error.localizedDescription)")
        }
    }
    //MM Recent Order
    func getMMRecentOrders() -> [ModelOrderstatus] {
        //Recent Order
        let currentProvider = OnlineOrderClientAPI.currentProvider
        OnlineOrderClientAPI.setApiOnlineOrderProvider(.monkeyMedia) //set olo for temp
        if let jsonData = UserDefaults.standard.object(forKey: k_MMRecentOrders) as? Data {
            do {
                let decoder = try JSONDecoder().decode([ModelOrderstatus].self, from: jsonData)
                OnlineOrderClientAPI.setApiOnlineOrderProvider(currentProvider)
                return decoder
            }catch {
                print("Error: decode ModelStoreServiceChannel - \(error)")
                OnlineOrderClientAPI.setApiOnlineOrderProvider(currentProvider)
                return []
            }
        }else {
            return []
        }
    }
    // Safe Area bottom height for setup iPhone X compatible
    func deviceSafeAreaBottomHeight() -> CGFloat {
        var bottomHeight: CGFloat = 0.0
        if #available(iOS 11.0, *) {
            let window = UIApplication.shared.keyWindow
            bottomHeight = window?.safeAreaInsets.bottom ?? 0.0
        }
        return bottomHeight
    }
    
    func addSpaceAroundFooterView(forView footerView: UIView, constraints: [NSLayoutConstraint], footerViewTopConstraint: NSLayoutConstraint? = nil, siblingViewBottomSpace: NSLayoutConstraint? = nil) {
        constraints[0].constant = 20 //Leading Space
        constraints[1].constant = 20 //Trailing Space
        constraints[2].constant = deviceSafeAreaBottomHeight() //Bottom space - Safe area height
        footerView.layer.cornerRadius = 5
        if let siblingBottomSpace = siblingViewBottomSpace {
            siblingBottomSpace.constant = deviceSafeAreaBottomHeight() + footerView.frame.height + 10
        }
        if let footerViewTop = footerViewTopConstraint {
            footerViewTop.constant = 10
        }
    }
}
//MARK:- Extension UIView
extension UIView {
    //MARK: Border Dash Line
    func addDashLineBorderDefault() {
        self.addDashLineBorder(color: UIColor.oloColorTextFourth(), corner: 5)
    }
    func addDashLineBorder(color:UIColor, corner:CGFloat) {
        let colorCG = color.cgColor
        self.layer.sublayers?.forEach({ (layerTmep) in
            if layerTmep.name == "borderLayerCorner" {
                layerTmep.removeFromSuperlayer()
            }
        })
        let  borderLayer = CAShapeLayer()
        borderLayer.name  = "borderLayerCorner"
        let frameSize = self.frame.size
        let shapeRect = CGRect(x: 0, y: 0, width: frameSize.width, height: frameSize.height)
        borderLayer.bounds=shapeRect
        borderLayer.position = CGPoint(x: frameSize.width/2, y: frameSize.height/2)
        borderLayer.fillColor = UIColor.clear.cgColor
        borderLayer.strokeColor = colorCG
        borderLayer.lineWidth=1
        borderLayer.lineJoin=CAShapeLayerLineJoin.round
        borderLayer.lineDashPattern = [2,2]
        let path = UIBezierPath.init(roundedRect: shapeRect, cornerRadius: corner)
        borderLayer.path = path.cgPath
        self.layer.addSublayer(borderLayer)
    }
    //MARK: Shadow
    func setShadow() {
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOffset = CGSize(width: 2, height: 2)
        self.layer.shadowOpacity = 0.3
        self.layer.shadowRadius = 1.0
    }
    func setShadowOutline(_ shadowRadius:CGFloat = 2.0) {
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.layer.shadowOpacity = 0.2
        self.layer.shadowRadius = shadowRadius
    }
    func setShadowOutline(_ color:UIColor = .black, shadowRadius:CGFloat = 2.0) {
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.layer.shadowOpacity = 0.2
        self.layer.shadowRadius = shadowRadius
    }
    func addDashedLineInView(color: UIColor = UIColor.oloColorTextFourth()) {
        //layer.sublayers?.filter({ $0.name == "DashedTopLine" }).forEach({$0.removeFromSuperlayer()})
        self.layer.sublayers?.forEach({ (layerTmep) in
            if layerTmep.name == "DashedTopLine" {
                layerTmep.removeFromSuperlayer()
            }
        })
        backgroundColor = .clear
        let shapeLayer = CAShapeLayer()
        shapeLayer.name = "DashedTopLine"
        shapeLayer.bounds = bounds
        shapeLayer.position = CGPoint(x: frame.width / 2, y: frame.height / 2)
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.strokeColor = color.cgColor
        shapeLayer.lineWidth = 1
        shapeLayer.lineJoin = CAShapeLayerLineJoin.round
        shapeLayer.lineDashPattern = [4, 4]
        
        let path = CGMutablePath()
        path.move(to: CGPoint.zero)
        path.addLine(to: CGPoint(x: frame.width, y: 0))
        shapeLayer.path = path
        
        layer.addSublayer(shapeLayer)
    }
    func setCornerRadious(cornerRadious:CGFloat = 0, borderColor:UIColor = .clear, borderWidth:CGFloat = 0) {
        self.layer.cornerRadius = cornerRadious
        self.layer.borderWidth = borderWidth
        self.layer.borderColor = borderColor.cgColor
        if cornerRadious > 0 {
            self.layer.masksToBounds = true
        }
    }
    //MARK:- Animation
    func startBlink(_ duration:TimeInterval = 0.8) {
        UIView.animate(withDuration: duration,
                       delay:0.0,
                       options:[.allowUserInteraction, .curveEaseInOut, .autoreverse, .repeat],
                       animations: { self.alpha = 0 },
                       completion: nil)
    }
    func stopAnimation() {
        layer.removeAllAnimations()
        alpha = 1
        transform = CGAffineTransform(rotationAngle: 0)
    }
    func startDancing(_ rotationAngle:CGFloat = -0.5, duration:TimeInterval = 1.0) {
        self.transform = CGAffineTransform(rotationAngle: -(rotationAngle))
        UIView.animate(withDuration: duration,
                       delay:0.0,
                       options:[.allowUserInteraction, .curveEaseInOut, .autoreverse, .repeat],
                       animations: { self.transform = CGAffineTransform(rotationAngle: rotationAngle) },
                       completion: nil)
    }
    //Anchor
    func anchor (top: NSLayoutYAxisAnchor?, left: NSLayoutXAxisAnchor?, bottom: NSLayoutYAxisAnchor?, right: NSLayoutXAxisAnchor?, paddingTop: CGFloat, paddingLeft: CGFloat, paddingBottom: CGFloat, paddingRight: CGFloat, width: CGFloat, height: CGFloat, enableInsets: Bool) {
        var topInset = CGFloat(0)
        var bottomInset = CGFloat(0)
        
        if #available(iOS 11, *), enableInsets {
            let insets = self.safeAreaInsets
            topInset = insets.top
            bottomInset = insets.bottom
        }
        translatesAutoresizingMaskIntoConstraints = false
        if let top = top {
            self.topAnchor.constraint(equalTo: top, constant: paddingTop+topInset).isActive = true
        }
        if let left = left {
            self.leftAnchor.constraint(equalTo: left, constant: paddingLeft).isActive = true
        }
        if let right = right {
            rightAnchor.constraint(equalTo: right, constant: -paddingRight).isActive = true
        }
        if let bottom = bottom {
            bottomAnchor.constraint(equalTo: bottom, constant: -paddingBottom-bottomInset).isActive = true
        }
        if height != 0 {
            heightAnchor.constraint(equalToConstant: height).isActive = true
        }
        if width != 0 {
            widthAnchor.constraint(equalToConstant: width).isActive = true
        }
    }
}
//MARK:- Extension UIViewController
extension UIViewController {
    //MARK: BackButton in Navigation
    @objc func addBackBarButtonInNavigation() {
        let viewLeftSide = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 35, height: 35))
        viewLeftSide.isUserInteractionEnabled = true
        let backButton = UIButton.init(frame: viewLeftSide.bounds)
        backButton.imageEdgeInsets = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        backButton.setImage(#imageLiteral(resourceName: "iconOloBack"), for: .normal)
        backButton.tintColor = UIColor.oloColorNavigationBarText()
        backButton.isExclusiveTouch = true
        accessibilityVoiceOver(type: backButton, title: OloDisplayText.AppDetailsBackNavigationButtonAccessibilityTitle(), hint: "")
        backButton.addTarget(self, action: #selector(self.actionNavigationBack(_:)), for: .touchUpInside)
        viewLeftSide.addSubview(backButton)
        let leftBarItems = UIBarButtonItem.init(customView: viewLeftSide)
        self.navigationItem.leftBarButtonItem = leftBarItems
    }
    @objc func addBackBarButtonInNavigation(tintColor:UIColor? = AppSettings.shared().primaryColor()) { // the optional tintColor for branded old screen back item color
        let viewLeftSide = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 35, height: 35))
        viewLeftSide.isUserInteractionEnabled = true
        let backButton = UIButton.init(frame: viewLeftSide.bounds)
        backButton.imageEdgeInsets = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        if var backArrow = UIImage.init(named: "theme1_back"){
            backArrow = backArrow.withRenderingMode(.alwaysTemplate)
            backButton.setImage(backArrow, for: .normal)
            backButton.tintColor = tintColor
        }
        backButton.isExclusiveTouch = true
        accessibilityVoiceOver(type: backButton, title: OloDisplayText.AppDetailsBackNavigationButtonAccessibilityTitle(), hint: "")
        backButton.addTarget(self, action: #selector(self.actionNavigationBack(_:)), for: .touchUpInside)
        viewLeftSide.addSubview(backButton)
        let leftBarItems = UIBarButtonItem.init(customView: viewLeftSide)
        self.navigationItem.leftBarButtonItem = leftBarItems
    }
    @objc func addBackBarButtonToNavigateDashBoard() {
        let viewLeftSide = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 35, height: 35))
        viewLeftSide.isUserInteractionEnabled = true
        let backButton = UIButton.init(frame: viewLeftSide.bounds)
        backButton.imageEdgeInsets = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        backButton.setImage(#imageLiteral(resourceName: "iconOloBack"), for: .normal)
        backButton.tintColor = UIColor.oloColorNavigationBarText()
        backButton.isExclusiveTouch = true
        accessibilityVoiceOver(type: backButton, title: OloDisplayText.AppDetailsBackNavigationButtonAccessibilityTitle(), hint: "")
        backButton.addTarget(self, action: #selector(self.segueToHomePage), for: .touchUpInside)
        viewLeftSide.addSubview(backButton)
        let leftBarItems = UIBarButtonItem.init(customView: viewLeftSide)
        self.navigationItem.leftBarButtonItem = leftBarItems
    }

    @objc func addMenuBarButtonInNavigation(isForDashboard: Bool = false){
        let viewWidthAndHeight = isForDashboard && AppSettings.shared()?.isEnableTierFeature() ?? false ? 28 : 35
        let viewLeftSide = UIView.init(frame: CGRect.init(x: 0, y: 0, width: viewWidthAndHeight, height: viewWidthAndHeight))
        viewLeftSide.isUserInteractionEnabled = true
        let backButton = UIButton.init(frame: viewLeftSide.bounds)
        if isForDashboard && AppSettings.shared()?.isEnableTierFeature() ?? false {
            backButton.setImage(#imageLiteral(resourceName: "iconMenuTierEnabled"), for: .normal)
            backButton.tintColor = UIColor.oloColorTheme()
        } else {
            backButton.setImage(#imageLiteral(resourceName: "iconOloSideDrawer"), for: .normal)
            backButton.tintColor = UIColor.oloColorNavigationBarText()
        }
        backButton.isAccessibilityElement = true
        accessibilityVoiceOver(type: backButton, title: OloDisplayText.AppDetailsSideNavigationButtonAccessibilityTitle(), hint: "")
        backButton.isExclusiveTouch = true
        backButton.addTarget(self, action: #selector(self.actionMenuButton), for: .touchUpInside)
        viewLeftSide.addSubview(backButton)
        let leftBarItems = UIBarButtonItem.init(customView: viewLeftSide)
        self.navigationItem.leftBarButtonItem = leftBarItems
    }
    @objc func addHomeBarButtonInNavigation(){
        let viewLeftSide = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 35, height: 35))
        viewLeftSide.isUserInteractionEnabled = true
        let backButton = UIButton.init(frame: viewLeftSide.bounds)
        backButton.setImage(#imageLiteral(resourceName: "iconOloHome"), for: .normal)
        backButton.tintColor = UIColor.oloColorNavigationBarText()
        backButton.isExclusiveTouch = true
        backButton.addTarget(self, action: #selector(self.segueToHomePage), for: .touchUpInside)
        viewLeftSide.addSubview(backButton)
        let leftBarItems = UIBarButtonItem.init(customView: viewLeftSide)
        self.navigationItem.rightBarButtonItem = leftBarItems
    }
    @objc func addNotificationButtonInNavigation(){
        if (!AppSettings.shared().isOloThemeOneEnabled()){
            return
        }else{
            if !OloValues.valueShowNotificationIcon(){
                return
            }
        }
        let viewLeftSide = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 33, height: 33))
        viewLeftSide.isUserInteractionEnabled = true
        let backButton = UIButton.init(frame: viewLeftSide.bounds)
        backButton.setImage(#imageLiteral(resourceName: "iconOloMessage"), for: .normal)
        if let tempImage = backButton.currentImage?.withRenderingMode(.alwaysTemplate){
            backButton.setImage(tempImage, for: .normal)
            backButton.tintColor = AppSettings.shared().primaryColor()
        }
        backButton.isExclusiveTouch = true
        backButton.addTarget(self, action: #selector(self.segueToMessageListPage(_:)), for: .touchUpInside)
        
        notificationCount = UILabel.init(frame: CGRect(x: 18, y: 0, width: 20, height: 20))
        notificationCount.font = self.getFont(family: AppSettings.shared().signInRefreshEnablePrimaryFontFamily(), size: 11)
        notificationCount.textColor = AppSettings.shared().highContrastColor()
        notificationCount.textAlignment = .center
        notificationCount.layer.cornerRadius = 10
        notificationCount.clipsToBounds = true
        notificationCount.layer.masksToBounds = true
        notificationCount.backgroundColor = AppSettings.shared().primaryColor()
        
        let externalBorder = CALayer()
        externalBorder.frame = CGRect(x: -1, y: -1, width: notificationCount.frame.size.width + 2, height: notificationCount.frame.size.height + 2)
        externalBorder.cornerRadius = 11
        externalBorder.borderColor = AppSettings.shared().highContrastColor().cgColor
        externalBorder.borderWidth = 2.5
        notificationCount.layer.addSublayer(externalBorder)
        
        viewLeftSide.addSubview(backButton)
        viewLeftSide.addSubview(notificationCount)
        let leftBarItems = UIBarButtonItem.init(customView: viewLeftSide)
        self.navigationItem.rightBarButtonItem = leftBarItems
    }
    @objc func addBasketButtonInNavigation(isForDashboard: Bool = false){
        if (!AppSettings.shared().isOloThemeOneEnabled()){
            return
        }else{
            if !OloValues.valueShowBasketIcon(){
                return
            }
        }
        let viewLeftSide = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 33, height: 33))
        viewLeftSide.isUserInteractionEnabled = true
        let backButton = UIButton.init(frame: viewLeftSide.bounds)
        backButton.setImage(#imageLiteral(resourceName: "iconOlONavigationBasket"), for: .normal)
        if let tempImage = backButton.currentImage?.withRenderingMode(.alwaysTemplate){
            backButton.setImage(tempImage, for: .normal)
            backButton.tintColor = (isForDashboard && AppSettings.shared()?.isEnableTierFeature() ?? false) ? UIColor.oloColorTheme() : UIColor.oloColorNavigationBarText()
        }
        backButton.isExclusiveTouch = true
        backButton.addTarget(self, action: #selector(navigationBasketBtnAction(sender:)), for: .touchUpInside)
        var basketCount = UILabel.init(frame: CGRect(x: 18, y: 0, width: 20, height: 20))
        basketCount.font = self.getFont(family: AppSettings.shared().signInRefreshEnablePrimaryFontFamily(), size: 11)
        basketCount.textColor = AppSettings.shared().highContrastColor()
        basketCount.textAlignment = .center
        basketCount.layer.cornerRadius = 10
        basketCount.clipsToBounds = true
        basketCount.layer.masksToBounds = true
        basketCount.backgroundColor = AppSettings.shared().primaryColor()
        if AppDetails.shared.basketModel.isBasketStatus {
            let basketProductCount = AppDetails.shared.basketModel.basketDetails?.products.count ?? 0
            basketCount.isHidden = basketProductCount == 0 ? true : false
            if basketProductCount > 99 {
                basketCount.text = String(format: "99+")
            }else{
                basketCount.text = String(format: "%d", basketProductCount)
            }
        } else {
            basketCount.isHidden = true
        }
        basketCount.accessibilityElementsHidden = true
        accessibilityVoiceOver(type: backButton, title: OloDisplayText.AppDetailsCartNavigationButtonAccessibilityTitle(), hint: "")
        let externalBorder = CALayer()
        externalBorder.frame = CGRect(x: -1, y: -1, width: basketCount.frame.size.width + 2, height: basketCount.frame.size.height + 2)
        externalBorder.cornerRadius = 11
        externalBorder.borderColor = AppSettings.shared().highContrastColor().cgColor
        externalBorder.borderWidth = 2.5
        basketCount.layer.addSublayer(externalBorder)
        
        viewLeftSide.addSubview(backButton)
        viewLeftSide.addSubview(basketCount)
        let leftBarItems = UIBarButtonItem.init(customView: viewLeftSide)
        self.navigationItem.rightBarButtonItem = leftBarItems
    }
    @objc func navigationBasketBtnAction(sender: UIButton) {
        self.view.endEditing(true)
        if APPSHARE.isNetworkReachable() {
            if OnlineOrderClientAPI.isOnlineOrderEnabled{
                if AppDetails.shared.basketModel.isBasketStatus {
                    self.segueToBasket(isBackEnable: true, isFromHomePage: true)
                }else {
                    if OloValues.valueIsEmptyBasketToLocationScreen() {
                        self.segueToLocationListPage(from: false)
                    }else {
                        self.segueToBasket(isBackEnable: true, isFromHomePage: true)
                    }
                }
            }
        }
    }
    @objc func segueToMessageListPage(_ sender: UIButton)
    {
        //OTOMessageList
        mm_drawerController.setCenterView(APPSHARE.gotoOTOMessageList(), withCloseAnimation: true, completion: nil)
    }

    @objc func actionMenuButton() {
        let appDelegate = UIApplication.shared.delegate as! PaytronixAppDelegate
        appDelegate.drawerController.toggle(MMDrawerSide.left, animated: true, completion: nil)
    }
   @objc func segueToHomePage() {
        let arrayNaviList = self.navigationController?.viewControllers ?? []
        let appDelegate = UIApplication.shared.delegate as! PaytronixAppDelegate
        var vcHomeTemp:UIViewController?
        for item in arrayNaviList {
            if item is Home {
                vcHomeTemp = item
            }
        }
        if vcHomeTemp != nil {
            _ = self.navigationController?.popToViewController(vcHomeTemp!, animated: true)
        }else {
            //let homePage = Home()
            //self.navigationController?.pushViewController(homePage, animated: true)
            appDelegate.sideDrawer.setCenterViewControllerAsTabBarControllerWithSelectedIndex(0)
        }
    }
    @objc func segueToOLOSelectDateTimeViewController() {
        let arrayNaviList = self.navigationController?.viewControllers ?? []
        var vcHomeTemp:UIViewController?
        for item in arrayNaviList {
            if item is OLOOrderSelectDateTimeViewController && vcHomeTemp == nil { //Remove if AND fixed
                vcHomeTemp = item
            }
        }
        if vcHomeTemp != nil {
            _ = self.navigationController?.popToViewController(vcHomeTemp!, animated: true)
        }else {
            let storyBoard = UIStoryboard.init(name: kOloStoryBoardName, bundle: nil)
            let segueTO = storyBoard.instantiateViewController(withIdentifier: "OLOOrderSelectDateTimeViewController") as! OLOOrderSelectDateTimeViewController
            self.navigationController?.pushViewController(segueTO, animated: true)
        }
    }
    @objc func segueToOLOMenuViewController() {
        let arrayNaviList = self.navigationController?.viewControllers ?? []
        var vcHomeTemp:UIViewController?
        for item in arrayNaviList {
            if item is OLOMenuViewController && vcHomeTemp == nil { //Remove if AND fixed
                vcHomeTemp = item
            }
        }
        if vcHomeTemp != nil {
            (vcHomeTemp as! OLOMenuViewController).isFromAddMoreItems = false //Remove if AND fixed
            _ = self.navigationController?.popToViewController(vcHomeTemp!, animated: true)
        }else {
            let storyBoard = UIStoryboard.init(name: kOloStoryBoardName, bundle: nil)
            let segueTO = storyBoard.instantiateViewController(withIdentifier: "OLOMenuViewController") as! OLOMenuViewController
            self.navigationController?.pushViewController(segueTO, animated: true)
        }
    }
    func segueToCateringDetailsViewController() {
        let arrayNaviList = self.navigationController?.viewControllers ?? []
        var vcHomeTemp:UIViewController?
        for item in arrayNaviList {
            if item is OLOCateringPickupDeliveryViewController {
                vcHomeTemp = item
            }
        }
        if vcHomeTemp != nil {
            _ = self.navigationController?.popToViewController(vcHomeTemp!, animated: true)
        }else {
            let controller = OLOCateringPickupDeliveryViewController()
            self.navigationController?.pushViewController(controller, animated: true)
        }
    }
    func segueToMenuScreenIfExist() -> Bool {
        if let tempVCA = self.navigationController?.viewControllers {
            for (_, element)  in (tempVCA.enumerated()) {
                let tempVC = element
                if (tempVC is OLOMenuViewController) {
                    self.navigationController?.popToViewController(tempVC, animated: true)
                    return true
                }
            }
        }
        return false
    }
    @objc func segueToRootViewContoller() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    @objc func segueToOLOBasketViewController() {
        let arrayNaviList = self.navigationController?.viewControllers ?? []
        var vcHomeTemp:UIViewController?
        for item in arrayNaviList {
            if item is OLOBasketViewController {
                vcHomeTemp = item
            }
        }
        if vcHomeTemp != nil {
            _ = self.navigationController?.popToViewController(vcHomeTemp!, animated: true)
            AppDetails.shared.basketModel.removeGiftCard()
        }else {
            self.segueToBasket(isBackEnable: false)
            
            
        }
    }
    @objc func segueToOLOLocationListViewController() {
        AppDetails.shared.locationPageTitle = ""
        let arrayNaviList = self.navigationController?.viewControllers ?? []
        var vcHomeTemp:UIViewController?
        for item in arrayNaviList {
            if item is OLOLocationViewController {
                vcHomeTemp = item
            }
        }
        if vcHomeTemp != nil {
            _ = self.navigationController?.popToViewController(vcHomeTemp!, animated: true)
        }else {
            self.segueToLocationListPage(from: false)
        }
    }
    @objc func segueToOLOLocationListViewControllerFromHomePage() {
        AppDetails.shared.locationPageTitle = ""
        let arrayNaviList = self.navigationController?.viewControllers ?? []
        var vcHomeTemp:UIViewController?
        for item in arrayNaviList {
            if item is Home {
                vcHomeTemp = item
            }
        }
        let homePage = self.storyboard?.instantiateViewController(withIdentifier: "OLOLocation_ViewController") as! OLOLocationViewController
        homePage.isMenuScreen = false
        if vcHomeTemp != nil {
            vcHomeTemp!.navigationController?.viewControllers = [vcHomeTemp!,homePage]
        }else {
            self.navigationController?.pushViewController(homePage, animated: true)
        }
    }
    @objc func segueToLocationListPage(from menuPage:Bool) {
        AppDetails.shared.locationPageTitle = ""
        let storyBoard = UIStoryboard.init(name: kOloStoryBoardName, bundle: nil)
        let homePage = storyBoard.instantiateViewController(withIdentifier: "OLOLocation_ViewController") as! OLOLocationViewController
        homePage.isMenuScreen = menuPage
        self.navigationController?.pushViewController(homePage, animated: true)
    }
    
    func segueToOrderDetails(orderID:String, storeInfo:PXStoreInformation?, basketId:String, isBackEnable:Bool, oloStoreDetails:Restaurant, isMonkeyMediaProvider:Bool = false, basketRequest:ModelBasket? = nil)  {
        let segueTo = self.storyboard?.instantiateViewController(withIdentifier: "OLOOrderDetails") as! OLOOrderDetails
        segueTo.orderID = orderID
        segueTo.storeInfo = storeInfo
        segueTo.basketId = basketId
        segueTo.isBackEnable = isBackEnable
        segueTo.oloStoreDetails = oloStoreDetails
        segueTo.isMonkeyMediaProvider = isMonkeyMediaProvider
        segueTo.basketRequest = basketRequest
        self.navigationController?.pushViewController(segueTo, animated: true)
    }
    func segueToFeedback(orderID:String, vendorID:Int, basketID:String)  {
        let segueTo = self.storyboard?.instantiateViewController(withIdentifier: "OLOFeedBackMenu") as! OLOFeedBackMenu
        segueTo.orderID = orderID
        segueTo.basketID = basketID
        segueTo.vendorID = vendorID
        self.navigationController?.pushViewController(segueTo, animated: true)
    }
    @objc func segueToPopViewController(before:Int) {
        let arrayNaviList = self.navigationController?.viewControllers ?? []
        if arrayNaviList.count > before {
            let segueTo = arrayNaviList[arrayNaviList.count-before]
            self.navigationController?.popToViewController(segueTo, animated: true)
        }else {
            self.navigationController?.popToRootViewController(animated: true)
        }
    }
    @objc func setNavigationTitle(title:String) {
        self.navigationItem.title = title.uppercased()
    }
    @objc func setOLONavigationBar() {
   
        var navBarBg : UIImage? = UIImage(named: "navBar")
        let statusBarFrame = UIApplication.shared.statusBarFrame
        let statusBarWidth = Int(statusBarFrame.width)
        let statusBarHeight = Int(statusBarFrame.height)
        if statusBarWidth == 375 {
            if statusBarHeight == 20 {
                navBarBg = UIImage(named: "navBar")
            }else{
                navBarBg = UIImage(named: "navBarForX_Xs")
            }
        }else if statusBarWidth == 414 {
            if statusBarHeight == 20 {
                navBarBg = UIImage(named: "navBarForPlusDevice")
            }else{
                navBarBg = UIImage(named: "navBarForXr_XsMax")
            }
        }else {
            if statusBarHeight == 20 {
                navBarBg = UIImage(named: "navBar")
            }else{
                navBarBg = UIImage(named: "navBarForX_Xs")
            }
        }
        self.navigationController?.navigationBar.setBackgroundImage(navBarBg, for: .default)
        self.navigationController?.navigationBar.isHidden = false
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = true
        self.navigationController?.navigationBar.backgroundColor = UIColor.oloColorNavigationBackGround()
        self.navigationController?.navigationBar.barTintColor = UIColor.oloColorNavigationBarText()
        self.navigationController?.navigationBar.titleTextAttributes = [ NSAttributedString.Key.font: UIFont.oloFontPrimary(20),NSAttributedString.Key.foregroundColor:UIColor.oloColorNavigationBarText()]
    }
    @objc func setOLODashboardNavigationBar() {
        self.navigationController?.navigationBar.isHidden = false
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = true
        self.navigationController?.navigationBar.backgroundColor = AppSettings.shared()?.highContrastColor()
        self.navigationController?.navigationBar.barTintColor = UIColor.oloColorTheme()
        self.navigationController?.navigationBar.titleTextAttributes = [ NSAttributedString.Key.font: UIFont.oloFontPrimary(20),NSAttributedString.Key.foregroundColor:UIColor.oloColorPrimary()]
    }
    func segueToMenuOrDetailsScreen(storeCode:Int, storeInfo:PXStoreInformation, oloStoreDetails:Restaurant, isNavToDetail: Bool,  isFromeDetail: Bool = false, orderType: OloOrderType, deliveryAddress:ModelDeliveryAddress? = nil)
    {
        if(isNavToDetail) {
            APPSHARE.hideHud(for: self.view)
            let storeInfoPage = self.storyboard?.instantiateViewController(withIdentifier: "OLOStoreInfoViewController") as! OLOStoreInfoViewController
            storeInfoPage.storeInformation  = storeInfo
            storeInfoPage.oloStoreCode = storeCode
            storeInfoPage.isFromMenuScreen = true
            storeInfoPage.isNavToDetail = isNavToDetail
            self.navigationController?.pushViewController(storeInfoPage, animated: true)
        } else {
            //START - New Order Type Selection with Delivery Address
            if (AppSettings.shared()?.isNewOrderTypeScreenWithDeliveryAddress() ?? false) {
                if orderType == .pickup, let basket = AppDetails.shared.basketModel.basketDetails, basket.deliverymode != .pickup {
                    apiDeliveryMode(.pickup, deliveryAddress: deliveryAddress)
                }else if orderType == .curbside, let basket = AppDetails.shared.basketModel.basketDetails, basket.deliverymode != .curbside {
                    apiDeliveryMode(.curbside, deliveryAddress: deliveryAddress)
                }else {
                    self.segueToNewOrderFlowOrNewOrderFlowWithDeliveryAddress(orderType, deliveryAddress: deliveryAddress)
                }
            }else if OloValues.isNewOrderFlowEnabled() {
                if orderType == .pickup, let basket = AppDetails.shared.basketModel.basketDetails, basket.deliverymode != .pickup {
                    apiDeliveryMode(.pickup, deliveryAddress: deliveryAddress)
                }else if orderType == .curbside, let basket = AppDetails.shared.basketModel.basketDetails, basket.deliverymode != .curbside {
                    apiDeliveryMode(.curbside, deliveryAddress: deliveryAddress)
                }else {
                    self.segueToNewOrderFlowOrNewOrderFlowWithDeliveryAddress(orderType, deliveryAddress: deliveryAddress)
                }
            } else {
                APPSHARE.hideHud(for: self.view)
                self.segueToOLOMenuViewController()
            }
        }
    }
    
    func apiDeliveryMode(_ orderType: OloOrderType, deliveryAddress:ModelDeliveryAddress? = nil) {
        APPSHARE.showHud(withMessage: "", for: self.view)
        OnlineOrderBasketAPI.basketsBasketIdDeliverymodePut(basketId: AppDetails.shared.basketModel.basketID, body: ModelSetDeliveryModePost.init(deliverymode: orderType == .pickup ? "pickup" : orderType == .curbside ? "curbside" : "")) { (basket, error) in
            DispatchQueue.main.async {
                if basket != nil && (basket?.id ?? "").count > 0 {
                    AppDetails.shared.basketModel.setBasketResponse(basket!)
                    self.segueToNewOrderFlowOrNewOrderFlowWithDeliveryAddress(orderType, deliveryAddress: deliveryAddress)
                }else if error != nil {
                    APPSHARE.hideHud(for: self.view)
                    self.alertMessageErrorMessage(error!)
                }else {
                    APPSHARE.hideHud(for: self.view)
                    self.alertMessage(OloDisplayText.textSomeWentWrong())
                }
            }
        }
    }
    func segueToNewOrderFlowOrNewOrderFlowWithDeliveryAddress(_ orderType: OloOrderType, deliveryAddress:ModelDeliveryAddress? = nil) {
        if (AppSettings.shared()?.isNewOrderTypeScreenWithDeliveryAddress() ?? false) { //New Order Type Selection with Delivery Address - Skip Asap/Later page
            if orderType == .delivery && deliveryAddress != nil {
                self.apiSetOlODeliveryAddress(deliveryAddress!)
            }else {
                APPSHARE.hideHud(for: self.view)
                self.segueToOLOMenuViewController()
            }
        }else if OloValues.isNewOrderFlowEnabled() { //New Order Type Selection - Segue to Asap/Later Page
            APPSHARE.hideHud(for: self.view)
            let storyBoard = UIStoryboard.init(name: kOloStoryBoardName, bundle: nil)
            let segueTO = storyBoard.instantiateViewController(withIdentifier: "OLOOrderSelectDateTimeViewController") as! OLOOrderSelectDateTimeViewController
            segueTO.deliveryAddress = deliveryAddress
            self.navigationController?.pushViewController(segueTO, animated: true)
        }else {
            APPSHARE.hideHud(for: self.view)
            self.segueToOLOMenuViewController()
        }
    }
    func apiSetOlODeliveryAddress(_ deliveryAddress:ModelDeliveryAddress) {
        if APPSHARE.isNetworkReachable() {
            OnlineOrderBasketAPI.basketsBasketIdDeliveryOrDispatchAddressPut(dispatch: !(AppDetails.shared.basketModel.basketOloStoreInfo?.candeliver ?? false), basketId: AppDetails.shared.basketModel.basketID, body: deliveryAddress) { (basket, error) in
                DispatchQueue.main.async {
                    if basket != nil {
                        AppDetails.shared.basketModel.setBasketResponse(basket!) 
                        APPSHARE.hideHud(for: self.view)
                        let storyBoard = UIStoryboard.init(name: kOloStoryBoardName, bundle: nil)
                        let segueTO = storyBoard.instantiateViewController(withIdentifier: "OLOMenuViewController") as! OLOMenuViewController
                        self.navigationController?.pushViewController(segueTO, animated: true)
                    }else if error != nil {
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessageErrorMessage(error!)
                    }else {
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessage(OloDisplayText.textSomeWentWrong())
                    }
                }
            }
        }
    }
    //END - New Order Type Selection with Delivery Address
    
    func segueToStoreInfo(storeCode:Int, storeInfo:PXStoreInformation, isNavToDetail: Bool,  isFromeDetail: Bool = true) {
        let storeInfoPage = self.storyboard?.instantiateViewController(withIdentifier: "OLOStoreInfoViewController") as! OLOStoreInfoViewController
        storeInfoPage.storeInformation  = storeInfo
        storeInfoPage.oloStoreCode = storeCode
        storeInfoPage.isNavToDetail = isFromeDetail
        self.navigationController?.pushViewController(storeInfoPage, animated: true)
    }
    @objc func actionNavigationBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
        
        if APPSHARE.isFromNewThemeDashboard{
            APPSHARE.sideDrawer.setCenterViewControllerAsTabBarControllerWithSelectedIndex(0)
        }
    }
    //MARK: BackButton in Navigation
    @objc func addCancelBarButtonInNavigation(){
        let backButton = UIButton(type: .custom)
        //backButton.setImage(UIImage(named: ""), for: .normal)
        backButton.setTitle("Cancel", for: .normal)
        backButton.titleLabel?.font = UIFont.oloFontPrimary(15)
        backButton.setTitleColor(UIColor.oloColorNavigationBarText(), for: .normal)
        backButton.addTarget(self, action: #selector(self.actionNavigationCancel(_:)), for: .touchUpInside)
        backButton.frame = CGRect(x: 0, y: 0, width: 60, height: 35)
        backButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: -20, bottom: 0, right: 0)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(customView: backButton)
    }
    @objc func actionNavigationCancel(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    //MARK: Done Button in Keyboard
    @objc func addDoneButtonInKeyboard() -> UIToolbar {
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor(red: 76/255, green: 217/255, blue: 100/255, alpha: 1)
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(actionDone))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        toolBar.setItems([spaceButton, spaceButton, doneButton], animated: false)
        toolBar.barTintColor = UIColor.oloColorTextTheme()
        toolBar.isUserInteractionEnabled = true
        toolBar.sizeToFit()
        return toolBar
    }
   @objc func actionDone(){
        view.endEditing(true)
    }
    //MARK: UnderLine
    @objc func addUnderLineInBottom(view:UIView) {
        let viewTemp = UIView()
        viewTemp.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(viewTemp)
        viewTemp.backgroundColor = .black
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[viewTemp]-0-|", options: [], metrics: [:], views: ["viewTemp":viewTemp]))
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:[viewTemp(1)]-0-|", options: [], metrics: [:], views: ["viewTemp":viewTemp]))
    }
    func getImageFromCache(imageView:UIImageView, imageUrl:String, placeHolderImage:UIImage) {
        imageView.sd_setImage(with: URL(string: imageUrl.replacingOccurrences(of: " ", with: "%20")), placeholderImage: placeHolderImage)
    }
    @objc func callFromDevice(phoneNumber:String) {
        if let phoneCallURL = URL(string: "tel://\(phoneNumber)") {
            let application:UIApplication = UIApplication.shared
            if phoneNumber != "" {
                if (application.canOpenURL(phoneCallURL)) {
                    if #available(iOS 10.3, *) {
                        application.open(phoneCallURL, options: convertToUIApplicationOpenExternalURLOptionsKeyDictionary([:]), completionHandler: nil)
                    }else {
                        UIApplication.shared.openURL(phoneCallURL)
                        // commented for [APPL-53030] Branded App : The back button and home icon's colour gets changed when the store's phone number link is tapped
                        /*let alert = UIAlertController(title: "\(phoneNumber)",
                            message: "",
                            preferredStyle: .alert)
                        //alert.view.tintColor = UIColor.oloColorTheme()
                        let cancel = UIAlertAction(title: "Cancel", style: .default, handler: { (action) -> Void in })
                        let submitAction = UIAlertAction(title: "Call", style: .default, handler: { (action) -> Void in
                            UIApplication.shared.openURL(phoneCallURL)
                        })
                        alert.addAction(cancel)
                        alert.addAction(submitAction)
                        view.tintAdjustmentMode = .normal
                        present(alert, animated: true, completion: nil)*/
                    }
                }
            }else {
                if (AppSettings.shared().isOloThemeOneEnabled() || AppSettings.shared().isOloThemeOneEnabled()) && !OnlineOrderClientAPI.isOnlineOrderEnabled {
                    self.showAlert(title: nil, description: "Phone number is not available", rightButton: "OK", leftButton: nil) { (status) in }
                }else{
                    AlertView.show("Phone number is not available")
                }
            }
        }
    }
    func callApiGetMenuDetails(providerMenuID: Int, completionHandler:@escaping ((_ menu:ModelMenu?, _ status:Bool) -> Void)) {
        if(APPSHARE.isNetworkReachable()) {
            APPSHARE.showHud(withMessage: "", for: self.view)
            OnlineOrderRestaurantAPI.restaurantsRestaurantIdMenuGet(restaurantId: providerMenuID) { (response, error) in
                DispatchQueue.main.async {
                    if response != nil {//} && (response?.menuCategories?.count ?? 0) > 0 {
                        APPSHARE.hideHud(for: self.view)
                        completionHandler(response!, true)
                    }else if error != nil {
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessageErrorMessage(error!)
                        completionHandler(nil, false)
                    }else {
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessage(OloDisplayText.textSomeWentWrong())
                        completionHandler(nil, false)
                    }
                }
            }
        }
    }
    //MARK: API
    func apiOloAddToBasket(basketProduct:ModelNewBasketProduct, basketProductMM:ModelBasket?, isBuyNow:Bool, isMayWeSuggest:Bool = false) {
        if APPSHARE.isNetworkReachable() {
            APPSHARE.showHud(withMessage: "", for: self.view)
            OnlineOrderBasketAPI.basketsBasketIdProductsPost(basketId: AppDetails.shared.basketModel.basketID, bodyCreateBasket: ModelCreatebasket.init(vendorid: AppDetails.shared.basketModel.venderID, authtoken: AppDetails.shared.oloUserAuthToken), body: basketProduct, bodyMM: basketProductMM) { (basket, error) in
                DispatchQueue.main.async {
                    if basket != nil && (basket?.id ?? "").count > 0 {
                        AppDetails.shared.basketModel.setBasketResponse(basket!)
                        AppDetails.shared.basketModel.basketMMRequestDetails = basketProductMM
                        APPSHARE.hideHud(for: self.view)
                        if isBuyNow { //Move to Basket Screen
                            if isMayWeSuggest {
                                self.segueToPaymentOptionScreen()
                            } else {
                                self.segueToBasket(isBackEnable: false, isBackToMenuScreen: true)
                            }
                        }else { //Move to Menu Screen
                            if isMayWeSuggest {
                                self.navigationController?.popViewController(animated: true)
                            } else {
                                self.segueToOLOMenuViewController()
                            }
                        }
                    }else if error != nil {
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessageErrorMessage(error!)
                    }else {
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessage(OloDisplayText.textSomeWentWrong())
                    }
                }
            }
        }
    }
    //API Go to Menu Page
    fileprivate func SegueToMenuOrChangeStore(_ storeCode: String, _ isChangeStore: Bool, _ oloStoreDetails: Restaurant?, _ storeInformation: PXStoreInformation, _ isNavToDetail: Bool, orderType: OloOrderType, deliveryAddress:ModelDeliveryAddress?, completionHandler: @escaping ((_ storeCode:Int, _ status:Bool) -> Void)) {
        if isChangeStore {
            if let restaurant = oloStoreDetails {
                self.changeStoreForBasket(storeCode: restaurant.id, storeInfo: storeInformation, oloStoreDetails: restaurant, completionHandler:completionHandler)
            }else {
                completionHandler(0,false)
                APPSHARE.hideHud(for: self.view)
                self.alertMessage(OloDisplayText.textAlertStoreCodeNotFound())
            }
        }else if let restaurant = oloStoreDetails, isNavToDetail {
            completionHandler(0,false)
            APPSHARE.hideHud(for: self.view)
            self.segueToMenuOrDetailsScreen(storeCode: restaurant.id, storeInfo: storeInformation, oloStoreDetails: restaurant, isNavToDetail: isNavToDetail, orderType: orderType, deliveryAddress:deliveryAddress)
        }else {
            if OnlineOrderClientAPI.isMMEnabled {
                if OnlineOrderClientAPI.isApiMMProvider {
                    if let providerStoreDetails = oloStoreDetails , OnlineOrderClientAPI.isMMEnabled, let serviceChannels = providerStoreDetails.serviceChannels, (providerStoreDetails.status ?? false) { //MM
                        if OnlineOrderClientAPI.isMMTakeOutEnabled, let serviceChannel:ServiceChannel = serviceChannels.first(where: {($0.serviceChannelId ?? 0) == 1}) { //Takeout
                            AppDetails.shared.modelMultipleProvidersStore.append(ModelOrderServices.init(provider: ApiOnlineOrderProvider.monkeyMedia, restaurant: providerStoreDetails, type: orderServiceType.takeout, title:OloDisplayText.textMMOrderServiceTakeoutTitle(), image: OloDisplayText.textMMOrderServiceTakeoutImage(), serviceChannel:serviceChannel))
                        }
                        if OnlineOrderClientAPI.isMMCateringEnabled, let serviceChannel:ServiceChannel = serviceChannels.first(where: {($0.serviceChannelId ?? 0) == 2}) { //Catering
                            AppDetails.shared.modelMultipleProvidersStore.append(ModelOrderServices.init(provider: ApiOnlineOrderProvider.monkeyMedia, restaurant: providerStoreDetails, type: orderServiceType.catering, title:OloDisplayText.textMMOrderServiceCateringTitle(), image: OloDisplayText.textMMOrderServiceCateringImage(), serviceChannel:serviceChannel))
                        }
                    }
                    completionHandler(0,false)
                    APPSHARE.hideHud(for: self.view)
                    var indexSelection = 0
                    if AppDetails.shared.basketModel.basketStoreInfo.code == storeInformation.code {
                        if AppDetails.shared.basketModel.basketIsMMProvider {
                            indexSelection = AppDetails.shared.modelMultipleProvidersStore.lastIndex(where: {$0.type == ((AppDetails.shared.basketModel.basketMMServiceChannel?.serviceChannelId ?? 0) == 1 ? orderServiceType.takeout : orderServiceType.catering) && $0.provider == ApiOnlineOrderProvider.monkeyMedia}) ?? 0
                        }else {
                            indexSelection = AppDetails.shared.modelMultipleProvidersStore.lastIndex(where: {$0.type == orderServiceType.takeout && $0.provider == ApiOnlineOrderProvider.olo}) ?? 0
                        }
                    }
                    showOrderServicePopup(storeInformation, isNavToDetail: isNavToDetail, selectedType: indexSelection, completionHandler: completionHandler)
                }else {
                    if let providerStoreDetails = oloStoreDetails , OnlineOrderClientAPI.isOlOEnabled { //OlO
                        AppDetails.shared.modelMultipleProvidersStore.append(ModelOrderServices.init(provider: ApiOnlineOrderProvider.olo, restaurant: providerStoreDetails, type: orderServiceType.takeout, title:OloDisplayText.textOlOOrderServiceTakeoutTitle(), image: OloDisplayText.textOlOOrderServiceTakeoutImage(), serviceChannel:nil))
                    }
                    OnlineOrderClientAPI.setApiOnlineOrderProvider(.monkeyMedia) //set Monkey Media for Retrieve store
                    callApiForStoreIDFromPaytronix(storeCode: storeCode, storeInformation: storeInformation, isChangeStore: isChangeStore, isNavToDetail: isNavToDetail, orderType: orderType, deliveryAddress: deliveryAddress, completionHandler: completionHandler)
                }
            }else {
                if let restaurant = oloStoreDetails {
                    if deliveryAddress != nil {
                        self.getBasketID(storeCode: restaurant.id, storeInfo: storeInformation, oloStoreDetails: restaurant, isNavToDetail: isNavToDetail, orderType: orderType, deliveryAddress: deliveryAddress, completionHandler: completionHandler)
                        /*
                        //yyyymmdd hh:mm
                        let deliveryCoverage = ModelCheckdeliverycoverage.init(handoffmode: restaurant.candeliver ? "delivery" : "dispatch", timewantedmode: "asap", timewantedutc: "", street: deliveryAddress!.streetaddress, city: deliveryAddress!.city, zipcode: deliveryAddress!.zipcode)
                        APPSHARE.showHud(withMessage: "", for: self.view)
                        OnlineOrderRestaurantAPI.restaurantsRestaurantIdCheckdeliverycoveragePost(restaurantId: restaurant.id, body: deliveryCoverage) { (deliveryCoverageResponse, error) in
                            DispatchQueue.main.async {
                                if deliveryCoverageResponse != nil {
                                    if deliveryCoverageResponse!.candeliver {
                                        self.getBasketID(storeCode: restaurant.id, storeInfo: storeInformation, oloStoreDetails: restaurant, isNavToDetail: isNavToDetail, deliveryAddress: deliveryAddress, completionHandler: completionHandler)
                                    }else {
                                        completionHandler(0,false)
                                        APPSHARE.hideHud(for: self.view)
                                        self.alertMessage(OloDisplayText.themeOneNewOrderFlowAddressUnavailableNewAlert())
                                        //self.alertMessage(((deliveryCoverageResponse?.message ?? "").containsIgnoringCase(OloDisplayText.themeOneNewOrderFlowAddressUnavailableAlertOne())) ? "Sorry we do not deliver to this address at the moment.  Please enter a different address or place order for pickup" : (deliveryCoverageResponse?.message ?? "").containsIgnoringCase(OloDisplayText.themeOneNewOrderFlowAddressUnavailableAlertTwo()) ? OloDisplayText.themeOneNewOrderFlowAddressUnavailableNewAlert(): (deliveryCoverageResponse?.message ?? ""))
                                    }
                                }else if error != nil {
                                    completionHandler(0,false)
                                    APPSHARE.hideHud(for: self.view)
                                    self.alertMessageErrorMessage(error!)
                                }else {
                                    completionHandler(0,false)
                                    APPSHARE.hideHud(for: self.view)
                                    self.alertMessage(OloDisplayText.textSomeWentWrong())
                                }
                            }
                        }*/
                    }else {
                        self.getBasketID(storeCode: restaurant.id, storeInfo: storeInformation, oloStoreDetails: restaurant,  isNavToDetail: isNavToDetail, orderType: orderType, completionHandler:completionHandler)
                    }
                }else {
                    completionHandler(0,false)
                    APPSHARE.hideHud(for: self.view)
                    self.alertMessage(OloDisplayText.textAlertStoreCodeNotFound())
                }
            }
        }
    }
    func showOrderServicePopup(_ storeInformation: PXStoreInformation, isNavToDetail: Bool, selectedType:Int, completionHandler: @escaping ((_ storeCode:Int, _ status:Bool) -> Void)) {
        if AppDetails.shared.modelMultipleProvidersStore.count > 0 {
            func didSelectOrderServiceType(_ index:Int) {
                if AppDetails.shared.modelMultipleProvidersStore.count > index {
                    let serviceType:ModelOrderServices = AppDetails.shared.modelMultipleProvidersStore[index]
                    //AppDetails.shared.modelMultipleProvidersStore = []
                    if serviceType.provider == .olo {
                        if let restaurant = serviceType.restaurant {
                            APPSHARE.showHud(withMessage: "", for: self.view)
                            self.getBasketID(storeCode: serviceType.restaurant?.id ?? 0, storeInfo: storeInformation, oloStoreDetails: restaurant,  isNavToDetail: isNavToDetail, orderType: .none, completionHandler:completionHandler)
                        }else {
                            APPSHARE.hideHud(for: self.view)
                            self.alertMessage(OloDisplayText.textSomeWentWrong())
                        }
                        
                    }else if serviceType.provider == .monkeyMedia {
                        OnlineOrderClientAPI.setApiOnlineOrderProvider(.monkeyMedia)
                        let oldBasket = AppDetails.shared.basketModel.copy() as? ModelBasketScreen
                        if ((AppDetails.shared.basketModel.basketID.count > 0 || (AppDetails.shared.basketModel.basketMMServiceChannel?.serviceChannelId ?? 0) > 0) && AppDetails.shared.basketModel.basketStoreInfo.code == storeInformation.code && AppDetails.shared.basketModel.basketOloStoreInfo?.id == serviceType.restaurant?.id ?? 0) { //Menu
                            self.segueToOLOMenuViewController()
                        }else {
                            AppDetails.shared.basketModel = ModelBasketScreen.init( serviceType.restaurant?.id ?? 0, basketID: "")
                            AppDetails.shared.basketModel.basketStoreInfo = storeInformation
                            AppDetails.shared.basketModel.basketOloStoreInfo = serviceType.restaurant
                            AppDetails.shared.basketModel.basketMMServiceChannel = serviceType.serviceChannel
                            let basketDetails = ModelBasket.init()
                            basketDetails.vendorid = serviceType.restaurant?.id ?? 0
                            AppDetails.shared.basketModel.setBasketResponse(basketDetails)
                            //OLOCateringPickupDeliveryViewController
                            let controller = OLOCateringPickupDeliveryViewController()
                            controller.modelBasket = oldBasket!
                            self.navigationController?.pushViewController(controller, animated: true)
                        }
                    }
                }
            }
            if OloValues.valueMMIsOrderServiceSelectionNewDesign() {
                didSelectOrderServiceType(selectedType)
            }else {
                let arrayActions = AppDetails.shared.modelMultipleProvidersStore.map({$0.image})
                let orderServicePopup = OLOViewOrderServices.init(frame: APPSHARE.window.bounds) { (index, selectedImage) in
                    if let index = arrayActions.firstIndex(of: selectedImage) {
                        didSelectOrderServiceType(index)
                    }
                }
                APPSHARE.window.addSubview(orderServicePopup)
                orderServicePopup.showOrderTypes(arrayActions)
            }
        }else {
            self.alertMessage(OloDisplayText.textAlertStoreCodeNotFound())
        }
    }
    func callApiForStoreIDFromPaytronix(storeCode: String, storeInformation: PXStoreInformation, isChangeStore:Bool, isNavToDetail: Bool, orderType: OloOrderType, deliveryAddress:ModelDeliveryAddress?, completionHandler:@escaping ((_ storeCode:Int, _ status:Bool) -> Void)) {
        if let oloStoreDetails = self.getStoreDetailsFromExistData(0, extRef: OnlineOrderClientAPI.isApiMMProvider ? (storeInformation.externalStoreNumber ?? "") : storeCode, isExtRef: true) {
            SegueToMenuOrChangeStore(storeCode, isChangeStore, oloStoreDetails, storeInformation, isNavToDetail, orderType: orderType, deliveryAddress: deliveryAddress, completionHandler: completionHandler)
        }else if(APPSHARE.isNetworkReachable()) {
            APPSHARE.showHud(withMessage: "", for: self.view)
            OnlineOrderRestaurantAPI.restaurantsByrefStoreNumberGet(storeNumber: storeCode, externalStoreNumber: storeInformation.externalStoreNumber ?? "") { (restaurant, error) in
                DispatchQueue.main.async {
                    if restaurant != nil {
                        if OnlineOrderClientAPI.isApiMMProvider {
                            if !AppDetails.shared.modelMMStoreList.contains(where: {$0.id == restaurant!.id}) {
                                AppDetails.shared.modelMMStoreList.append(restaurant!)
                            }
                        }else {
                            if !AppDetails.shared.modelOlOStoreList.contains(where: {$0.id == restaurant!.id}) {
                                AppDetails.shared.modelOlOStoreList.append(restaurant!)
                            }
                        }
                        self.SegueToMenuOrChangeStore(storeCode, isChangeStore, restaurant!, storeInformation, isNavToDetail, orderType: orderType, deliveryAddress: deliveryAddress, completionHandler: completionHandler)
                    }else if error != nil {
                        func showErrorAlert() {
                            completionHandler(0,false)
                            APPSHARE.hideHud(for: self.view)
                            self.alertMessageErrorMessage(error!)
                        }
                        if isChangeStore {
                            showErrorAlert()
                        }else if OnlineOrderClientAPI.isApiMultipleProvider {
                            self.SegueToMenuOrChangeStore(storeCode, isChangeStore, nil, storeInformation, isNavToDetail, orderType: orderType, deliveryAddress: deliveryAddress, completionHandler: completionHandler)
                        }else {
                            showErrorAlert()
                        }
                    }else {
                        func showErrorAlert() {
                            completionHandler(0,false)
                            APPSHARE.hideHud(for: self.view)
                            self.alertMessage(OloDisplayText.textAlertStoreCodeNotFound())
                        }
                        if isChangeStore {
                            showErrorAlert()
                        }else if OnlineOrderClientAPI.isApiMultipleProvider {
                            self.SegueToMenuOrChangeStore(storeCode, isChangeStore, nil, storeInformation, isNavToDetail, orderType: orderType, deliveryAddress: deliveryAddress, completionHandler: completionHandler)
                        }else {
                            showErrorAlert()
                        }
                    }
                }
            }
        }else {
            completionHandler(0,false)
            APPSHARE.hideHud(for: self.view)
        }
    }
    func getOrderOnlineStoreIDFromPaytronix(storeCode: String, storeInformation: PXStoreInformation, isChangeStore:Bool, isNavToDetail: Bool, orderType: OloOrderType, deliveryAddress:ModelDeliveryAddress?, completionHandler:@escaping ((_ storeCode:Int, _ status:Bool) -> Void)) {
        if !(isChangeStore || isNavToDetail) && OnlineOrderClientAPI.isApiMultipleProvider {
            AppDetails.shared.modelMultipleProvidersStore = []
            OnlineOrderClientAPI.setApiOnlineOrderProvider(.olo) //set OlO for Retrieve store
        }
        callApiForStoreIDFromPaytronix(storeCode: storeCode, storeInformation: storeInformation, isChangeStore: isChangeStore, isNavToDetail: isNavToDetail, orderType: orderType, deliveryAddress: deliveryAddress, completionHandler: completionHandler)
    }
    //MARK: OloBasketID Api
    func getBasketID(storeCode:Int, storeInfo:PXStoreInformation, oloStoreDetails:Restaurant, isNavToDetail: Bool,  isFromeDetail: Bool = false, orderType: OloOrderType, deliveryAddress:ModelDeliveryAddress? = nil, completionHandler:@escaping ((_ storeCode:Int, _ status:Bool) -> Void)) {
        let isMMProvider = OnlineOrderClientAPI.isApiMMProvider
        OnlineOrderClientAPI.setApiOnlineOrderProvider(.olo)
        if AppDetails.shared.basketModel.venderID != storeCode {
            if(APPSHARE.isNetworkReachable()) {
                if OloValues.valueMMIsOrderServiceSelectionNewDesign() {
                    AppDetails.shared.basketModel = ModelBasketScreen.init(storeCode, basketID: "")
                    AppDetails.shared.basketModel.basketStoreInfo = storeInfo
                    AppDetails.shared.basketModel.basketOloStoreInfo = oloStoreDetails
                    guestInfo = GuestUserFields.init(firstName: "", lastName: "", email: "", phone: "")
                    completionHandler(storeCode,true)
                    self.segueToMenuOrDetailsScreen(storeCode: storeCode, storeInfo: storeInfo, oloStoreDetails: oloStoreDetails, isNavToDetail: isNavToDetail, orderType: orderType, deliveryAddress:deliveryAddress)
                }else {
                    APPSHARE.showHud(withMessage: "", for: self.view)
                    OnlineOrderBasketAPI.basketsCreatePost(body: ModelCreatebasket.init(vendorid: storeCode, authtoken: AppDetails.shared.oloUserAuthToken)) { (basket, error) in
                        DispatchQueue.main.async {
                            if basket != nil && (basket?.id ?? "").count > 0 {
                                AppDetails.shared.basketModel = ModelBasketScreen.init(storeCode, basketID: (basket?.id ?? ""))
                                AppDetails.shared.basketModel.basketStoreInfo = storeInfo
                                AppDetails.shared.basketModel.basketOloStoreInfo = oloStoreDetails
                                AppDetails.shared.basketModel.setBasketResponse(basket!)
                                guestInfo = GuestUserFields.init(firstName: "", lastName: "", email: "", phone: "")
                                completionHandler(storeCode,true)
                                self.segueToMenuOrDetailsScreen(storeCode: storeCode, storeInfo: storeInfo, oloStoreDetails: oloStoreDetails, isNavToDetail: isNavToDetail, orderType: orderType, deliveryAddress:deliveryAddress)
                            }else if error != nil {
                                OnlineOrderClientAPI.setApiOnlineOrderProvider(isMMProvider ? .monkeyMedia :.olo)
                                APPSHARE.hideHud(for: self.view)
                                self.alertMessageErrorMessage(error!)
                            }else {
                                OnlineOrderClientAPI.setApiOnlineOrderProvider(isMMProvider ? .monkeyMedia :.olo)
                                APPSHARE.hideHud(for: self.view)
                                self.alertMessage(OloDisplayText.textSomeWentWrong())
                            }
                        }
                    }
                }
            }
        }else {
            DispatchQueue.main.async {
                completionHandler(storeCode,true)
                self.segueToMenuOrDetailsScreen(storeCode: storeCode, storeInfo: storeInfo, oloStoreDetails: oloStoreDetails, isNavToDetail: isNavToDetail, orderType: orderType, deliveryAddress:deliveryAddress)
            }
        }
    }
    func changeStoreForBasket(storeCode:Int, storeInfo:PXStoreInformation, oloStoreDetails:Restaurant, completionHandler:@escaping ((_ storeCode:Int, _ status:Bool) -> Void)) {
        if AppDetails.shared.basketModel.venderID != storeCode {
            var orderService:ModelOrderServices?
            if OnlineOrderClientAPI.isApiMMProvider {
                if let serviceChannel = oloStoreDetails.serviceChannels?.first(where: {$0.serviceChannelId == AppDetails.shared.basketModel.basketMMServiceChannel?.serviceChannelId}) {
                    orderService = ModelOrderServices.init(provider: ApiOnlineOrderProvider.monkeyMedia, restaurant: oloStoreDetails, type: serviceChannel.serviceChannelId == 1 ? orderServiceType.takeout : orderServiceType.catering, title:serviceChannel.serviceChannelId == 1 ? OloDisplayText.textMMOrderServiceTakeoutTitle() : OloDisplayText.textMMOrderServiceCateringTitle(), image: serviceChannel.serviceChannelId == 1 ?  OloDisplayText.textMMOrderServiceTakeoutImage() : OloDisplayText.textMMOrderServiceCateringImage(), serviceChannel:serviceChannel)
                }else {
                    completionHandler(0,false)
                    APPSHARE.hideHud(for: self.view)
                    self.alertMessage(OloDisplayText.textAlertStoreCodeNotFound())
                }
            }
            if(APPSHARE.isNetworkReachable()) {
                APPSHARE.showHud(withMessage: "", for: self.view)
                var basketRequest = ModelBasket.init()
                if let basketTemp = AppDetails.shared.basketModel.basketMMRequestDetails?.copy() as? ModelBasket {
                    basketRequest = basketTemp
                }
                basketRequest.vendorid = storeCode
                OnlineOrderBasketAPI.basketsBasketIdTransferPost(basketId: AppDetails.shared.basketModel.basketID, body: ModelBasketTransferPost.init(vendorid: storeCode), bodyMM: basketRequest) { (basketTransfer, error) in
                    DispatchQueue.main.async {
                        if basketTransfer != nil {
                            if basketTransfer!.basket != nil {
                                if OnlineOrderClientAPI.isApiMMProvider { //MM
                                    AppDetails.shared.basketModel.basketMMServiceChannel = orderService?.serviceChannel
                                    if let distributionType = orderService?.serviceChannel?.distributionTypes?.first(where: {$0.distributionTypeId == AppDetails.shared.basketModel.basketMMDistributionType?.distributionTypeId}), let orderGuide = distributionType.orderGuides?.first {
                                        AppDetails.shared.basketModel.basketMMDistributionType = distributionType
                                        AppDetails.shared.basketModel.basketMMOrderGuide = orderGuide
                                        AppDetails.shared.basketModel.venderID = storeCode
                                        AppDetails.shared.basketModel.isBasketMayWeSuggest = true
                                    }
                                }else {
                                    AppDetails.shared.basketModel = ModelBasketScreen.init(storeCode, basketID: basketTransfer?.basket?.id ?? "")
                                }
                                AppDetails.shared.basketModel.basketStoreInfo = storeInfo
                                AppDetails.shared.basketModel.basketOloStoreInfo = oloStoreDetails
                                AppDetails.shared.basketModel.basketMMRequestDetails = basketRequest
                                AppDetails.shared.basketModel.setBasketResponse(basketTransfer!.basket!)
                                completionHandler(storeCode,true)
//                                if (basketTransfer?.itemsnottransferred?.count ?? 0 > 0) {
//                                    self.dismiss(animated: true, completion: {
//                                        self.alertMessage(message: AppDetails.shared.basketModel.isBasketStatus ? "Some Items Couldn't be transferred, please recheck your cart for the missing products." : "Some Items Couldn't be transferred, please start order again.", complition: {
//                                            self.segueToBasket(isBackEnable: false)
//                                        })
//                                    })
//                                }
                                APPSHARE.hideHud(for: self.view)
                                self.actionNavigationCancel(UIButton())
                            } else if error != nil {
                                completionHandler(0,false)
                                APPSHARE.hideHud(for: self.view)
                                if let err = error as? ErrorResponse {
                                    switch(err) {
                                    case .error(_, let data, _, let errorOnlineOrder):
                                        if data != nil {
                                            if errorOnlineOrder != nil {
                                                self.alertMessage(errorOnlineOrder?.code == 41213 ? OloDisplayText.textItemNotAvailable() : errorOnlineOrder!.message)
                                            }else {
                                                do {
                                                    let errorResponse:ErrorOnlineOrder = try JSONDecoder().decode(ErrorOnlineOrder.self, from: data!)
                                                    self.alertMessage(errorResponse.message)
                                                }catch {
                                                    self.alertMessage(error.localizedDescription)
                                                }
                                            }
                                        }else {
                                            self.alertMessage(error?.localizedDescription ?? "")
                                        }
                                        break
                                    }
                                } else {
                                    self.alertMessageErrorMessage(error!)
                                }
                            } else {
                                completionHandler(0,false)
                                APPSHARE.hideHud(for: self.view)
                                self.alertMessage(OloDisplayText.textSomeWentWrong())
                            }
                        }else if error != nil {
                            completionHandler(0,false)
                            APPSHARE.hideHud(for: self.view)
                            self.alertMessageErrorMessage(error!)
                        }else {
                            completionHandler(0,false)
                            APPSHARE.hideHud(for: self.view)
                            self.alertMessage(OloDisplayText.textSomeWentWrong())
                        }
                    }
                }
            }else {
                completionHandler(0,false)
            }
        }else {
            DispatchQueue.main.async {
                if AppDetails.shared.basketModel.basketStoreInfo.code != storeInfo.code {
                    AppDetails.shared.basketModel.basketStoreInfo = storeInfo
                }
                completionHandler(storeCode,false)
                APPSHARE.hideHud(for: self.view)
                //self.handlerChangeStore(String(storeCode),storeInfo)
                self.actionNavigationCancel(UIButton())
            }
        }
    }
    //MARK: API Add Tip
    func apiOloAddTip(amount:Double, complitionHandler:@escaping ((_ status:Bool)-> Void)) {
        if(APPSHARE.isNetworkReachable()) {
            var basketRequest = ModelBasket.init()
            if let basketTemp = AppDetails.shared.basketModel.basketMMRequestDetails?.copy() as? ModelBasket {
                basketRequest = basketTemp
            }
            basketRequest.tip = amount
            APPSHARE.showHud(withMessage: "", for: self.view)
            OnlineOrderBasketAPI.basketsBasketIdTipPut(basketId: AppDetails.shared.basketModel.basketID, body: ModelUpdateBasketTipPost.init(amount: amount), bodyMM: basketRequest) { (basket, error) in
                DispatchQueue.main.async {
                    if basket != nil && (basket?.id ?? "").count > 0 {
                        AppDetails.shared.basketModel.setBasketResponse(basket!)
                        AppDetails.shared.basketModel.basketMMRequestDetails = basketRequest
                        complitionHandler(true)
                    }else if error != nil {
                        complitionHandler(false)
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessageErrorMessage(error!)
                    }else {
                        complitionHandler(false)
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessage(OloDisplayText.textSomeWentWrong())
                    }
                }
            }
        }else {
            complitionHandler(false)
        }
    }
    //Get Olo Store Details from Local
    func getStoreDetailsFromExistData(_ vendorID:Int, extRef:String, isExtRef:Bool) -> Restaurant? {
        var modelOlOStoreListTemp:[Restaurant] = []
        if OnlineOrderClientAPI.isApiOlOProvider {
             modelOlOStoreListTemp = AppDetails.shared.modelOlOStoreList
        }else if OnlineOrderClientAPI.isApiMMProvider {
            modelOlOStoreListTemp = AppDetails.shared.modelMMStoreList
        }
        if modelOlOStoreListTemp.count > 0 {
            if isExtRef {
                if OnlineOrderClientAPI.isApiMMProvider {
                    if let index = modelOlOStoreListTemp.firstIndex(where: {$0.id == Int(extRef) ?? 0}), extRef.count > 0 {
                        return modelOlOStoreListTemp[index]
                    }
                }else {
                    if let index = modelOlOStoreListTemp.firstIndex(where: {$0.extref == extRef}), extRef.count > 0 {
                        return modelOlOStoreListTemp[index]
                    }
                }
            }else if vendorID > 0 {
                if let index = modelOlOStoreListTemp.firstIndex(where: {$0.id == vendorID}) {
                    return modelOlOStoreListTemp[index]
                }
            }
        }
        return nil
    }
    //API Olo Store Details
    func getOloStoreDetails(oloStoreCode: Int, completionHandler:@escaping ((_ storeDetails:Restaurant?, _ status:Bool) -> Void)) {
        if let oloStoreDetails = self.getStoreDetailsFromExistData(oloStoreCode, extRef: "", isExtRef: false) {
            completionHandler(oloStoreDetails,true)
        }else if(APPSHARE.isNetworkReachable()) {
            APPSHARE.showHud(withMessage: "", for: self.view)
            OnlineOrderRestaurantAPI.restaurantsRestaurantIdGet(restaurantId: oloStoreCode) { (restaurant, error) in
                DispatchQueue.main.async {
                    if restaurant != nil {
                        if OnlineOrderClientAPI.isApiMMProvider {
                            if !AppDetails.shared.modelMMStoreList.contains(where: {$0.id == restaurant!.id}) {
                                AppDetails.shared.modelMMStoreList.append(restaurant!)
                            }
                        }else {
                            if !AppDetails.shared.modelOlOStoreList.contains(where: {$0.id == restaurant!.id}) {
                                AppDetails.shared.modelOlOStoreList.append(restaurant!)
                            }
                        }
                        completionHandler(restaurant,true)
                    }else if error != nil {
                        completionHandler(nil,false)
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessageErrorMessage(error!)
                    }else {
                        completionHandler(nil,false)
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessage(OloDisplayText.textAlertStoreCodeNotFound())
                    }
                }
            }
        }else {
            completionHandler(nil,false)
            APPSHARE.hideHud(for: self.view)
            self.alertMessage(OloDisplayText.textAlertStoreCodeNotFound())
        }
    }
    //Order
    func callOrderThisAgainFromOrderPage(orderStatus:ModelOrderstatus, isBackEnable:Bool, storeInfo:PXStoreInformation, oloStoreDetails:Restaurant, isMonkeyMediaProvider:Bool, basketRequest:ModelBasket? = nil) {
        if isMonkeyMediaProvider { //MM
            if let basketResponse = basketRequest, let serviceChannel = oloStoreDetails.serviceChannels?.first(where: {$0.serviceChannelId == basketResponse.serviceChannelId}) {
                let controller = OLOCateringPickupDeliveryViewController()
                controller.isOrderThisAgain = true
                controller.basketMMServiceChannel = serviceChannel
                controller.orderThisAgainDetails = (storeInfo,oloStoreDetails,basketResponse)
                self.navigationController?.pushViewController(controller, animated: true)
            }else {
                self.alertMessage(OloDisplayText.textSomeWentWrong())
            }
        }else { //OlO
            self.apiCreateBasketFromPreviousOrder(orderRef: ""/*orderStatus.orderref*/, orderID: orderStatus.id) { (vendorid, basketId, response) in
                self.segueToBasketWithSettings(vendorid: vendorid, basketId: basketId, storeInfo: storeInfo, basketResponse: response, isBackEnable: isBackEnable, oloStoreDetails: oloStoreDetails)
            }
        }
    }
    func segueToBasketWithSettings(vendorid:Int, basketId:String, storeInfo:PXStoreInformation, basketResponse:ModelBasket, isBackEnable:Bool, oloStoreDetails:Restaurant) {
        AppDetails.shared.basketModel = ModelBasketScreen.init(vendorid, basketID: basketId)
        AppDetails.shared.basketModel.basketStoreInfo = storeInfo
        AppDetails.shared.basketModel.basketOloStoreInfo = oloStoreDetails
        AppDetails.shared.basketModel.setBasketResponse(basketResponse)
        segueToBasket(isBackEnable: isBackEnable)
    }
    func segueToBasket(isBackEnable:Bool, isBackToMenuScreen:Bool = false, isFromHomePage:Bool = false) {
        let storyBoard = UIStoryboard.init(name: kOloStoryBoardName, bundle: nil)
        let oloBasketPage = storyBoard.instantiateViewController(withIdentifier: "OLOBasketViewController") as! OLOBasketViewController
        oloBasketPage.isBackEnable = isBackEnable
        oloBasketPage.isBackToMenuScreen = isBackToMenuScreen
        oloBasketPage.isFromHomePage = isFromHomePage
        self.navigationController?.pushViewController(oloBasketPage, animated: true)
    }
    @objc func segueToVehicleInfo() {
//        self.segueToPaymentOptionScreen()
        if (AppDetails.shared.basketModel.basketDetails?.customfields ?? []).count > 0 {
            let oloBasketPage = self.storyboard?.instantiateViewController(withIdentifier: "OLOVehicleInfoViewController") as! OLOVehicleInfoViewController
            let oloNewVehicleInfo = self.storyboard?.instantiateViewController(withIdentifier: "OLONewVehicleInfoController") as! OLONewVehicleInfoController
            self.navigationController?.pushViewController(AppSettings.shared()?.isCurbsideVehicleInfoWithTypeEnable() ?? false ? oloNewVehicleInfo : oloBasketPage, animated: true)
        }else {
            self.segueToPaymentOptionScreen()
        }
    }
    func segueToPaymentOptionScreen() {
        if OnlineOrderClientAPI.isApiMMProvider {
            let segueTO = self.storyboard?.instantiateViewController(withIdentifier: "OloPlaceOrderViewController") as! OloPlaceOrderViewController
            self.navigationController?.pushViewController(segueTO, animated: true)
        } else {
            var segueTO : UIViewController = self.storyboard?.instantiateViewController(withIdentifier: "OLOPaymentOptionsViewController") as! OLOPaymentOptionsViewController
            if ThemeOneSettingGlobal.isNewOrderFlowEnabled() {
                segueTO = self.storyboard?.instantiateViewController(withIdentifier: "OLOPaymentSelectionViewController") as! OLOPaymentSelectionViewController
            }
            self.navigationController?.pushViewController(segueTO, animated: true)
        }
    }
    func segueToPhoneNumberOrPlaceOrderScreen(_ billingschemes:ModelBillingscheme?, isExistingCard:Bool = false, creditCardDetails:CardIOCreditCardInfo?, issaveCreditCard:Bool = false, isPayByCash:Bool = false, modelCreditCard:ModelCreditCardList?, phoneNumber:String = "", seguePlaceOrder:Bool = false, guestUserFields : GuestUserFields?) {
        if(hasCards())
        {
            if (AppDetails.shared.basketModel.basketOloStoreInfo?.requiresphonenumber ?? false) && !seguePlaceOrder {
                let segueTO = self.storyboard?.instantiateViewController(withIdentifier: "OLOPhoneNumberViewController") as! OLOPhoneNumberViewController
                segueTO.billingschemes = billingschemes
                segueTO.isPayByCash = isPayByCash
                segueTO.modelCreditCard = modelCreditCard
                segueTO.isExistingCard = isExistingCard
                segueTO.issaveCreditCard = issaveCreditCard
                segueTO.creditCardDetails = creditCardDetails
                self.navigationController?.pushViewController(segueTO, animated: true)
            }else {
                let segueTO = self.storyboard?.instantiateViewController(withIdentifier: "OloPlaceOrderViewController") as! OloPlaceOrderViewController
                segueTO.billingschemes = billingschemes
                segueTO.isPayByCash = isPayByCash
                segueTO.modelCreditCard = modelCreditCard
                segueTO.isExistingCard = isExistingCard
                segueTO.issaveCreditCard = issaveCreditCard
                segueTO.creditCardDetails = creditCardDetails
                segueTO.phoneNumber = phoneNumber
                self.navigationController?.pushViewController(segueTO, animated: true)
            }
        }
        else
        {
            if(seguePlaceOrder)
            {
                let segueTO = self.storyboard?.instantiateViewController(withIdentifier: "OloPlaceOrderViewController") as! OloPlaceOrderViewController
                segueTO.billingschemes = billingschemes
                segueTO.isPayByCash = isPayByCash
                segueTO.modelCreditCard = modelCreditCard
                segueTO.isExistingCard = isExistingCard
                segueTO.issaveCreditCard = issaveCreditCard
                segueTO.creditCardDetails = creditCardDetails
                segueTO.phoneNumber = phoneNumber
                segueTO.guestInfo = guestUserFields
                self.navigationController?.pushViewController(segueTO, animated: true)
            }
            else
            {
                let segueTO = self.storyboard?.instantiateViewController(withIdentifier: "OLOPhoneNumberViewController") as! OLOPhoneNumberViewController
                segueTO.billingschemes = billingschemes
                segueTO.isPayByCash = isPayByCash
                segueTO.modelCreditCard = modelCreditCard
                segueTO.isExistingCard = isExistingCard
                segueTO.issaveCreditCard = issaveCreditCard
                segueTO.creditCardDetails = creditCardDetails
                self.navigationController?.pushViewController(segueTO, animated: true)
            }
        }
    }
    //Modified for Native OlO Guest User Flow: Guest Information
    @objc func apiCreateBasketFromPreviousOrder(orderRef:String,orderID:String, completionHandler: @escaping ((_ vendorid:Int, _ basketID:String, _ response:ModelBasket) -> Void)) {
        if(APPSHARE.isNetworkReachable()) {
            APPSHARE.showHud(withMessage: "", for: self.view)
            OnlineOrderBasketAPI.basketsCreatefromorderPost(body: ModelCreateBasketFromOrder.init(orderref: orderRef, id: orderID), authtoken: AppDetails.shared.oloUserAuthToken, completion: { (basket, error) in
                DispatchQueue.main.async {
                    if basket != nil && (basket?.id ?? "").count > 0 {
                        completionHandler((basket?.vendorid ?? 1), (basket?.id ?? ""), basket!)
                    }else if error != nil {
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessageErrorMessage(error!)
                    }else {
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessage(OloDisplayText.textSomeWentWrong())
                    }
                }
            })
        }
    }
    func callSaveFavouriteFromOrder(orderStatus:ModelOrderstatus, description:String, basketID:String, handler:((Bool) -> Void)? = nil) {
        if description.count > 0 {
            if basketID.count > 0 {
                self.apiSaveFavouritesFromOrder(basketid: basketID, description: description) { (status) in
                    if handler != nil {
                        handler!(status)
                    }
                }
            }else {
                self.apiCreateBasketFromPreviousOrder(orderRef: ""/*orderStatus.orderref*/, orderID: orderStatus.id) { (vendorid, basketId, response) in
                    self.apiSaveFavouritesFromOrder(basketid: basketId, description: description)
                }
            }
        }else {
            self.alertMessage(OloDisplayText.textOrderFavouriteNameCondition())
        }
    }
    @objc func apiSaveFavouritesFromOrder(basketid:String, description:String, handler:((Bool) -> Void)? = nil) {
        if(APPSHARE.isNetworkReachable()) {
            APPSHARE.showHud(withMessage: "", for: self.view)
            OnlineOrderUserAPI.usersAuthtokenFavesPost(authtoken: AppDetails.shared.oloUserAuthToken, body: ModelNewfave.init(basketid: basketid, description: description)) { (userFaves, error) in
                DispatchQueue.main.async {
                    if userFaves != nil {
                        APPSHARE.hideHud(for: self.view)
                        AppDetails.shared.showAlertMessageOlo(message: OloDisplayText.textFavoritePopup(), handler: {
                            if handler != nil {
                                handler!(true)
                            }
                        })
                    }else if error != nil {
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessageErrorMessage(error!)
                    }else {
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessage(OloDisplayText.textSomeWentWrong())
                    }
                }
            }
        }
    }
    //MARK: Favourite
        func apiGetFavouriteList(_ reload:Bool, complitionHandler:@escaping (([String]) -> Void)) {
            if OnlineOrderClientAPI.isApiOlOProvider {
                if reload {
                    if(APPSHARE.isNetworkReachable()) {
                        OnlineOrderRestaurantAPI.usersAuthtokenFavelocationsGet(authtoken: AppDetails.shared.oloUserAuthToken) { (response, error) in
                            DispatchQueue.main.async {
                                if response != nil {
                                    AppDetails.shared.arrayOloFavouriteStoreList = response?.favelocations ?? []
                                    self.getOloFavouriteExtensionList(fromFavourite: true, complitionHandler: complitionHandler)
                                }else if error != nil {
                                    complitionHandler([])
                                    APPSHARE.hideHud(for: self.view)
                                    self.alertMessageErrorMessage(error!)
                                }else {
                                    complitionHandler([])
                                    APPSHARE.hideHud(for: self.view)
                                    self.alertMessage(OloDisplayText.textAlertStoreCodeNotFound())
                                }
                            }
                        }
                    }
                    
                }else {
                    self.getOloFavouriteExtensionList(fromFavourite: true, complitionHandler: complitionHandler)
                }
            }else {
                complitionHandler([])
            }
        }
    @objc func apiGetOloStoreList(complitionHandler:@escaping (([String]) -> Void)) {
        if(APPSHARE.isNetworkReachable()) {
            OnlineOrderRestaurantAPI.restaurantsGet { (restaurantList, error) in
                DispatchQueue.main.async {
                    if restaurantList != nil && restaurantList!.count > 0 {
                        AppDetails.shared.isGetOlOAllStore = true
                        AppDetails.shared.modelOlOStoreList = restaurantList ?? []
                        self.getOloFavouriteExtensionList(fromFavourite: false, complitionHandler: complitionHandler)
                    }else if error != nil {
                        complitionHandler([])
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessageErrorMessage(error!)
                    }else {
                        complitionHandler([])
                        APPSHARE.hideHud(for: self.view)
                        let alertMsg = OloDisplayText.textNoLocationFound()
                        self.alertMessage(alertMsg)
                    }
                }
            }
        }else {
            complitionHandler([])
        }
    }
    func apiGetOloAllRestaurantsList(complitionHandler:@escaping (([Restaurant]) -> Void)) {
        if AppDetails.shared.modelOlOStoreList.count <= 0 || !AppDetails.shared.isGetOlOAllStore {
            if(APPSHARE.isNetworkReachable()) {
                OnlineOrderRestaurantAPI.restaurantsGet { (restaurantList, error) in
                    DispatchQueue.main.async {
                        if restaurantList != nil && restaurantList!.count > 0 {
                            AppDetails.shared.isGetOlOAllStore = true
                            AppDetails.shared.modelOlOStoreList = restaurantList ?? []
                            complitionHandler(AppDetails.shared.modelOlOStoreList)
                        }else if error != nil {
                            complitionHandler(AppDetails.shared.modelOlOStoreList)
                            APPSHARE.hideHud(for: self.view)
                            self.alertMessageErrorMessage(error!)
                        }else {
                            complitionHandler(AppDetails.shared.modelOlOStoreList)
                            APPSHARE.hideHud(for: self.view)
                            let alertMsg = OloDisplayText.textNoLocationFound()
                            self.alertMessage(alertMsg)
                        }
                    }
                }
            }else {
                complitionHandler(AppDetails.shared.modelOlOStoreList)
            }
        }else {
            complitionHandler(AppDetails.shared.modelOlOStoreList)
        }
    }
    @objc func getOloFavouriteExtensionList(fromFavourite:Bool, complitionHandler:@escaping (([String]) -> Void)) {
        let arrayFavourite = AppDetails.shared.arrayOloFavouriteStoreList
        if arrayFavourite.count > 0 {
            let arrayOloStoreList = AppDetails.shared.modelOlOStoreList
            if arrayOloStoreList.count > 0 {
                var arrayFavouriteResult:[String] = []
                for item in arrayFavourite {
                    if let store = arrayOloStoreList.first(where: {$0.id == item.vendorid}) {
                        arrayFavouriteResult.append(store.extref)
                    }
                }
                complitionHandler(arrayFavouriteResult)
            }else {
                if fromFavourite {
                    self.apiGetOloStoreList(complitionHandler: complitionHandler)
                }else {
                    complitionHandler([])
                }
            }
        }else {
            complitionHandler([])
        }
    }
    func apiUpdateRecentOrderListToLocal(complition:@escaping ((_ status:Bool) -> Void)) {
        //Call Recent Order Api for Re Order Popup and Recommended Menu
        if APPSHARE.isNetworkReachable() && AppDetails.shared.isCallRecentOrderApiToLocalOnce && (OloValues.IsOlORecommendedMenuListEnable() || OloValues.IsOlOReorderPopupEnable()) && OnlineOrderClientAPI.isOlOEnabled {
            AppDetails.shared.isCallRecentOrderApiToLocalOnce = false
            let currentProvider = OnlineOrderClientAPI.currentProvider
            OnlineOrderClientAPI.setApiOnlineOrderProvider(.olo)
            APPSHARE.showHud(withMessage: "", for: self.view)
            OnlineOrderClientAPI.setApiOnlineOrderProvider(currentProvider)
            OnlineOrderUserAPI.usersAuthtokenRecentordersGet(authtoken: AppDetails.shared.oloUserAuthToken) { (recentOrder, error) in
                DispatchQueue.main.async {
                    if recentOrder != nil {
                        AppDetails.shared.oloRecentOrderList = recentOrder?.orders ?? []
                        complition(true)
                    }else if error != nil {
                        print("Error: Recent Order Api error IsOlORecommendedMenuListEnable | IsOlOReorderPopupEnable:")
                        complition(false)
                    }else {
                        self.alertMessage(OloDisplayText.textSomeWentWrong())
                        print("Error: Recent Order Api error IsOlORecommendedMenuListEnable | IsOlOReorderPopupEnable - \(OloDisplayText.textSomeWentWrong())")
                        complition(false)
                    }
                    //APPSHARE.hideHud(for: self.view)
                    OnlineOrderClientAPI.setApiOnlineOrderProvider(currentProvider)
                }
            }
        }else {
            complition(false)
        }
    }
    //MARK:- API SSO Login
    @objc func apiOloSSOLoginAuth(_ account:PXStoredAccount,  complitionHandler: @escaping ((_ authToken:String, _ printedCardNumber:String) -> Void)) {
        APPSHARE.showHud(withMessage: APPSHARE.hudView.labelText, for: APPSHARE.window)
        if account.oauthAuthentication.expirationDate.timeIntervalSince1970 > Date().timeIntervalSince1970 {
            self.apiOloSSOLoginGrand(account, authorizationGrant: account.oauthAuthentication.accessToken, complitionHandler: complitionHandler)
        }else {
            let printedCardNumber = account.printedCardNumber
            let ssoAccount = APPSHARE.modelAPI.storedAccount(forPrintedCardNumber: printedCardNumber)
            let onSuccess = {(guestTokenResponse: PXOAuthAuthentication?) -> Void in
                self.apiOloSSOLoginGrand(account, authorizationGrant: guestTokenResponse?.accessToken ?? "", complitionHandler: complitionHandler)
            }
            let onError = {(error: Error?) -> Void in
                if (error?.localizedDescription ?? "") != "The Internet connection appears to be offline." {
                    self.alertMessage("Error\n\(error?.localizedDescription ?? "")")
                }
                APPSHARE.hideHudForEmptyView()
            }
            APPSHARE.modelAPI.directAPI.oauth.refreshToken(ssoAccount!.oauthAuthentication.refreshToken, scope: ["user_read", "account_read"], onSuccess: onSuccess, onError: onError)
        }
        //Set Olo Auth Token Static
        /*APPSHARE.accountAdded(account)
         APPSHARE.currentAccount = account
         let testAuthToken = "PDPKzIhJYmnKHYxIZHGah3YEAZoZoW7S"
         AppDetails.shared.oloAuthToken(authToken: testAuthToken, printedCardNumber: account.printedCardNumber, isDefault: true)
         complitionHandler(testAuthToken, account.printedCardNumber)*/
    }
    @objc func apiOloSSOLoginGrand(_  account:PXStoredAccount,  authorizationGrant:String, complitionHandler: @escaping ((_ authToken:String, _ printedCardNumber:String) -> Void)) {
        let merchantID:Int = (Int)(AppSettings.shared().merchantID())
        let scopeAray = ["user_read","user_write","account_read","account_write"]
        let ssoService = PaytronixAppDelegate.api().directAPI.ssoSetup
        var clientIDString:String = AppSettings.shared().oLoClientID()
        if(APPSHARE.isThirdPartySSOPreloadEnabled) {
            clientIDString = AppSettings.shared().thirdPartySSOClientID(0)
        }
        ssoService?.requestAuthorizationGrant (forSSO: account.username, merchantID:(String)(merchantID), response_type: "code", refresh_token: authorizationGrant, thirdPartyIntegration: clientIDString,scope: scopeAray, onSuccess:  { (response: PXSSOResponseParser?) -> Void in
            ssoService?.requestGuestToken (forOLO: "authorization_code", scope: scopeAray, client_id:"\(AppSettings.shared().oLoClientID() as String);mid=\(UInt(AppSettings.shared().merchantID()));ctc=\(UInt(AppSettings.shared().cardTemplateCode()))"
                , client_secret: AppSettings.shared().oloSecret(), code: response?.authorizationGrantToken, redirect_uri: OnlineOrderClientAPI.apiRedirectUrl, onSuccess: { (tokenResponse:PXOLOTokenResponseParser?) -> Void in
                    if OnlineOrderClientAPI.isApiOlOProvider {
                        self.apiOloGetOrCreate(account, authorizationGrant: tokenResponse?.authorizationGuestToken ?? "", complitionHandler: complitionHandler)
                    }
            }, onError: { (error: Error?) -> Void in
                self.alertMessage("Error\n\(error?.localizedDescription ?? "")")
                APPSHARE.hideHudForEmptyView()
            })
            return
        }, onError:{ (error: Error?) -> Void in
            self.alertMessage("Error\n\(error?.localizedDescription ?? "")")
            APPSHARE.hideHudForEmptyView()
        })
    }
    @objc func apiOloGetOrCreate(_  account:PXStoredAccount,  authorizationGrant:String, complitionHandler: @escaping ((_ authToken:String, _ printedCardNumber:String) -> Void)) {
        if(APPSHARE.isNetworkReachable()) {
            OnlineOrderUserAPI.usersGetorcreatePost(body: ModelUserSingleSignOnRequest.init(provider: "", providertoken: authorizationGrant, provideruserid: "", contactnumber: "", basketid: AppDetails.shared.oloUserAuthToken.count > 0 ? "" : AppDetails.shared.basketModel.basketID)) { (ssoPost, error) in
                DispatchQueue.main.async {
                    if ssoPost != nil && (ssoPost?.authtoken ?? "").count > 0 {
                        APPSHARE.hideHudForEmptyView()
                        APPSHARE.accountAdded(account)
                        APPSHARE.currentAccount = account
                        AppDetails.shared.oloAuthToken(authToken: (ssoPost?.authtoken ?? ""), printedCardNumber: account.printedCardNumber, isDefault: AppDetails.shared.oloUserAuthToken.count > 0 ? true : false)
                        complitionHandler((ssoPost?.authtoken ?? ""), account.printedCardNumber)
                    }else if error != nil {
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessageErrorMessage(error!)
                    }else {
                        APPSHARE.hideHud(for: self.view)
                        self.alertMessage(OloDisplayText.textSomeWentWrong())
                    }
                }
            }
        }
    }
    @objc func openTermsAndConditions() {
        if APPSHARE.isNetworkReachable() {
            let url = AppSettings.shared()?.termsAndConditionURL()?.absoluteString ?? ""
            if url.count > 0 {
                UIApplication.shared.openURL(URL.init(string: url)!)
            }
        }
        /*if(APPSHARE.isNetworkReachable()) {
            APPSHARE.isFromNewThemeDashboard = false
            multiSSOSelectedIndexModel = WebBrowserModel.init(title: AppSettings.shared()?.termsAndConditionsPageTitle() ?? "", image: "", url: AppSettings.shared()?.termsAndConditionURL()?.absoluteString ?? "", type: .none)
            multiSSOSelectedIndexModel?.isBackButtonEnable = true
            multiSSOSelectedIndexModel?.browserTitle = AppSettings.shared()?.termsAndConditionsPageTitle()
            let newBrowser:NewWebBrowser = NewWebBrowser()
            self.navigationController?.pushViewController(newBrowser, animated: true)
        }*/
    }
    //MARK:- Facebook Login
    @objc func facebookLogin(signinOrRegisterDelegate: PXSignInOrRegisterDelegate, completionHandler: @escaping ((String,PXUserAuthenticationFields) -> Void)){
        if(APPSHARE.isNetworkReachable())
        {
            APPSHARE.registerInputFieldValues = NSMutableDictionary()
            APPSHARE.registerAccountFieldValues = NSMutableDictionary()
            AppDetails.shared.faceBookDetails = [:]
            let facebookIntegrationIdString = AppSettings().faceBookIntegrationKey()!
            let facebookPermissions = ["email"]
            let fbLoginManager = LoginManager()
            fbLoginManager.logOut()
            fbLoginManager.logIn(permissions: facebookPermissions, from: self, handler: { (result, error) in
                if (result != nil){
                    self.showHudWithMessage("")
                    let fbloginresult : LoginManagerLoginResult = result!
                    var facebookProfileString:String = ""
                    if(fbloginresult.isCancelled) {
                        self.hideHud()
                        self.showAlert(title: "Oops!", description: "We're sorry, we were unable to connect your account to Facebook. Permission was denied.", rightButton: "OK", leftButton: nil) { (status) in }
                    } else if(fbloginresult.grantedPermissions.contains("email")) {
                        if((AccessToken.current) != nil){
                            GraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, email, picture.type(normal)"]).start(completionHandler: { (connection, result, error) -> Void in
                                if (error == nil){
                                    
                                    var email = String()
                                    var userId = String()
                                    var firstName = String()
                                    var lastName = String()
                                    //Empty Old Values from Facebook
                                    let facebookData:NSMutableDictionary = [:]
                                    if ((result as! NSDictionary).value(forKey: "email") != nil){
                                        email = (result as! NSDictionary).value(forKey: "email") as! String
                                        facebookData.setValue(email, forKey: "_email")
                                        APPSHARE.registerInputFieldValues.setValue(email, forKey: "email")
                                    }
                                    if ((result as! NSDictionary).value(forKey: "id") != nil){
                                        userId = (result as! NSDictionary).value(forKey: "id") as! String
                                    }
                                    if ((result as! NSDictionary).value(forKey: "first_name") != nil){
                                        firstName = (result as! NSDictionary).value(forKey: "first_name") as! String
                                        facebookData.setValue(firstName, forKey: "_firstName")
                                        APPSHARE.registerInputFieldValues.setValue(firstName, forKey: "firstName")
                                    }
                                    if ((result as! NSDictionary).value(forKey: "last_name") != nil){
                                        lastName = (result as! NSDictionary).value(forKey: "last_name") as! String
                                        facebookData.setValue(lastName, forKey: "_lastName")
                                        APPSHARE.registerInputFieldValues.setValue(lastName, forKey: "lastName")
                                    }
                                    if ((result as! NSDictionary).value(forKey: "picture") != nil) {
                                        let picture:NSDictionary=(result as! NSDictionary).value(forKey: "picture") as! NSDictionary
                                        let data:NSDictionary=picture.value(forKey: "data") as! NSDictionary
                                        facebookProfileString = (data.value(forKey: "url") as! String)
                                        facebookData.setValue(facebookProfileString, forKey: "url")
                                    }
                                    // Locally Storing facebook image Url
                                    UserDefaults.standard.set(facebookProfileString, forKey: "facebookImageString")
                                    UserDefaults.standard.set(true, forKey: "isFacebookUser")
                                    APPSHARE.facebookValues = facebookData
                                    AppDetails.shared.faceBookDetails = facebookData as? [String : Any] ?? [:]
                                    print("AppDetails.shared.faceBookDetails :\(AppDetails.shared.faceBookDetails)")
                                    self.showHudWithMessage("Looking for account...")
                                    let authFields = self.authenticateWithExternalAccountCredentials(facebookIntegrationIdString, externalAccountCode: userId, externalAccessToken: AccessToken.current?.tokenString, externalTokenSecret: nil, signinOrRegisterDelegate: signinOrRegisterDelegate)
                                    completionHandler(facebookProfileString, authFields)
                                }
                                else
                                {
                                    let fbErrorMessage = self.generateErrorMessageFromFacebookError(error! as NSError)
                                    self.hideHud()
                                    self.showAlert(title: "Oops!", description: "We're sorry, we were unable to connect your account to Facebook.\n\(fbErrorMessage)", rightButton: "OK", leftButton: nil, complition: { (status) in })
                                }
                            })
                        }
                        else
                        {
                            self.hideHud()
                            self.showAlert(title: "Oops!", description: "We're sorry, we were unable to connect your account to Facebook.", rightButton: "OK", leftButton: nil, complition: { (status) in })
                        }
                    }
                    else
                    {
                        self.hideHud()
                        self.showAlert(title: "Oops!", description: "We're sorry, we were unable to connect your account to Facebook.", rightButton: "OK", leftButton: nil, complition: { (status) in })
                    }
                }else
                {
                    let fbErrorMessage = self.generateErrorMessageFromFacebookError(error! as NSError)
                    self.hideHud()
                    self.showAlert(title: "Oops!", description: "We're sorry, we were unable to connect your account to Facebook.\n\(fbErrorMessage)", rightButton: "OK", leftButton: nil, complition: { (status) in })
                    
                }
            })
        }
    }
    func generateErrorMessageFromFacebookError(_ error: NSError) -> String {
        switch GraphRequestError(rawValue: UInt(error.code))! {
        default:
            NSLog("Facebook Error: \(error.description)")
            return "Please contact support."
        }
    }
    func authenticateWithExternalAccountCredentials(_ externalIdentifier: String, externalAccountCode: String?, externalAccessToken: String?, externalTokenSecret: String?, signinOrRegisterDelegate: PXSignInOrRegisterDelegate) -> PXUserAuthenticationFields {
        let authFields: PXUserAuthenticationFields = PXUserAuthenticationFields()
        authFields.setValue(externalIdentifier, forKey: "externalIdentifier")
        authFields.setValue(externalAccountCode, forKey: "externalAccountCode")
        authFields.setValue(externalAccessToken, forKey: "externalAccessToken")
        authFields.setValue(externalTokenSecret, forKey: "externalTokenSecret")
        
        let externalId = PXIntegrationIdentifier(externalIdentifier, secret: nil, detail: nil)
        APPSHARE.externalAccount = PXNewExternalAccount(forIntegration: externalId, accountCode: externalAccountCode, accessToken: externalAccessToken, appIdentifier: nil)
        PaytronixAppDelegate.api()?.signIn(with: authFields, cardTemplateCode: AppSettings.shared().cardTemplateCode(), delegate: signinOrRegisterDelegate)
        return authFields
    }
    
    //MARK: - New Order Flow for PF Changs
    @objc func segueToNewOrderFlowPage() {
        if AppSettings.shared()?.isNewOrderTypeScreenWithDeliveryAddress() ?? false {
            let arrayNaviList = self.navigationController?.viewControllers ?? []
            var vcHomeTemp:UIViewController?
            for item in arrayNaviList {
                if item is OLOOrderTypeSelectionController && vcHomeTemp == nil {
                    vcHomeTemp = item
                }
            }
            if vcHomeTemp != nil {
                _ = self.navigationController?.popToViewController(vcHomeTemp!, animated: false)
            }else {
                let storyBoard = UIStoryboard.init(name: kOloStoryBoardName, bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "OrderTypeSelectionController")
                self.navigationController?.pushViewController(vc, animated: true)
            }
        } else {
            let arrayNaviList = self.navigationController?.viewControllers ?? []
            var vcHomeTemp:UIViewController?
            for item in arrayNaviList {
                if item is OLOPickupOrDeliveryViewController && vcHomeTemp == nil {
                    vcHomeTemp = item
                }
            }
            if vcHomeTemp != nil {
                _ = self.navigationController?.popToViewController(vcHomeTemp!, animated: false)
            }else {
                let storyBoard = UIStoryboard.init(name: kOloStoryBoardName, bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "PickupOrDeliveryViewController")
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
}
//MARK:- Date
extension Date {
    var components:DateComponents {
        let cal = NSCalendar.current
        return cal.dateComponents(Set([.year, .month, .day, .hour, .minute, .second, .weekday, .weekOfYear, .yearForWeekOfYear]), from: self)
    }
    var day:Int {return Calendar.current.component(.day, from:self)}
    var month:Int {return Calendar.current.component(.month, from:self)}
    var year:Int {return Calendar.current.component(.year, from:self)}
}
//MARK:- Extension NSObject
extension NSObject {
    @objc func logoutFromDevice() {
        alertMessageMultiple(message: OloDisplayText.textAlertWantToLogout(), buttonList: [OloDisplayText.textNO(),OloDisplayText.textYES()]) { (sender) in
            if sender == OloDisplayText.textYES() {
                DispatchQueue.main.async {
                    APPSHARE.window?.isUserInteractionEnabled = false
                    APPSHARE.removeAllAccount()
                    UserDefaults.standard.set(nil, forKey: "ContactNumber")
                    UserDefaults.standard.set(false, forKey: "isFetchedContactDetails")
                    UserDefaults.standard.set(false, forKey: "isFacebookUser")
                    UserDefaults.standard.set(nil, forKey: "facebookImageString")
                    APPSHARE.isAppleSignInClicked = false
                    AppDetails.shared.logoutFromAccount(true)
                    APPSHARE.currentAccount = nil
                    APPSHARE.facebookValues.removeAllObjects()
                    //set preload values Empty
                    newWebBrowserObject = nil
                    multiSSOSelectedIndexModel = nil
                        // Move to home first tab item
                    if  !AppSettings.shared().isOloThemeOneEnabled() &&
                        !AppSettings.shared().isSignInRefreshEnable() &&
                        !AppSettings.shared().disableBottomBar(){
                        APPSHARE.goToHome()
                    }
                    if TouchIdOrFaceIdManager.shared.checkAppConfiguration() {
                        // Reset user associate Touch ID or Face ID feature to show in Dashboard screen
                        TouchIdOrFaceIdManager.shared.userNotAssociatedTouchIdOrFaceIdOnce()
                    }
                    if #available(iOS 13.0, *) {
                        AppleSignIn.isASAuthenticationSuccess = false
                    }
                }
            }
        }
    }
    @objc func getCostConvertionWithCurrency(_ cost:Double) -> String {
        return String.init(format: "%@ %.02f", AppDetails.shared.appCurrency, cost)
    }
    func getCostConvertionWithCurrency(_ cost1:Double, cost2:Double) -> String {
        let cost = getCostConvertionWithCurrency(cost1)
        if cost2 > 0 {
            return String.init(format: "%@ - %@", cost, getCostConvertionWithCurrency(cost2))
        }
        return cost
    }
    func getStartAndEndOfWeekDate() -> (start:String, end:String) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyyMMdd"
        return (start:"\(dateFormatter.string(from: self.startOfWeek))", end:"\(dateFormatter.string(from: self.endOfWeek))")
    }
    var startOfWeek: Date {
        let date = Calendar.current.date(from: Calendar.current.dateComponents([.yearForWeekOfYear, .weekOfYear], from: Date()))!
        let dslTimeOffset = TimeZone.current.secondsFromGMT()
        return date.addingTimeInterval(TimeInterval(dslTimeOffset))
    }
    var endOfWeek: Date {
        return Calendar.current.date(byAdding: .second, value: 604799, to: self.startOfWeek)!
    }
    func timeWantedConvertedDate(datetime : String?, isMMProvider: Bool = false) -> String {
        guard datetime != nil && datetime!.count > 0 else {
            return ""
        }
        //let timeWantedString = "30-03-2016"
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = isMMProvider ? "yyyy-MM-dd'T'HH:mm" : "yyyyMMdd HH:mm"
        // convert your string to date
        guard let apiDate = dateFormatter.date(from: datetime!) else {
            return ""
        }
        let apiDateFormatter = DateFormatter()
        //then again set the date format whhich type of output you need
        apiDateFormatter.dateFormat = "MMM dd"
        
        let apiTimeFormatter = DateFormatter()
        apiTimeFormatter.dateFormat = "hh:mm a"
        apiTimeFormatter.amSymbol="am"
        apiTimeFormatter.pmSymbol="pm"
        let timeString = apiTimeFormatter.string(from: apiDate)
        // again convert your date to string
        let dateString = apiDateFormatter.string(from: apiDate)
        let dateTimeString = "\(dateString) @ \(timeString.uppercased())"
        return dateTimeString
    }
    func dateTimeConvertedToTimeWantedMM(date: String, time: String) -> String {
        guard date.count > 0 && time.count > 0 else {
            return ""
        }
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "M-d-yyyy h:mm a"
        dateFormatter.locale = Locale.init(identifier: "en_US")
        guard let apiDate = dateFormatter.date(from: "\(date) \(time)") else {
            return ""
        }
        let apiDateTimeFormatter = DateFormatter()
        apiDateTimeFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm"
        apiDateTimeFormatter.amSymbol="am"
        apiDateTimeFormatter.pmSymbol="pm"
        let dateTimeString = apiDateTimeFormatter.string(from: apiDate)
        return dateTimeString
    }
    func timeWantedConvertedToDateMM(orderType: Int, serviceChannelId: Int, dateTime:String) -> (date: String, time: String) {
        guard dateTime.count > 0 else {
            return ("","")
        }
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm"
        guard let apiDate = dateFormatter.date(from: dateTime) else {
            return ("","")
        }
        let apiDateFormatter = DateFormatter()
        apiDateFormatter.dateFormat = "MM/dd/yyyy"
        let dateString = apiDateFormatter.string(from: apiDate)
        let apiTimeFormatter = DateFormatter()
        apiTimeFormatter.dateFormat = "hh:mm a"
        apiTimeFormatter.amSymbol="AM"
        apiTimeFormatter.pmSymbol="PM"
        let timeString = apiTimeFormatter.string(from: apiDate)
        
        if let selectedDelTime = getMMDeliveryTimeListMM(orderType: orderType, serviceChannelId: serviceChannelId).first(where: {$0.delTimeFrontEndDesc == timeString}) {
            return (dateString,selectedDelTime.delTimeDesc ?? "")
        }
        return (dateString,"")
    }
    func getMMDeliveryTimeListMM() -> [ModelStoreServiceChannel] {
        var arrayStoreList:[ModelStoreServiceChannel] = []
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: OloValues.themeOneDelTimeDict(), options: JSONSerialization.WritingOptions.prettyPrinted)
            arrayStoreList = try! JSONDecoder().decode([ModelStoreServiceChannel].self, from: jsonData)
        }catch {
            return arrayStoreList
        }
        return arrayStoreList
    }
    func getMMDeliveryTimeListMM(orderType: Int, serviceChannelId: Int) -> [ModelStoreRestrictedDelTime] {
        let arrayServiceList:[ModelStoreServiceChannel] = getMMDeliveryTimeListMM()
        if let distribution = arrayServiceList.first(where: {$0.serviceChannelId == serviceChannelId}), let del = distribution.distributionTypes?.first(where: {$0.distributionTypeId == orderType}) {
            return del.storeRestrictedDelTimes ?? []
        }
        return []
    }
    //MARK:- Alert
    func alertMessageErrorMessage(_ error:Error) {
        if let err = error as? ErrorResponse {
            switch(err) {
            case .error(_, let data, let errorLocal, let errorOnlineOrder):
                if data != nil && (data?.count ?? 0) > 0 {
                    if errorOnlineOrder != nil {
                        if errorOnlineOrder!.message == "Please choose a time in the future"{
                            alertMessage(OloDisplayText.themeOneNewOrderFlowOderTimeClosedAlert())
                        }else{
                           // https://paytronix.atlassian.net/browse/APPL-54022
                           // client required custom alert, alert1-> Fuji congif, alert2-> Prod config are changed to newalert message
                            alertMessage((errorOnlineOrder!.message.containsIgnoringCase(OloDisplayText.themeOneNewOrderFlowAddressUnavailableAlertOne())) ? "Sorry we do not deliver to this address at the moment.  Please enter a different address or place order for pickup" : errorOnlineOrder!.message.containsIgnoringCase(OloDisplayText.themeOneNewOrderFlowAddressUnavailableAlertTwo()) ? OloDisplayText.themeOneNewOrderFlowAddressUnavailableNewAlert(): errorOnlineOrder!.message)
                        }
                    }else {
                        do {
                            let errorResponse:ErrorOnlineOrder = try JSONDecoder().decode(ErrorOnlineOrder.self, from: data!)
                            alertMessage(errorResponse.message)
                        }catch {
                            alertMessage(errorLocal.localizedDescription)
                        }
                    }
                }else {
                    alertMessage(errorLocal.localizedDescription)
                }
                break
            }
        }else {
            alertMessage(error.localizedDescription)
        }
    }
    @objc func alertMessage(_ message:String) {
        if !OnlineOrderClientAPI.isOnlineOrderEnabled {
            self.showAlert(title: nil, description: message, rightButton: "OK", leftButton: nil) { (status) in }
        }else{
            if message == "The Internet connection appears to be offline." {
                APPSHARE.showAlertNoNetwork()
            }else {
                self.alertMessage(message: message, complition: nil)
            }
        }
    }
    func alertUnderDevelopment(_ complition:(() -> Void)? = nil) {
        self.alertMessage(message: OloDisplayText.textDevelopmentInProgress(), complition: complition)
    }
    @objc func alertMessage(_ title: String? = nil, message:String, complition:(() -> Void)?) {
        let alertMessage = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        if #available(iOS 13.0, *) {
            if self.topViewController()?.traitCollection.userInterfaceStyle == .dark {
                alertMessage.view.tintColor =  .white
            }else {
                alertMessage.view.tintColor =  UIColor.oloColorTheme()
            }
        }else {
            alertMessage.view.tintColor =  UIColor.oloColorTheme()
        }
        let ok = UIAlertAction.init(title: OloDisplayText.textOk(), style: .default) { (action) in
            if complition != nil {
                complition!()
            }
        }
        alertMessage.addAction(ok)
        let currentVC = self.topViewController()
        currentVC?.view.tintAdjustmentMode = .normal
        currentVC?.present(alertMessage, animated: true, completion: nil)
    }
    @objc func alertMessageMultiple(_ title: String? = nil, message:String, buttonList:[String], complition:((String) -> Void)?) {
        let alertMessage = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        if #available(iOS 13.0, *) {
            if self.topViewController()?.traitCollection.userInterfaceStyle == .dark {
                alertMessage.view.tintColor =  .white
            }else {
                alertMessage.view.tintColor =  UIColor.oloColorTheme()
            }
        }else {
            alertMessage.view.tintColor =  UIColor.oloColorTheme()
        }
        for item in buttonList {
            let ok = UIAlertAction.init(title: item, style: .default) { (action) in
                if complition != nil {
                    complition!(item)
                }
            }
            alertMessage.addAction(ok)
        }
        let currentVC = self.topViewController()
        currentVC?.view.tintAdjustmentMode = .normal
        currentVC?.present(alertMessage, animated: true, completion: nil)
    }
    @objc func oloAlertMessageDelete(complition:@escaping ((_ status:Bool) -> Void)) -> AlertViewController {
        let alertDelete = AlertViewController.init(nibName: "AlertViewController", bundle: nil)
        alertDelete.modalPresentationStyle = .overCurrentContext
        alertDelete.view.backgroundColor = .clear
        alertDelete.showAlertDelete(complition: complition)
        self.topViewController()?.present(alertDelete, animated: false, completion: nil)
        return alertDelete
    }
    //Cancel Order Popup
    @objc func oloAlertMessageCancelOrder(complition:@escaping ((_ status:Bool) -> Void)) -> AlertViewController {
        let alertCancel = AlertViewController.init(nibName: "AlertViewController", bundle: nil)
        alertCancel.modalPresentationStyle = .overCurrentContext
        alertCancel.view.backgroundColor = .clear
        alertCancel.showAlertCancelOrder(complition: complition)
        self.topViewController()?.present(alertCancel, animated: false, completion: nil)
        return alertCancel
    }
    //AlertMessage
    @objc func oloAlertMessage(_ title:String = "", message:String, buttons:[String] = [], complition: ((_ action:String) -> Void)?) -> AlertViewController {
        let alertCancel = AlertViewController.init(nibName: "AlertViewController", bundle: nil)
        alertCancel.modalPresentationStyle = .overCurrentContext
        alertCancel.view.backgroundColor = .clear
        alertCancel.oloAlertMessage(title, message: message, action: buttons, complition: complition)
        self.topViewController()?.present(alertCancel, animated: false, completion: nil)
        return alertCancel
    }
    @objc func topViewController(controller: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let navigationController = controller as? UINavigationController {
            return topViewController(controller: navigationController.visibleViewController)
        }
        if let tabController = controller as? UITabBarController {
            if let selected = tabController.selectedViewController {
                return topViewController(controller: selected)
            }
        }
        if let presented = controller?.presentedViewController {
            return topViewController(controller: presented)
        }
        return controller
    }
    //review
    @objc func requestReviewInAppStore() {
        func openAppStoreLink(_ apppstoreID: String) {
            let url = "itms-apps://itunes.apple.com/app/viewContentsUserReviews?id=\(apppstoreID)";
            if UIApplication.shared.canOpenURL(URL.init(string: url)!) {
                UIApplication.shared.openURL(URL.init(string: url)!)
            }
        }
        //        if #available(iOS 10.3, *) {
        //            SKStoreReviewController.requestReview()
        //        } else {
        //AppStoreID
        let apppstoreID:String = OloValues.valueAppStoreID()
        if apppstoreID.count > 0 {
            openAppStoreLink(apppstoreID)
        }else if let bundleID = Bundle.main.bundleIdentifier {
            APPSHARE.showHud(withMessage: "", for: self.topViewController()?.view)
            OnlineOrderOthersAPI.itunesLookupGet(bundleID: bundleID) { (itunesList, error) in
                DispatchQueue.main.async {
                    APPSHARE.hideHudForEmptyView()
                    if itunesList != nil {
                        if let itunes = itunesList!.results.first, itunes.trackID > 0 {
                            openAppStoreLink("\(itunes.trackID)")
                        }else {
                            openAppStoreLink("")
                            //self.alertMessage("Can't find the itunes url")
                        }
                    }else if error != nil {
                        self.alertMessageErrorMessage(error!)
                    }else {
                        self.alertMessage(OloDisplayText.textAlertStoreCodeNotFound())
                    }
                }
            }
        }
        //        }
    }
    @objc func prettyPrint(with json: [String:Any]) -> String{
        let data = try! JSONSerialization.data(withJSONObject: json, options: .prettyPrinted)
        let string = NSString(data: data, encoding: String.Encoding.utf8.rawValue)
        return (string ?? "") as String
    }
    func getDeliveryAddressWithFormat(_ sender:[String:Any]) -> (deliveryAddress:String, specialInst:String?) {
        var strAddress:String = ""
        if let streetaddress = sender["streetaddress"] as? String {
            strAddress += "\(streetaddress)"
        }
        if let building = sender["building"] as? String, building.count > 0 {
            strAddress += ", \(building)"
        }
        if let city = sender["city"] as? String {
            strAddress += ",\n\(city)"
        }
        if let zipcode = sender["zipcode"] as? String {
            strAddress += ", \(zipcode)"
        }
        if let specialinstructions = sender["specialinstructions"] as? String, specialinstructions.count > 0 {
            return (strAddress, specialinstructions)
        }
        return (strAddress, nil)
    }
    func getDeliveryAddressWithFormat(_ deliveryAddress:ModelDeliveryAddress) -> (deliveryAddress:String, specialInst:String?) {
        var strAddress:String = ""
        let streetaddress = deliveryAddress.streetaddress
        let city = deliveryAddress.city
        let zipcode = deliveryAddress.zipcode
        if streetaddress.count > 0 {
            strAddress += "\(streetaddress)"
        }
        if let building = deliveryAddress.building, building.count > 0 {
            strAddress += ", \(building)"
        }
        if let addressLine2 = deliveryAddress.addressLine2, addressLine2.count > 0 { // MM
            strAddress += ", \(addressLine2)"
        }
        if city.count > 0 {
            strAddress += ",\n\(city)"
        }
        if let addressState = deliveryAddress.addressState, addressState.count > 0 { // MM
            strAddress += ", \(addressState)"
        }
        if zipcode.count > 0 {
            strAddress += ", \(zipcode)"
        }
        if let specialinstructions = deliveryAddress.specialinstructions, specialinstructions.count > 0 {
            return (strAddress, specialinstructions)
        }
        return (strAddress, nil)
    }
    //Local Notification
   @objc func showLocalNotification(title: String, body: String) {
        if #available(iOS 10.0, *) { //iOS 10
            let content = UNMutableNotificationContent()
            content.title = title
            content.body = body;
            content.sound = UNNotificationSound.default
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 2, repeats: false)
            let request = UNNotificationRequest(identifier: "AlertIdentifier", content: content, trigger: trigger)
            UNUserNotificationCenter.current().add(request) { (error) in
                if let error = (error as NSError?) {
                    print("Something went wrong: \(error.localizedDescription)")
                }
            }
        }else { //iOS 9
            let notification = UILocalNotification()
            notification.fireDate = NSDate(timeIntervalSinceNow: 2) as Date
            notification.alertTitle = title
            notification.alertBody = body
            notification.soundName = UILocalNotificationDefaultSoundName
            UIApplication.shared.scheduleLocalNotification(notification)
        }
    }
    //Get Target Info Plist details
    func getTargetInfoPlist() -> [String:Any] {
        return Bundle.parsePlist(ofName: "PFChangs-Info")
    }
    //Set Accessibility Voice Over text for uiview extension
    @objc func accessibilityVoiceOver(type view: UIView?, title: String, hint: String) {
        if let button = view as? UIButton {
            button.accessibilityTraits = .none
            button.isAccessibilityElement = true
            button.accessibilityLabel = title
            button.accessibilityHint = hint
        }else if let viewType = view {
            viewType.accessibilityTraits = .none
            viewType.isAccessibilityElement = true
            viewType.accessibilityLabel = title
            viewType.accessibilityHint = hint
        }
    }
}
//Multitap issue start
extension UINavigationController {
   @objc public func pushViewController(
        viewController: UIViewController,
        animated: Bool,
        completion: @escaping () -> Void)
    {
        pushViewController(viewController, animated: animated)
        
        guard animated, let coordinator = transitionCoordinator else {
            completion()
            return
        }
        
        coordinator.animate(
            // pass nil here or do something animated if you'd like, e.g.:
            alongsideTransition: { context in
                viewController.setNeedsStatusBarAppearanceUpdate()
        },
            completion: { context in
                completion()
        }
        )
    }
}
//Multitap issue end
//MARK:- UITextField
extension UITextField {
    @objc func setPlaceHolderText(_ text:String, color:UIColor = UIColor.oloColorTextFourth()) {
        self.attributedPlaceholder = NSAttributedString(string: text,attributes: [NSAttributedString.Key.foregroundColor:color])
    }
    @objc func setLeftPaddingPoints(_ amount:CGFloat){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
    @objc func setRightPaddingPoints(_ amount:CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.rightView = paddingView
        self.rightViewMode = .always
    }
}
//MARK:- Double
extension Double {
    //The below code is used for RoundOff the value
    var roundOffValue: String {
        return self.truncatingRemainder(dividingBy: 1) == 0 ? String(format: "%.0f", self) : String(self)
    }
    
}

extension Array {
    mutating func remove(at indexes: [Int]) {
        var lastIndex: Int? = nil
        for index in indexes.sorted(by: >) {
            guard lastIndex != index else {
                continue
            }
            remove(at: index)
            lastIndex = index
        }
    }
}
//MARK:- Extension String
extension String {
    func getStringFromHTML(_ color:UIColor, font:UIFont, fontSize:Int) -> NSAttributedString? {
        do {
            var colorCode = "color=black"
            if let rgb = color.rgb() {
                colorCode = "color=rgb(\(rgb.red), \(rgb.green), \(rgb.blue))"
            }
            let htmlString = "<font face=\"\(font.fontName)\" size=\"\(fontSize)\" \(colorCode)>" + self + "</font>"
            let data = htmlString.data(using: String.Encoding.unicode, allowLossyConversion: true)
            if let currentData = data {
                let attributed = try NSAttributedString(data: currentData,options: convertToNSAttributedStringDocumentReadingOptionKeyDictionary([convertFromNSAttributedStringDocumentAttributeKey(NSAttributedString.DocumentAttributeKey.documentType): convertFromNSAttributedStringDocumentType(NSAttributedString.DocumentType.html)]),documentAttributes: nil)
                return attributed
            }
        } catch {
        }
        return nil
    }
}
//MARK:- Extension UIColor
extension UIColor {
    func rgb() -> (red:Int, green:Int, blue:Int, alpha:Int)? {
        var fRed : CGFloat = 0
        var fGreen : CGFloat = 0
        var fBlue : CGFloat = 0
        var fAlpha: CGFloat = 0
        if self.getRed(&fRed, green: &fGreen, blue: &fBlue, alpha: &fAlpha) {
            let iRed = Int(fRed * 255.0)
            let iGreen = Int(fGreen * 255.0)
            let iBlue = Int(fBlue * 255.0)
            let iAlpha = Int(fAlpha * 255.0)
            return (red:iRed, green:iGreen, blue:iBlue, alpha:iAlpha)
        } else {
            // Could not extract RGBA components:
            return nil
        }
    }
}
//MARK:- UISegmentedControl
extension UISegmentedControl {
    func setOloSegmentStyle() {
        setBackgroundImage(imageWithColor(color: UIColor.oloPopupWhiteBackgroundColor()), for: .normal, barMetrics: .default)
        setBackgroundImage(imageWithColor(color: UIColor.oloColorTheme()), for: .selected, barMetrics: .default)
        setDividerImage(imageWithColor(color: UIColor.oloColorTheme()), forLeftSegmentState: .normal, rightSegmentState: .normal, barMetrics: .default)
        let segAttributes: [NSAttributedString.Key : Any] = [
            NSAttributedString.Key.foregroundColor: UIColor.oloColorTextPrimary(),
            NSAttributedString.Key.font: UIFont.oloFontPrimary(18)
        ]
        setTitleTextAttributes(segAttributes, for: UIControl.State.normal)
        let segAttributesExtra: [NSAttributedString.Key : Any] = [
            NSAttributedString.Key.foregroundColor: UIColor.oloColorTextThird(),
            NSAttributedString.Key.font: UIFont.oloFontPrimary(18)
        ]
        setTitleTextAttributes(segAttributesExtra, for: UIControl.State.selected)
        self.layer.borderWidth = 1.0
        self.layer.cornerRadius = 10.0
        self.layer.borderColor = UIColor.oloColorTextTheme().cgColor
        self.layer.masksToBounds = true
    }
    private func imageWithColor(color: UIColor) -> UIImage {
        let rect = CGRect(x: 0.0, y: 0.0, width:  1.0, height: 1.0)
        UIGraphicsBeginImageContext(rect.size)
        let context = UIGraphicsGetCurrentContext()
        context!.setFillColor(color.cgColor);
        context!.fill(rect);
        let image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        return image!
    }
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertToOptionalNSAttributedStringKeyDictionary(_ input: [String: Any]?) -> [NSAttributedString.Key: Any]? {
    guard let input = input else { return nil }
    return Dictionary(uniqueKeysWithValues: input.map { key, value in (NSAttributedString.Key(rawValue: key), value)})
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertToUIApplicationOpenExternalURLOptionsKeyDictionary(_ input: [String: Any]) -> [UIApplication.OpenExternalURLOptionsKey: Any] {
    return Dictionary(uniqueKeysWithValues: input.map { key, value in (UIApplication.OpenExternalURLOptionsKey(rawValue: key), value)})
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromNSAttributedStringKey(_ input: NSAttributedString.Key) -> String {
    return input.rawValue
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertToNSAttributedStringDocumentReadingOptionKeyDictionary(_ input: [String: Any]) -> [NSAttributedString.DocumentReadingOptionKey: Any] {
    return Dictionary(uniqueKeysWithValues: input.map { key, value in (NSAttributedString.DocumentReadingOptionKey(rawValue: key), value)})
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromNSAttributedStringDocumentAttributeKey(_ input: NSAttributedString.DocumentAttributeKey) -> String {
    return input.rawValue
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromNSAttributedStringDocumentType(_ input: NSAttributedString.DocumentType) -> String {
    return input.rawValue
}

// Shadow for uiview
extension UIView {
    func shadowView() {        
        self.layer.cornerRadius = 15
        self.layer.shadowOpacity = 0.6
        self.layer.shadowColor = AppSettings.shared()?.lowContrastColor().cgColor ?? UIColor.black.cgColor
        self.layer.shadowRadius = 8.0
        self.layer.shadowOffset = CGSize(width: 0, height: 4)
    }
}

enum iPhoneDeviceType {
    case iPhone_SE
    case iPhone_6_6s_7_8
    case iPhone_6P_6sP_7P_8P
    case iPhone_X_Xs_11Pro
    case iPhone_Xr_11
    case iPhone_XsMax_11ProMax
    case defaultSize
    
    var deviceType: iPhoneDeviceType {
        switch UIScreen.main.nativeBounds.width {
        case 640:
            return .iPhone_SE
        case 750:
            return .iPhone_6_6s_7_8
        case 828:
            return .iPhone_Xr_11
        case 1080:
            return .iPhone_6P_6sP_7P_8P
        case 1125:
            return .iPhone_X_Xs_11Pro
        case 1242:
            if UIScreen.main.nativeBounds.height == 2208 || UIScreen.main.nativeBounds.height == 1920 {
                return .iPhone_6P_6sP_7P_8P
            } else {
                return .iPhone_XsMax_11ProMax
            }
        default:
            return .defaultSize
        }
    }
}

extension UINavigationBar {
    @objc func setUpOLOImageNavigationBar() {
        var navBarBg : UIImage? = UIImage(named: "navBar")
        let statusBarFrame = UIApplication.shared.statusBarFrame
        let statusBarWidth = Int(statusBarFrame.width)
        let statusBarHeight = Int(statusBarFrame.height)
        if statusBarWidth == 375 {
            if statusBarHeight == 20 {
                navBarBg = UIImage(named: "navBar")
            }else{
                navBarBg = UIImage(named: "navBarForX_Xs")
            }
        }else if statusBarWidth == 414 {
            if statusBarHeight == 20 {
                navBarBg = UIImage(named: "navBarForPlusDevice")
            }else{
                navBarBg = UIImage(named: "navBarForXr_XsMax")
            }
        }else {
            if statusBarHeight == 20 {
                navBarBg = UIImage(named: "navBar")
            }else{
                navBarBg = UIImage(named: "navBarForX_Xs")
            }
        }
        self.setBackgroundImage(navBarBg, for: .default)
        self.shadowImage = UIImage()
        self.isTranslucent = true
        self.backgroundColor = UIColor.oloColorNavigationBackGround()
        self.barTintColor = UIColor.oloColorNavigationBarText()
    }
}
