//
//  OloDashBoardViewController.swift
//  PaytronixApps
//
//  Created by mac on 15/12/17.
//  Copyright © 2017 Paytronix Systems Inc. All rights reserved.
//

import UIKit


@objc(OloDashBoardViewController)
class OloDashBoardViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout,OLOCellHomeMenuDelegate,PXCheckInDelegate,WebBrowserDelegate
{
    //MARK:- Outlet
    var delegate: PXHomeDelegate?
    let dashBoardViewObject:DashboardView = DashboardView()
    @IBOutlet var viewEarnRewardBG:UIView!
    @IBOutlet var viewEarnRewardValue:UIView!
    @IBOutlet var imageViewEarnRewardValue:UIImageView!
    @IBOutlet var viewEarnRewardEarnRewards:UIView!
    @IBOutlet var collectionDashBoardMenu:UICollectionView!
    @IBOutlet var layoutLeadingEarnRewardBlur: NSLayoutConstraint!
    @IBOutlet var labelRewardTitle: UILabel!
    @IBOutlet var labelRewardValue: UILabel!
    @IBOutlet var labelRewardMinimumValue: UILabel!
    @IBOutlet var labelRewardMaximumValue: UILabel!
    @IBOutlet var labelRewardHalfValue: UILabel!
    @IBOutlet var layoutHeightRewardProgressValues: NSLayoutConstraint!
    @IBOutlet var layoutHeightRewardProgressBar: NSLayoutConstraint!
    @IBOutlet var viewRewardsProgressValues: UIView!
    @IBOutlet var backgroundImageView:UIImageView!
    var timerCheckIn: Timer?
    var _currentExpirationTime: Date?
    var _currentShortCardNumber: String?
    var imageMenuBG = UIImage.init(named: "iconOloMenuBG")
    
    //MARK:- Var
    var arrayMenus:[ModelOloHomeMenu] = []
    var rewardPercentage:Int = 0
    var rewardMinimum:Int = 0
    var rewardMaximum:Int = 0
    var rewardHalf:Int = 0
    
    var ExpirationText:String = ""
    var checkinStoreCode:String = ""
    var isCheckinEnabled:Bool = false
    let appDelegate = UIApplication.shared.delegate as! PaytronixAppDelegate
    
    var dimView = UIView()
     
    //Tier Feature
    @IBOutlet weak var tierProgressContainerView: UIView!
    @IBOutlet weak var tierProgressContainerBottom: NSLayoutConstraint!
    @IBOutlet weak var pointsProgressTextBottom: NSLayoutConstraint!
    @IBOutlet weak var tierImageContainer: UIView!
    @IBOutlet weak var tierShadowView: UIView!
    @IBOutlet weak var tierImageView: UIImageView!
    @IBOutlet weak var tierWrapperContainer: UIView!
    @IBOutlet weak var logoImageView: UIImageView!
    @IBOutlet weak var tierLevelLabel: UILabel!
    @IBOutlet weak var benefitsButton: UIButton!
    @IBOutlet weak var orderNowButtonContainer: UIView!
    @IBOutlet weak var orderNowArrowIconView: UIImageView!
    @IBOutlet weak var orderNowButtonLabel: UILabel!
    @IBOutlet weak var orderNowButton: UIButton!
    @IBOutlet var stickyFooterConstaintsArray: [NSLayoutConstraint]!
    @IBOutlet weak var collectionViewLeadingSpace: NSLayoutConstraint!
    @IBOutlet weak var collectionViewTrailingSpace: NSLayoutConstraint!
    @IBOutlet weak var collectionViewBottomSpaceToOrderNow: NSLayoutConstraint!
    @IBOutlet weak var collectionViewBottomSpaceToSuperView: NSLayoutConstraint!
    
    let isTierFeatureEnabled: Bool = AppSettings.shared()?.isEnableTierFeature() ?? false
    var tierLevels = [TierLevel]()
    var currentUserTierCode: Int = -1
    var currentTierTitle: String = ""
    
    //MARK:- View Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        UIAccessibility.post(notification: .screenChanged, argument: self.parent?.navigationItem.leftBarButtonItem)
        self.pageDesign()
        collectionDashBoardMenu.isScrollEnabled = false
        //timerCheckIn = Timer.scheduledTimer(timeInterval: 1, target: self, selector: Selector("timerFireMethod:"), userInfo: nil, repeats: true)
        NotificationCenter.default.addObserver(self, selector: #selector(shortCardExpiredNotification(_:)), name: NSNotification.Name(rawValue: kPXShortCardNumberExpired), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(getCheckinDetails), name: NSNotification.Name(rawValue: kAccountCheckedIn), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(getCheckinDetails), name: NSNotification.Name(rawValue: kLocationChanged), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(getCheckinDetails), name: NSNotification.Name(rawValue: kCurrentAccountWasChangedNotification), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(updateMessageCount), name: NSNotification.Name(rawValue: kUpdateSideDrawerNotificationCount), object: nil)
        //Preload Works here
        if newWebBrowserObject == nil {
            preloadConceptExecute()
        }
    }
    
    override func viewWillLayoutSubviews() {
        self.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
    }
    @objc func updateMessageCount()
    {
        let unreadeMessageCount: Int =  UserDefaults.standard.integer(forKey: kUpdateSideDrawerNotificationCount)
        if unreadeMessageCount > 99{
            notificationCount.text = String(format: "9+")
        }else{
            notificationCount.text = String(format: "%d", unreadeMessageCount)
        }
    }
    @objc func updateBasketCount()
    {
        self.addBasketButtonInNavigation(isForDashboard: true)
        
    }
    override func viewDidAppear(_ animated: Bool)  {
        
        updateMessageCount()
        updateBasketCount()
        
        let welcomeText = VWOManager.isVWOEnabled ? VWOManager.dashboardWelcomeText : OloDisplayText.textWelcome()
        if AppDetails.shared.welcomeUsername.count > 0 {
            self.parent?.navigationItem.title = "\(welcomeText), \(AppDetails.shared.welcomeUsername)"
        }else {
            self.parent?.navigationItem.title = "\(welcomeText), \(OloDisplayText.textUser())"
        }
        if APPSHARE.isNetworkReachable() {
            if (self.delegate!.hasCards()) {
                let storedAccount:PXStoredAccount = APPSHARE.currentAccount
                if(storedAccount.printedCardNumber != nil) {
                    storedAccount.fetchInformation({ (accountInformation, ErrorType) -> Void in
                        if let accountInformation = accountInformation {
                            self.currentUserTierCode = Int(accountInformation.tierCode)
                            self.currentTierTitle = accountInformation.tierLabel
                        }
                        DispatchQueue.main.async {
                            // Update tier data based on user tier
                            self.loadTierData()
                        }
                        storedAccount.fetchUserInformation({ (userInformation, ErrorType) -> Void in
                            if userInformation != nil {
                                AppDetails.shared.userInformation = userInformation!
                                if userInformation!.fields.firstName != nil {
                                    AppDetails.shared.welcomeUserName(userName: "\(userInformation!.fields.firstName!)".uppercased())
                                    self.parent?.navigationItem.title = "\(welcomeText), \(AppDetails.shared.welcomeUsername)"
                                }else {
                                    AppDetails.shared.welcomeUserName(userName: "")
                                    self.parent?.navigationItem.title = "\(welcomeText), \(AppDetails.shared.welcomeUsername)"
                                }
                            }else {
                                AppDetails.shared.welcomeUserName(userName: "")
                                self.parent?.navigationItem.title = "\(welcomeText), \(AppDetails.shared.welcomeUsername)"
                            }
                        })
                        let rewardPercentage:Double = self.dashBoardViewObject.calculatePercentage()
                        let rewardPoints:Double = self.dashBoardViewObject.calculateAmountSpent()                        
                        self.showPercentageOfEarnPoint(rewardPoints, percentage: rewardPercentage * 100)
                    })
                }
            }
        }
        self.reloadPage()
        
        if TouchIdOrFaceIdManager.shared.checkAppConfiguration() {
            // Show touchId or faceId defualt prompt for confirmation
            if TouchIdOrFaceIdManager.shared.isTouchIdOrFaceIdConfirmed && TouchIdOrFaceIdManager.shared.getRefreshToken() == nil{
                TouchIdOrFaceIdManager.shared.showTouchIdOrFaceIdDefualtPromptForConfirm{ (status) in
                    if status == false {
                        // Remove cofirmation if user cancelled authenticate prompt or any errors
                        TouchIdOrFaceIdManager.shared.removeTouchIdOrFaceIdConfirm()
                        
                        // Update for Do Not show bottom sheet in Dashboard screen here after
                        TouchIdOrFaceIdManager.shared.userAssociatedTouchIdOrFaceIdOnce()
                    }
                }
            }else if TouchIdOrFaceIdManager.shared.isTouchIdOrFaceIdEnabled && TouchIdOrFaceIdManager.shared.isUserSignedInUsingTouchIdOrFaceId {
                
                // Update for Do Not show success alert in Dashboard screen here after
                TouchIdOrFaceIdManager.shared.isUserSignedInUsingTouchIdOrFaceId = false
            }else{
                
                if  TouchIdOrFaceIdManager.shared.isTouchIdOrFaceIdEnabled == false &&  TouchIdOrFaceIdManager.shared.isUserAssociatedTouchIdOrFaceIdOnce == false {
                    
                    // Update for Do Not show bottom sheet in Dashboard screen here after
                    TouchIdOrFaceIdManager.shared.userAssociatedTouchIdOrFaceIdOnce()
                    self.showTouchIdOrFaceIdBottomSheet()
                    
                }else if TouchIdOrFaceIdManager.shared.isTouchIdOrFaceIdEnabled && TouchIdOrFaceIdManager.shared.isUserAssociatedTouchIdOrFaceIdOnce == false && TouchIdOrFaceIdManager.shared.isUserSignedInUsingTouchIdOrFaceId == false && TouchIdOrFaceIdManager.shared.isAssociateUserChanged{
                    
                    // Update for Do Not show bottom sheet in Dashboard screen here after
                    TouchIdOrFaceIdManager.shared.userAssociatedTouchIdOrFaceIdOnce()
                    
                    self.showTouchIdOrFaceIdBottomSheet()
                }
            }
        }
    }
    func showRewardPopup() {
        // Start *** Show Popup when user achieves their maximum point
        let rewardCount: Int = Int(self.dashBoardViewObject.calculateRewardsCount())
        if UserDefaults.standard.object(forKey: k_rewardsCount) != nil {
            if rewardCount > UserDefaults.standard.integer(forKey: k_rewardsCount) {
                let rewardsTitle = OloDisplayText.customRewardEndValueText()
                var endValueText = ""
                let listString = rewardsTitle.components(separatedBy: "{dividedByThemeColor}")
                if listString.count > 1 {
                    endValueText = "\(listString[0])\(listString[1])"
                } else {
                    endValueText = rewardsTitle.replacingOccurrences(of: "{dividedByThemeColor}", with: "")
                }
                self.showAlert(title: OloDisplayText.customRewardDialogueTitleText(), description: endValueText, rightButton: "OK", leftButton: nil, complition: { status in
                    self.callReorderPopup() //Call Reorder Popup
                })
                UserDefaults.standard.set(rewardCount, forKey: k_rewardsCount)
                UserDefaults.standard.synchronize()
            } else {
                UserDefaults.standard.set(rewardCount, forKey: k_rewardsCount)
                UserDefaults.standard.synchronize()
                self.callReorderPopup() //Call Reorder Popup
            }
        } else {
            UserDefaults.standard.set(rewardCount, forKey: k_rewardsCount)
            UserDefaults.standard.synchronize()
            self.callReorderPopup() //Call Reorder Popup
        }
        // End *** Show Popup when user achieves their maximum point
    }

    func callReorderPopup() {
        print("Reorder popup get called!!!")
        APPSHARE.showHud(withMessage: "", for: self.view)
        self.apiUpdateRecentOrderListToLocal { (status) in
            if status {
                AppDetails.shared.checkRecentOrder(delegate:self)
            }
            APPSHARE.hideHudForEmptyView()
        }
    }
    
    func showTouchIdOrFaceIdBottomSheet(){
        // Display TouchId or FaceId bottom sheet
        let storyBoard = UIStoryboard(name: "ThemeOneScreen", bundle: nil)
        if let touchIdOrFaceIdObject = storyBoard.instantiateViewController(withIdentifier: "TouchIDOrFaceIDSheet") as? TouchIDOrFaceIDSheet{
            self.showDimView()
            touchIdOrFaceIdObject.view.frame = CGRect.init(x: touchIdOrFaceIdObject.view.frame.origin.x, y: UIScreen.main.bounds.height, width: touchIdOrFaceIdObject.view.frame.size.width, height: touchIdOrFaceIdObject.view.frame.height)
            UIView.animate(withDuration: 0.3, delay: 0.0, options: .curveEaseIn, animations: {
                touchIdOrFaceIdObject.view.frame = UIScreen.main.bounds
            }, completion: { _ in
            })
            UIApplication.shared.keyWindow?.rootViewController?.view.addSubview(touchIdOrFaceIdObject.view)
            UIApplication.shared.keyWindow?.rootViewController?.addChild(touchIdOrFaceIdObject)
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self)
        clearCheckin()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        APPSHARE.isFromNewThemeDashboard = false
        self.navigationController?.navigationBar.isTranslucent = true
        self.navigationController?.navigationBar.isHidden = false
        appDelegate.isRechargeClass = false
        if !(self.delegate!.hasCards())
        {
            //modified for SignInSignUpHome
            if(AppSettings.shared().isSignInRefreshEnable() || AppSettings.shared().isOloThemeOneEnabled()) {
                self.delegate?.setUpSignInSignUpHomeViewControllerAsChild()
            }else {
                self.delegate?.setUpSignInViewControllerAsChild()
            }
            self.delegate?.takeDownOloSignedInViewControllerAsChild()
        } else {
//            APPSHARE.showHud(withMessage: "", for: self.view)
//            self.apiUpdateRecentOrderListToLocal { (status) in
//                AppDetails.shared.checkRecentOrder(delegate:self)
//                APPSHARE.hideHudForEmptyView()
//            }
        }
        getCheckinDetails()
        self.checkAutoSurveyDetails()
        //Call Recent Order Api for Re Order Popup and Recommended Menu
    }
    
    func checkAutoSurveyDetails(){
        var surveyCode = ""
        var condextcodeString = ""
        
        func onSuccess(_ response: PXMyMessages?) -> (){
            
            if ((response?.myMessages.count)!>0){
                var surveyViewCodeArray:NSMutableArray = []
                var temp:PXMessage?
                
                for i in 0..<Int((response?.myMessages.count)!) {
                    temp = response?.myMessages[i] as? PXMessage
                    if temp?.contextType == "SURVEY_CODE"{
                        surveyViewCodeArray.add(temp!.code)
                        if i == 0{
                            condextcodeString = (temp?.contextCode)!
                        }
                    }
                }
                
                if (surveyViewCodeArray.count>0){
                    
                    surveyCode = (surveyViewCodeArray[0] as! NSNumber).stringValue
                    var surveyCodeArray:NSMutableArray = []
                    surveyCodeArray = SignedIn().getSurveyValues()
                    
                    if (!(surveyCodeArray.contains(surveyCode)) || surveyViewCodeArray.count == 0){
                        
                        func onSuccessSurvey(_ response: HSSurveyDetailsGetResponse?) -> (){
                            
                            var optedInDatetime: Date!
                            var dateAutoDurationAhead: Date!
                            var currentDate:Date!
                            let secondsInTenMinutes: TimeInterval =                           TimeInterval(AppSettings.shared().autoSurveyTimeDuration() * 60)

                            let dateFormatter = DateFormatter()
                            dateFormatter.dateFormat = "YYYY-MM-dd HH:mm:ss z"
                            dateFormatter.formatterBehavior = .default
                            
                            if let hasOptedInDatetime = response?.optedInDatetime{
                                if let hasValue = dateFormatter.date(from: hasOptedInDatetime){
                                    optedInDatetime = hasValue
                                }
                            }
                            
                            // Add 'autoSurveyTimeDuration' to optedInDatetime
                            if optedInDatetime != nil {
                                dateAutoDurationAhead = optedInDatetime?.addingTimeInterval(secondsInTenMinutes)
                            }
                            
                            // Get currentDate
                            if let hasCurrentDate = dateFormatter.date(from: dateFormatter.string(from: Date())){
                                currentDate = hasCurrentDate
                            }
                            
                            // Comparing 'dateAutoDurationAhead' and 'currentDate'
                            if dateAutoDurationAhead != nil && currentDate != nil {
                                
                                optedInDatetime = optedInDatetime.toLocalTime()
                                dateAutoDurationAhead = dateAutoDurationAhead.toLocalTime()
                                currentDate = currentDate.toLocalTime()
                                
                                let result: ComparisonResult = dateAutoDurationAhead.compare(currentDate)
                                var showAutoSurvey:Bool = false
                                if result == .orderedAscending {
                                    print("currentDate is in the future, No need to show survey")
                                } else if result == .orderedDescending {
                                    showAutoSurvey = true
                                    print("currentDate is in the past, Show survey screen")
                                } else {
                                    showAutoSurvey = true
                                    print("Both dates are the same")
                                }
                                
                                if showAutoSurvey {
                                    let storyBoard = UIStoryboard(name: "ThemeOneScreen", bundle: nil)
                                    if let hasSurveyInitialScreen = storyBoard.instantiateViewController(withIdentifier: "SurveyInitialScreen") as? SurveyInitialScreen{
                                        hasSurveyInitialScreen.isSurveySuccess = true
                                        if let hasValue = response?.surveyDetailsArray{
                                            hasSurveyInitialScreen.SurveyQuestionsDetailsString = hasValue as? [String : AnyObject] ?? [:]
                                        }
                                        hasSurveyInitialScreen.surveyCode = surveyCode
                                        self.navigationController?.pushViewController(hasSurveyInitialScreen, animated: false)
                                    }
                                }
                            }
                            
                            
                            
                            /*var End:NSString = "00:00:00"
                            var start:NSString = "00:01:00"
                            let today1 = Date().addingTimeInterval(0)
                            let f = DateFormatter()
                            f.dateFormat = "YYYY-MM-dd HH:mm:ss z"
                            
                            f.formatterBehavior = DateFormatter.Behavior.default
                            let testVar = f.date(from: (response?.optedInDatetime)!)
                            
                            if let tvar = testVar{
                                start = f.string(from: tvar) as NSString
                            }
                            End = f.string(from: today1) as NSString
                            let startDate = f.date(from: start as String)
                            let endDate = f.date(from: End as String)
                            
                            if (startDate != nil && endDate != nil) {
                                let gregorianCalendar = Calendar(identifier: Calendar.Identifier.gregorian)
                                let datecomponenets = (gregorianCalendar as NSCalendar).components(.minute, from: startDate!, to: endDate!, options:[])
                                let minuteCount = datecomponenets.minute
                                if (Double(minuteCount!)) <= Double(AppSettings.shared().autoSurveyTimeDuration())
                                {
                                    let currentview:UIViewController = (self.navigationController?.visibleViewController)!
                                    
                                    if(currentview.isKind(of:Home.self) )
                                    {
                                        let value1:NSDictionary = response!.surveyDetailsArray as NSDictionary
                                        let surveyExpPage = self.storyboard!.instantiateViewController(withIdentifier: "Survey_Experience_Page") as! SurveyExperiencePage
                                        surveyExpPage.SurveyQuestionsDetailsString = value1;
                                        surveyExpPage.rootViewForSurveyPage = "SignedIn";
                                        surveyExpPage.survayCode = surveyCode;
                                        surveyExpPage.contextCodeValue = condextcodeString
                                        
                                        self.navigationController!.pushViewController(surveyExpPage, animated: true)
                                        UserDefaults.standard.set(true, forKey: "ViewControllerName")
                                    }
                                    //self.navigationController!.pushViewController(surveyExpPage, animated: true)
                                }
                            }*/
                        }
                        
                        func onErrorSurvey(_ error: Error?) -> (){
                            print(error as Any)
                        }
                        
                        let currentAccount:PXStoredAccount = PaytronixAppDelegate.currentAccount()
                        if(hasCards()){
                            if(currentAccount.username != nil){
                                let surveyService =  PaytronixAppDelegate.api().directAPI.surveyDetailsServiceFunction
                                surveyService?.getSurveyDetails(forUsername: currentAccount.username, merchantId:"\((Int)(AppSettings.shared().merchantID()))", client_id: AppSettings.shared().integrationIdentifier().identifier, access_token: currentAccount.oauthAuthentication.accessToken, code: condextcodeString, authentication: currentAccount.oauthAuthentication, onSuccess: onSuccessSurvey, onError:onErrorSurvey)
                            }
                        }
                    }
                }
            }
        }
        
        
        func onError(_ error: Error?) -> ()
        {
            
        }
        
        
        let currentAccount:PXStoredAccount? = PaytronixAppDelegate.currentAccount()
        if(hasCards() && currentAccount != nil)
        {
            if(currentAccount?.username != nil)
            {
                let messageService =  PaytronixAppDelegate.api().directAPI.message
                messageService?.getMessagesForUsername(currentAccount?.username, authentication: currentAccount?.oauthAuthentication, onSuccess: onSuccess, onError: onError)
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    //MARK:- Private Methods
    func pageDesign() {
        //Setup New Dashboard UI Design
        setupDashboardUI(withTierFeatureEnabled: isTierFeatureEnabled)

        viewEarnRewardValue.layer.masksToBounds = true
        imageViewEarnRewardValue.layer.masksToBounds = true
        self.collectionDashBoardMenu.delegate = self
        self.collectionDashBoardMenu.dataSource = self
        self.backgroundImageView.image = AppImageAssets.appAssets.appBackgroundImage()
        self.collectionDashBoardMenu.register(UINib.init(nibName: "OLOCellHomeMenu", bundle: nil), forCellWithReuseIdentifier: "OLOCellHomeMenu")
        /*rewardMinimum = OloValues.valueDashBoardRewardMinimum()
         rewardMaximum = OloValues.valueDashBoardRewardMaximum()*/
        rewardMinimum = 0
        rewardMaximum = Int(HomeScreenSettings.shared().maxSpend())
        if rewardMinimum+1 >= rewardMaximum {
            rewardMinimum = 0
            rewardMaximum = 100
        }
        rewardHalf = (rewardMaximum/2) + rewardMinimum
        self.labelRewardMinimumValue.text = "\(rewardMinimum)"
        self.labelRewardMaximumValue.text = "\(rewardMaximum)"
        self.labelRewardHalfValue.text = "\(rewardHalf)"
        self.showPercentageOfEarnPoint(0, percentage: 0)
        //Font Color
        let arrayLabel:[UILabel] = [labelRewardMinimumValue,labelRewardHalfValue,labelRewardMaximumValue]
        for item in arrayLabel {
            item.font = UIFont.oloFontPrimary(14)
            item.textColor = UIColor.oloColorTextSecondary()
        }
        labelRewardTitle.font = UIFont.oloFontPrimary(17)
        labelRewardValue.font = UIFont.oloFontPrimary(17)
        if OloValues.valueShowRewards() {
            labelRewardTitle.textColor = UIColor.themeOneDashBoardRewardPointsColor()
            labelRewardValue.textColor = UIColor.themeOneDashBoardRewardTitleColor()
        }else {
            labelRewardTitle.textColor = UIColor.themeOneDashBoardRewardTitleColor()
            labelRewardValue.textColor = UIColor.themeOneDashBoardRewardPointsColor()
        }
        if OloValues.valueRewardsProgressValuesHide() {
            layoutHeightRewardProgressValues.constant = 0
            viewRewardsProgressValues.isHidden = true
        }
        if OloValues.valueIsRewardsProgressBarHide() {
            layoutHeightRewardProgressBar.constant = 0
            viewEarnRewardBG.isHidden = true
            layoutHeightRewardProgressValues.constant = 0
            viewRewardsProgressValues.isHidden = true
        }
    }
    
    override func segueToMessageListPage(_ sender: UIButton) {
        if let otoMessageList = APPSHARE.otoMessageList{
            self.navigationController?.pushViewController(otoMessageList, animated: true)
        }
    }
    
    func reloadPage()
    {
        arrayMenus = []
        
        let menuItems = isTierFeatureEnabled ? OloValues.valueDashBoardTierEnabledMenuList() : OloValues.valueDashBoardMenuList()
        for item in menuItems {
            if arrayMenus.count == 6 { // only first six configured items should display
                break
            }
            var title:String?
            var icon:String?
            var type:OloMenuHomeType? = .none
            var shouldUseOlo:Bool?
            var browserTitle:String?
            var shouldUseMultipleSSO:Bool?
            var ssoIndex:Int?
            var shouldUseThirdPartySSO:Bool?
            var shouldUseSSO:Bool?
            var url:String?
            
            if  let valueOftitle = item["Title"] as? String{
                title = valueOftitle
            }
            if  let valueOfType = item["Type"] as? String{
                if let theType = OloMenuHomeType.init(rawValue: valueOfType){
                    type = theType
                }
            }
            if  let valueOfIcon = item["Image"] as? String{
                icon = valueOfIcon
            }
            if let valueOfUrl = item["URL"] as? String{
                url = valueOfUrl
            }
            
            if  let valueOfShouldUseOlo = item["ShouldUseOLO"] as? Bool{
                shouldUseOlo = valueOfShouldUseOlo
            }
            if  let valueOfBrowserTitle = item["BrowserTitle"] as? String{
                browserTitle = valueOfBrowserTitle
            }
            if  let valueOfShouldUseMultipleSSO = item["ShouldUseMultipleSSO"] as? Bool{
                shouldUseMultipleSSO = valueOfShouldUseMultipleSSO
            }
            if  let valueOfssoIndex = item["SSOIndex"] as? Int{
                ssoIndex = valueOfssoIndex
            }
            if  let valueOfShouldUseThirdPartySSO = item["ShouldUseThirdPartySSO"] as? Bool{
                shouldUseThirdPartySSO = valueOfShouldUseThirdPartySSO
            }
            if  let valueOfShouldUseSSO = item["ShouldUseSSO"] as? Bool{
                shouldUseSSO = valueOfShouldUseSSO
            }
            var menu: ModelOloHomeMenu?
            if title != nil && icon != nil && type != nil{
                if shouldUseOlo != nil && browserTitle != nil && shouldUseMultipleSSO != nil && ssoIndex != nil && shouldUseThirdPartySSO != nil && shouldUseSSO != nil && url != nil{
                    menu = ModelOloHomeMenu.init(title: title!, image: icon!, url: url!, type: type!, shouldUseOlo: shouldUseOlo, browserTitle: browserTitle, shouldUseMultipleSSO: shouldUseMultipleSSO, ssoIndex: ssoIndex, shouldUseThirdPartySSO: shouldUseThirdPartySSO, shouldUseSSO: shouldUseSSO)
                }else if url != nil{
                    menu = ModelOloHomeMenu.init(title: title!, image: icon!, url: url!, type: type!)
                }else{
                    menu = ModelOloHomeMenu.init(title: title!, image: icon!, url: "", type: type!)
                }
            }
            //Accessibility
            if  let AccessbilityVoiceOverTitle = item["AccessbilityVoiceOverTitle"] as? String {
                menu?.AccessbilityVoiceOverTitle = AccessbilityVoiceOverTitle
            }
            if  let AccessbilityVoiceOverHint = item["AccessbilityVoiceOverHint"] as? String {
                menu?.AccessbilityVoiceOverHint = AccessbilityVoiceOverHint
            }
            if let menuTemp = menu {
                arrayMenus.append(menuTemp)
            }
        }
        if arrayMenus.count == 0{
            arrayMenus.append(ModelOloHomeMenu.init(title: "LOCATION LIST", image: "iconOloMenuLocation", url: "", type: .nearby))
            arrayMenus.append(ModelOloHomeMenu.init(title: "CHECKIN", image: "iconOloMenuCheckin", url: "", type: .checkin))
            arrayMenus.append(ModelOloHomeMenu.init(title: "TRANSACTION HISTORY", image: "iconOloMenuRecent", url: "", type: .nearby))
            arrayMenus.append(ModelOloHomeMenu.init(title: "MY ACCOUNT", image: "iconOloSideMyAccount", url: "", type: .nearby))
            arrayMenus.append(ModelOloHomeMenu.init(title: "REFER-A-FRIEND", image: "iconOloSideReferFriend", url: "", type: .nearby))
            arrayMenus.append(ModelOloHomeMenu.init(title: "REWARD YOURSELF", image: "iconOloMenuReward", url: "", type: .nearby))
        }
        self.perform(#selector(reloadCollection), with: nil, afterDelay: 0.2)
    }
    
    
    @objc func reloadCollection() {
        self.collectionDashBoardMenu.reloadData()
        if isTierFeatureEnabled {
            self.collectionDashBoardMenu.backgroundColor = UIColor.clear
        }
    }
    //MARK:- Delegate
    //MARK: UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrayMenus.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if isTierFeatureEnabled {
            //Setup Dashboard Menu cell when Tier feature Enabled
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "OLODashboardMenuCell", for: indexPath) as! OLODashboardMenuCell
            cell.delegate = self
            cell.tag = indexPath.row
            cell.setValues(modelOloMenu: arrayMenus[indexPath.row], index: indexPath.row, totalMenuCount: arrayMenus.count, indexPath: indexPath)
            return cell
        } else {
            //Setup Dashboard Menu cell when Tier feature Disabled
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "OLOCellHomeMenu", for: indexPath) as! OLOCellHomeMenu
            cell.delegate = self
            //        let currentStatus = APPSHARE.authorizationStatus
            //        if (currentStatus == .denied) {
            //            self.isCheckinEnabled  = false
            //        }
            if(self.isCheckinEnabled && self.arrayMenus[indexPath.row].type == .checkin && self.ExpirationText.count > 0) {
                cell.checkinViewBorder.isHidden = false
                cell.checkinValidityLabel.text = self.ExpirationText
                cell.checkinCodeLabel.text = _currentShortCardNumber
                cell.viewBorder.isHidden = true
            }else{
                cell.checkinViewBorder.isHidden = true
                cell.viewBorder.isHidden = false
            }
            cell.tag = indexPath.row
            cell.setValues(modelOloMenu: arrayMenus[indexPath.row])
            if imageMenuBG != nil {
                cell.imageViewHomeMenuBG.image = imageMenuBG
                if let imageMenuCheckin = UIImage.init(named: "iconOloMenuCheckinBG") {
                    cell.imageViewHomeMenuCheckinBG.image = imageMenuCheckin
                    cell.checkinViewBorder.backgroundColor = .clear
                }
            }
            return cell
        }
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if !isTierFeatureEnabled {
            if let cellTemp = cell as? OLOCellHomeMenu, imageMenuBG == nil {
                cellTemp.layoutIfNeeded()
                cellTemp.viewBorder.addDashLineBorderDefault()
            }
        }
    }
    //MARK: UICollectionViewDelegateFlowLayout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        if isTierFeatureEnabled {
            let width = (collectionView.frame.width) / 2
            let height = (collectionView.frame.height) / CGFloat(arrayMenus.count / 2)
            return CGSize(width: width, height: height)
        } else {
            return CGSize(width: collectionView.bounds.width/2, height: collectionView.bounds.height/3)
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return isTierFeatureEnabled ? 0 : 0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return isTierFeatureEnabled ? 0 : 0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    
    //MARK: OLOCellHomeMenuDelegate
    func OLOCellHomeMenu(index: Int) {
        if self.arrayMenus[index].type == .nearby {
            if APPSHARE.isNetworkReachable() {
                if ThemeOneSettingGlobal.isNewOrderFlowEnabled() {
                    self.segueToNewOrderFlowPage()
                }else{
                    self.segueToLocationListPage(from: false)
                }
            }
        }else if self.arrayMenus[index].type == .checkin {
            self.checkIn()
        }else if self.arrayMenus[index].type == .checkinandqr || self.arrayMenus[index].type == .checkinandbar {
            if APPSHARE.isNetworkReachable() {
                if  AppSettings.shared().isOloThemeOneEnabled()
                {
                    self.navigateToCheckinCodeScreen(type: (self.arrayMenus[index].type == .checkinandqr) ? "checkinandqr" : "checkinandbar")
                }
            }
        }else if self.arrayMenus[index].type == .favourites {
            if APPSHARE.isNetworkReachable() {
                if OnlineOrderClientAPI.isOnlineOrderEnabled{
                let segueTo = self.storyboard?.instantiateViewController(withIdentifier: "OLOFavouritesList") as! OLOFavouritesList
                self.navigationController?.pushViewController(segueTo, animated: true)
                }
            }
        }else if self.arrayMenus[index].type == .basket {
            if APPSHARE.isNetworkReachable() {
                if OnlineOrderClientAPI.isOnlineOrderEnabled{
                if AppDetails.shared.basketModel.isBasketStatus {
                    self.segueToBasket(isBackEnable: true, isFromHomePage: true)
                }else {
                    if OloValues.valueIsEmptyBasketToLocationScreen() {
                        self.segueToLocationListPage(from: false)
                    }else {
                        self.segueToBasket(isBackEnable: true, isFromHomePage: true)
                    }
                }
                }
            }
        }else if self.arrayMenus[index].type == .recentOrder {
            if APPSHARE.isNetworkReachable() {
                 if OnlineOrderClientAPI.isOnlineOrderEnabled{
                let oloRecentOrdersPage = self.storyboard?.instantiateViewController(withIdentifier: "OloRecentOrdersViewController") as! OloRecentOrdersViewController
                self.navigationController?.pushViewController(oloRecentOrdersPage, animated: true)
                }
            }
            
        }else if self.arrayMenus[index].type == .reward {
            if APPSHARE.isNetworkReachable() {
                if OnlineOrderClientAPI.isOnlineOrderEnabled{
                    let rewardPage = self.storyboard?.instantiateViewController(withIdentifier: "OLORewardsAnimationViewController") as! OLORewardsAnimationViewController
                    self.navigationController?.pushViewController(rewardPage, animated: true)
                }
            }
        }else if self.arrayMenus[index].type == .rewardYourself {
            if APPSHARE.isNetworkReachable() {
                if AppSettings.shared().isOloThemeOneEnabled(){
                    let storyborad:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
                    if let rewardController = storyborad.instantiateViewController(withIdentifier: "OTO_Reward_Yourself") as? OTORewardYourself{
                        self.navigationController?.pushViewController(rewardController, animated: true)
                    }
                }else{
                    let storyborad:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
                    if let rewardController = storyborad.instantiateViewController(withIdentifier: "RewardViewController") as? RewardViewController{
                        self.navigationController?.pushViewController(rewardController, animated: true)
                    }
                }
            }
        }else if self.arrayMenus[index].type == .transactionhistory {
            if APPSHARE.isNetworkReachable() {
                if AppSettings.shared().isOloThemeOneEnabled(){
                    let storyborad:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
                    if let switchObject = storyborad.instantiateViewController(withIdentifier: "Transaction_History_ViewController") as? TransactionHistoryViewController{
                        self.navigationController?.pushViewController(switchObject, animated: true)
                    }
                }
            }
        }else if self.arrayMenus[index].type == .myaccount {
            if APPSHARE.isNetworkReachable() {
                if AppSettings.shared().isOloThemeOneEnabled(){
                    let storyborad:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
                    if let rewardController = storyborad.instantiateViewController(withIdentifier: "OTOMyAccount") as? OTOMyAccount{
                        self.navigationController?.pushViewController(rewardController, animated: true)
                    }
                }
                else
                {
                       let appDelegate = UIApplication.shared.delegate as! PaytronixAppDelegate
                        appDelegate.goToMyAccount()
                    
                }
            }
        }else if self.arrayMenus[index].type == .cardsettings {
            if APPSHARE.isNetworkReachable() {
                if  AppSettings.shared().isOloThemeOneEnabled()
                {
                    let storyBoard = UIStoryboard(name: "ThemeOneScreen", bundle: nil)
                    if let cardSettingsObject = storyBoard.instantiateViewController(withIdentifier: "CardSettings") as? CardSettings{
                        self.navigationController?.pushViewController(cardSettingsObject, animated: true)
                    }
                }
            }
        }else if self.arrayMenus[index].type == .locationsettings {
            if APPSHARE.isNetworkReachable() {
                if  AppSettings.shared().isOloThemeOneEnabled()
                {
                    let storyBoard = UIStoryboard(name: "ThemeOneScreen", bundle: nil)
                    if let locationSettingsObject = storyBoard.instantiateViewController(withIdentifier: "LocationSettingsViewController") as? LocationSettingsViewController{
                        self.navigationController?.pushViewController(locationSettingsObject, animated: true)
                    }
                }
                else
                {
                    APPSHARE.isFromNewThemeDashboard = true
                    let storyborad:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
                    if let loctionController = storyborad.instantiateViewController(withIdentifier: "Region_Monitoring_Settings") as? RegionMonitoringSettings{
                        self.navigationController?.pushViewController(loctionController, animated: true)
                    }
                }
            }
        }else if self.arrayMenus[index].type == .security {
            if APPSHARE.isNetworkReachable() {
                if  AppSettings.shared().isOloThemeOneEnabled()
                {
                    let storyBoard = UIStoryboard(name: "ThemeOneScreen", bundle: nil)
                    if let securityObject = storyBoard.instantiateViewController(withIdentifier: "Security") as? Security{
                        self.navigationController?.pushViewController(securityObject, animated: true)
                    }
                }
            }
        }else if self.arrayMenus[index].type == .referafriend {
            /*if APPSHARE.isNetworkReachable() {
                
                if  AppSettings.shared().isOloThemeOneEnabled()
                {
                    let storyborad:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
                    if let referController = storyborad.instantiateViewController(withIdentifier: "OTOReferFriendViewController") as? OTOReferFriendViewController{
                        self.navigationController?.pushViewController(referController, animated: true)
                    }
                }
                else
                {
                    let storyborad:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
                    if let referController = storyborad.instantiateViewController(withIdentifier: "Refer_View_Controller") as? Refer{
                        self.navigationController?.pushViewController(referController, animated: true)
                    }
                }
                
            }*/
        }else if self.arrayMenus[index].type == .ExternalBrowser {
            if APPSHARE.isNetworkReachable() {
                if self.arrayMenus[index].url.count > 0{
                    UIApplication.shared.openURL(URL.init(string: self.arrayMenus[index].url)!)
                }
            }
        }else if self.arrayMenus[index].type == .InternalBrowser {
            if APPSHARE.isNetworkReachable() {
               
                    //Added code for [APPL-53444] Branded iPhone app : App should be able to configure both SSO and web URL link in dashboard for YesWay app[Starts]
                    let appDelegate = UIApplication.shared.delegate as! PaytronixAppDelegate
                    appDelegate.dashboardIndex = Int32(index)
                    //Added code for [APPL-53444] Branded iPhone app : App should be able to configure both SSO and web URL link in dashboard for YesWay app[Ends]
                    self.internalBrowserAction(index: index)
            
            }
        }else if self.arrayMenus[index].type == .recharge {
            if APPSHARE.isNetworkReachable() {
                if(AppSettings.shared().isRechargeEnabled())
                {
                    self.startRecharge()
                }

            }
        }else if self.arrayMenus[index].type == .editAccount {
            if APPSHARE.isNetworkReachable() {
                    self.appDelegate.isRechargeClass = false
                    self.parent?.navigationItem.title = ""
                    EditAccount.startRegistration(onNavController: self.navigationController, currentView: self.view, delegate: self.delegate, storedAccount: self.appDelegate.currentAccount, animated: true)

            }
        }else if self.arrayMenus[index].type == .switchAccount {
            if APPSHARE.isNetworkReachable() {
                if  AppSettings.shared().isOloThemeOneEnabled()
                {
                    let storyBoard = UIStoryboard(name: "Main", bundle: nil)
                    if let switchObject = storyBoard.instantiateViewController(withIdentifier: "Switch_Account_ViewController") as? SwitchAccount{
                        self.navigationController?.pushViewController(switchObject, animated: true)
                    }
                }
                else
                {
                     self.appDelegate.myAccount.switch()
                }
            }
        }else if self.arrayMenus[index].type == .logout {
            if AppSettings.shared().isOloThemeOneEnabled(){
                
                self.showAlert(title: "", description: OloDisplayText.textAlertWantToLogout(), rightButton: "YES", leftButton: "NO", complition: { (index) in
                    if index {
                        DispatchQueue.main.async {
                            APPSHARE.window?.isUserInteractionEnabled = false
                            APPSHARE.removeAllAccount()
                            UserDefaults.standard.set(nil, forKey: "ContactNumber")
                            UserDefaults.standard.set(false, forKey: "isFetchedContactDetails")
                            UserDefaults.standard.set(false, forKey: "isFacebookUser")
                            UserDefaults.standard.set(nil, forKey: "facebookImageString")
                            AppDetails.shared.logoutFromAccount(true)
                            APPSHARE.currentAccount = nil
                            APPSHARE.facebookValues.removeAllObjects()
                            
                            // Loading guest url
                            NotificationCenter.default.post(name: NSNotification.Name.kdisableQuickActionMenuOnRemove, object: nil)
                            let appDelegate = UIApplication.shared.delegate as! PaytronixAppDelegate
                            appDelegate.loadGuestOLOURL()
                            UserDefaults.standard.set(nil, forKey: "emailRecipients")
                            
                            //Reset touch ID or Face ID associate status
                            if TouchIdOrFaceIdManager.shared.checkAppConfiguration(){
                                // Reset user associate Touch ID or Face ID feature to show in Dashboard screen
                                TouchIdOrFaceIdManager.shared.userNotAssociatedTouchIdOrFaceIdOnce()
                            }
                        }
                    }
                })
            }else{
                self.logoutFromDevice()
            }
            
        }else if self.arrayMenus[index].type == .message {
            if APPSHARE.isNetworkReachable() {
                if  AppSettings.shared().isOloThemeOneEnabled()
                {
                    APPSHARE.isFromNewThemeDashboard = true
                    let storyBoard = UIStoryboard(name: "Main", bundle: nil)
                    if let switchObject = storyBoard.instantiateViewController(withIdentifier: "OTOMessageList") as? OTOMessageList{
                        self.navigationController?.pushViewController(switchObject, animated: true)
                    }
                }
                else
                {
                        APPSHARE.isFromNewThemeDashboard = true
                     self.appDelegate.showMessages()
                }
            }
        }else if self.arrayMenus[index].type == .popdeem{
            if APPSHARE.isNetworkReachable() {
                if(AppSettings.shared().isPopdeemEnabled()) {
                 appDelegate.isFromNewThemeDashboard = true
                let storyborad:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
                if let loctionController = storyborad.instantiateViewController(withIdentifier: "Popdeem_Controller") as? PopdeemController{
                    self.navigationController?.pushViewController(loctionController, animated: true)
                }
                }
            }
        }
        else {
            self.alertUnderDevelopment()
        }
    }
    
    @IBAction func orderNowDidPress(_ sender: UIButton) {
        if APPSHARE.isNetworkReachable() {
            if ThemeOneSettingGlobal.isNewOrderFlowEnabled() {
                VWOManager.setVWOGoalForOrderNowPress()
                self.segueToNewOrderFlowPage()
            }else{
                self.segueToLocationListPage(from: false)
            }
        }
    }

    @IBAction func benefitsButtonDidPress(_ sender: Any) {
        //Display benefits ViewController
        VWOManager.setVWOGoalForBenefitsPress()
        let storyBoard = UIStoryboard(name: "NativeOlo", bundle: nil)
        if let benefitsVC = storyBoard.instantiateViewController(withIdentifier: "kTierBenefitsViewController") as? TierBenefitsViewController{
            self.showDimView()
            benefitsVC.tierLevels = updatedTiersBasedOnActive(withTierLevels: self.tierLevels)
            benefitsVC.view.frame = CGRect.init(x: benefitsVC.view.frame.origin.x, y: UIScreen.main.bounds.height, width: benefitsVC.view.frame.size.width, height: UIScreen.main.bounds.height * 0.60)
            UIView.animate(withDuration: 0.3, delay: 0.0, options: .curveEaseIn, animations: {
                benefitsVC.view.frame = CGRect.init(x: benefitsVC.view.frame.origin.x, y: UIScreen.main.bounds.height - (UIScreen.main.bounds.height * 0.60), width: benefitsVC.view.frame.size.width, height: UIScreen.main.bounds.height * 0.60)
            }, completion: { _ in
            })
            UIApplication.shared.keyWindow?.rootViewController?.view.addSubview(benefitsVC.view)
            UIApplication.shared.keyWindow?.rootViewController?.addChild(benefitsVC)
        }
    }
    
    func startRecharge() {
        self.appDelegate.isRechargeClass = true
        let payconfigSuccess: ((_ response: PXPaymentConfig?) -> Void)? = { response in
            self.hideHud()
            let storyborad:UIStoryboard = UIStoryboard.init(name: "ThemeOneScreen", bundle: nil)
            if let rechargeController = storyborad.instantiateViewController(withIdentifier: "ThemeOneRecharge") as? ThemeOneRecharge{
                self.navigationController?.pushViewController(rechargeController, animated: true)
            }
        }
        let payconfigError: ((_ error: Error?) -> Void)? = { error in
            self.hideHud()
            let storyborad:UIStoryboard = UIStoryboard.init(name: "ThemeOneScreen", bundle: nil)
            if let rechargeController = storyborad.instantiateViewController(withIdentifier: "ThemeOneRecharge") as? ThemeOneRecharge{
                self.navigationController?.pushViewController(rechargeController, animated: true)
            }
        }
        
        self.startRecharge(withSuccess: payconfigSuccess!, error: payconfigError!)
    }
    
    func startRecharge(withSuccess onSuccess: @escaping (_ response: PXPaymentConfig?) -> Void, error onError: @escaping (_ error: Error?) -> Void) {
        self.showHudWithMessage("Just a moment...")
        
        let paymentService: PXPaymentService? = PaytronixAppDelegate.api().directAPI.payment
        let currentAccount: PXStoredAccount? = PaytronixAppDelegate.currentAccount()
        
        let userinfoResult: ((_ userInformation: PXUserInformation?, _ error: Error?) -> Void)? = { userInformation, error in
            
            if (userInformation != nil && userInformation?.fields.email == nil) {
                self.hideHud()
                if AppSettings.shared().isSignInRefreshEnable() || AppSettings.shared().isOloThemeOneEnabled(){
                    self.showAlert(title: "No email found", description: "Please enter your email address here", rightButton: "OK", leftButton: nil, complition: { status in
                    })
                } else {
                    AlertView.show("No email found", body: "Please enter your email address here")
                }
                self.appDelegate.isRechargeClass = false
                EditAccount.startRegistration(onNavController: self.navigationController, currentView: self.view, delegate: self.delegate, storedAccount: self.appDelegate.currentAccount, animated: true)
                /*if (self.parent?.parent is UITabBarController) {
                 //* Accessed via Gear Menu on My Account page
                 //editAccount()
                 } else {
                 //* Accessed via Side Drawer
                 var drawerController: MMDrawerController? = self.appDelegate.sideDrawer.mm_drawerController
                 //editAccount(from: drawerController)
                 }*/*/*/
                return
            }else if (userInformation != nil && !(userInformation?.fields.isEmailVerified)!) {
                self.hideHud()
                let message:String = "You must verify your email address before continuing."
                self.showAlert(title: "Email not verified", description: message, rightButton: "Send Email", leftButton: "Don't Send", complition: { sendEmail in
                    if sendEmail {
                        if currentAccount?.username == nil {
                            self.showAlert(title: "Account not Registered", description: "You need to register your card before sending a verification email", rightButton: "OK", leftButton: nil, complition: { status in
                            })
                            return
                        }
                        
                        print("Sending verification email")
                        self.showHudWithMessage("Sending Email")
                        
                        let success: ((_ response: PXEmailResponse?) -> Void)? = { response in
                            self.hideHud()
                            if let anEmail = response?.email {
                                self.showAlert(title: "A verification email was sent to \(anEmail)", description: nil, rightButton: "OK", leftButton: nil, complition: { status in
                                    if status {
                                        self.appDelegate.sideDrawer.mm_drawerController.closeDrawer(animated: true, completion: nil)
                                    }
                                })
                            }
                        }
                        
                        let error: ((_ error: Error?) -> Void)? = { error in
                            self.hideHud()
                            var errorCode:String = ""
                            if let responseBody = (error! as NSError).userInfo["responseBody"] {
                                if let errCode = responseBody as? NSDictionary{
                                    if let errCodeStr = errCode["errorCode"] as? String{
                                        errorCode = errCodeStr
                                    }
                                }
                            }
                            
                            if (errorCode == "authorization.insufficient_scope") {
                                let bodyFormat = "This will be fixed by relogging into your account. For reference your username is %@. Would you like to signout?"
                                if let anUsername = currentAccount?.username {
                                    self.showAlert(title: "Permissions Error", description: String(format: bodyFormat, anUsername), rightButton: "Manage accounts", leftButton: "Later", complition: { manageAccounts in
                                        if manageAccounts {
                                            self.appDelegate.myAccount.switch()
                                        }
                                    })
                                }
                            } else {
                                if AppSettings.shared().isSignInRefreshEnable() {
                                    self.showAlert(title: "Oops", description: "An error occurred: \(error?.localizedDescription ?? "")", rightButton: "OK", leftButton: nil, complition: { status in
                                    })
                                } else {
                                    AlertView.show("Oops", body: "An error occurred: \(error?.localizedDescription ?? "")")
                                }
                            }
                        }
                        
                        let enrollmentService: PXEnrollmentService? = PaytronixAppDelegate.api().directAPI.enrollment
                        enrollmentService?.sendVerificationEmail(toUsername: currentAccount!.username, containingURL: nil, authentication: currentAccount!.oauthAuthentication, onSuccess: success, onError: error)
                        
                    }else{
                        self.appDelegate.sideDrawer.mm_drawerController.closeDrawer(animated: true, completion: nil)
                    }
                })
                return
            }else if (error != nil){
                print("Unable to get user information \(String(describing: error))")
            }
            
            paymentService?.paymentConfig(forCardTemplate: AppSettings.shared().cardTemplateCode() as NSNumber, authentication: nil, onSuccess: onSuccess, onError: onError)
        }
        currentAccount?.fetchUserInformation(userinfoResult)
    }
    
    
    func navigateToCheckinCodeScreen(type:String){
        let storyBoard = UIStoryboard(name: "ThemeOneScreen", bundle: nil)
        if let checkinQrObject = storyBoard.instantiateViewController(withIdentifier: "CheckinQrCode") as? CheckinQrCode{
            checkinQrObject.codeType = type
            checkinQrObject.checkIn()
            self.navigationController?.pushViewController(checkinQrObject, animated: true)
        }
    }
    
    func internalBrowserAction(index: Int){
        
        APPSHARE.isFromNewThemeDashboard = true
        //An SSO index of -1 signifies to Web Browser that this is a non SSO link coming from the side drawer
        let sideDrawerItem = self.arrayMenus[index]
        let selectedItem = WebBrowserModel(title: sideDrawerItem.title, image: sideDrawerItem.image, url: sideDrawerItem.url, type: sideDrawerItem.type, shouldUseOlo: sideDrawerItem.shouldUseOlo, browserTitle: sideDrawerItem.browserTitle, shouldUseMultipleSSO: sideDrawerItem.shouldUseMultipleSSO, ssoIndex: sideDrawerItem.ssoIndex, shouldUseThirdPartySSO: sideDrawerItem.shouldUseThirdPartySSO, shouldUseSSO: sideDrawerItem.shouldUseSSO, isBackButtonEnable: true)

        multiSSOSelectedIndexModel = selectedItem
        if sideDrawerItem.shouldUseMultipleSSO! && sideDrawerItem.shouldUseSSO!
        {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let navController: UIViewController = storyboard.instantiateViewController(withIdentifier: "OnlineOrder_View_Controller") as! OnlineOrder
            self.navigationController?.pushViewController(navController, animated: true)
        } else {
            let newBrowser:NewWebBrowser = NewWebBrowser()
            self.navigationController?.pushViewController(newBrowser, animated: true)
        }
    }
    
    //MARK:- Percentage
    func showPercentageOfEarnPoint(_ points:Double, percentage:Double) {
        let xPosition = (self.viewEarnRewardBG.bounds.width / 100) * CGFloat(percentage)
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseIn, animations: {
            self.layoutLeadingEarnRewardBlur.constant = CGFloat(xPosition)
        }, completion: nil)
        
        if OloValues.isCustomRewardTextFormatEnabled() {
            if Int(points) <= OloValues.customRewardClosestValue() - 1 {
                self.labelRewardTitle.text = ""
                self.labelRewardValue.text = OloDisplayText.customRewardInitialText()
            } else if OloValues.customRewardClosestValue() > 0 && Int(points) >= OloValues.customRewardClosestValue() && Int(points) < Int(HomeScreenSettings.shared().maxSpend())  {
                let rewardsTitle = OloDisplayText.customRewardClosestValueText()
                let listString = rewardsTitle.components(separatedBy: "{dividedByThemeColor}")
                if listString.count > 1 {
                    self.labelRewardTitle.text = ""
                    let rewardText = "\(listString[0])\(listString[1])"
                    self.labelRewardValue.text = rewardText
                } else {
                    self.labelRewardTitle.text = ""
                    self.labelRewardValue.text = rewardsTitle.replacingOccurrences(of: "{dividedByThemeColor}", with: "")
                }
            } else if Int(points) >= Int(HomeScreenSettings.shared().maxSpend()) {
                let rewardsTitle = OloDisplayText.customRewardEndValueText()
                let listString = rewardsTitle.components(separatedBy: "{dividedByThemeColor}")
                if listString.count > 1 {
                    self.labelRewardTitle.text = ""
                    let rewardText = "\(listString[0])\(listString[1])"
                    self.labelRewardValue.text = rewardText
                } else {
                    self.labelRewardTitle.text = ""
                    self.labelRewardValue.text = rewardsTitle.replacingOccurrences(of: "{dividedByThemeColor}", with: "")
                }
            }
        } else {
            if OloValues.showClosestRewardPoints() > 0 && Int(points) >= OloValues.showClosestRewardPoints() {
                //ALMOST THERE – {divided}{points} TO GO!
                if points > 0 {
                    let pointsValue = Int(HomeScreenSettings.shared().maxSpend()) - Int(points)
                    var rewardsTitle = OloDisplayText.textClosestRewardText()
                    let pointsText = pointsValue == 1 ? OloDisplayText.textPoint() : OloDisplayText.textPoints()
                    rewardsTitle = rewardsTitle.replacingOccurrences(of: "{points}", with: "\(pointsValue) \(pointsText)")
                    let listString = rewardsTitle.components(separatedBy: "{dividedByThemeColor}")
                    if listString.count > 1 {
                        self.labelRewardTitle.text = listString[0]
                        self.labelRewardValue.text = listString[1]
                    }else {
                        self.labelRewardTitle.text = rewardsTitle.replacingOccurrences(of: "{dividedByThemeColor}", with: "")
                        self.labelRewardValue.text = ""
                    }
                }else {
                    self.labelRewardTitle.text = OloDisplayText.textDashBoardCheckin()
                    self.labelRewardValue.text = " \(OloDisplayText.textDashBoardEarnReward())"
                }
            }else if OloValues.valueShowRewards() {
                //Balance points until next reward
                self.labelRewardValue.text = "\(OloDisplayText.textUntilYourNextReward())"
                if(points == (Double(HomeScreenSettings.shared().maxSpend()) - 1)){
                    self.labelRewardTitle.text = "\(Int(HomeScreenSettings.shared().maxSpend()) - Int(points)) \(OloDisplayText.textPoint()) "
                }else{
                    self.labelRewardTitle.text = "\(Int(HomeScreenSettings.shared().maxSpend()) - Int(points)) \(OloDisplayText.textPoints()) "
                }
            }else{
                let pointsText = points == 1 ? OloDisplayText.textPoint() : OloDisplayText.textPoints()
                if points > 0 {
                    self.labelRewardTitle.text = "\(OloDisplayText.textDashBoardCheckinEarn()) -"
                    self.labelRewardValue.text = " \(Int(points)) \(pointsText)"
                }else {
                    self.labelRewardTitle.text = OloDisplayText.textDashBoardCheckin()
                    self.labelRewardValue.text = " \(OloDisplayText.textDashBoardEarnReward())"
                }
            }
        }
    }
    
    func checkIn() {
        self.dashBoardViewObject.checkIn(with: self, controller: self)
        /*let account: PXStoredAccount? = PaytronixAppDelegate.currentAccount()
         if account == nil {
         AlertView.show(OloDisplayText.textOops(), body: OloDisplayText.textConditionCheckinSignin())
         return
         }
         if APPSHARE.isNetworkReachable() {
         //  PaytronixAppDelegate.showHud(withMessage: "Checking in, please wait...", for: self)
         APPSHARE.showHud(withMessage: "", for: self.view)
         let currentStatus = APPSHARE.authorizationStatus
         let isLocationServicesAuthorized = (currentStatus == .authorizedAlways) || (currentStatus == .authorizedWhenInUse)
         if isLocationServicesAuthorized {
         var location: PXStoreInformation? = nil
         if(APPSHARE.locationNearby != nil){
         if APPSHARE.locationNearby.count > 0 {
         if let firstLocation = APPSHARE.locationNearby[0] as? PXStoreInformation {
         location = firstLocation
         }
         checkinStoreCode = location?.code ?? ""
         account?.checkIn(atStoreCode: checkinStoreCode, delegate: self)
         }else {
         checkinStoreCode = "corp"
         account?.checkIn(atStoreCode: "corp", delegate: self)
         }
         }else{
         checkinStoreCode = "corp"
         account?.checkIn(atStoreCode: "corp", delegate: self)
         }
         }
         else {
         account?.checkIn(atStoreCode: "corp", delegate: self)
         }
         }*/
    }
    
    //MARK:- checkInSuccess
    func checkInSuccess(withShortCode shortCardNumber: String!, expiresAt expirationTime: Date!) {
        APPSHARE.hideHudForEmptyView()
        self.isCheckinEnabled = true
        _currentExpirationTime = expirationTime
        _currentShortCardNumber = shortCardNumber
        timerCheckIn = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.timerFireMethod), userInfo: nil, repeats: true)
        collectionDashBoardMenu.reloadData()
    }
    
    //MARK:- check
    func check(inLocalizedError error: Error!) {
        APPSHARE.hideHudForEmptyView()
        clearCheckin()
        self.alertMessage(OloDisplayText.textOops(), message: "\(OloDisplayText.textAlertFailedCheckin()) \(error.localizedDescription)", complition: nil)
    }
    
    //MARK:- checkedInTooManyTimes
    func checkedInTooManyTimes() {
        APPSHARE.hideHudForEmptyView()
        clearCheckin()
        AlertView.show(OloDisplayText.textOops(), body: AppSettings.shared().checkinTooManyTimes())
    }
    
    //MARK:- checkinServiceNotAvailable
    func checkinServiceNotAvailable() {
        APPSHARE.hideHudForEmptyView()
        self.alertMessage(OloDisplayText.textAlertCheckinNotActive())
        APPSHARE.hideHud(for: self.view)
    }
    //MARK:- alreadyChecked
    func alreadyChecked(in shortCardNumber: String, expiresAt expirationDate: Date) {
        APPSHARE.hideHudForEmptyView()
        _currentExpirationTime = expirationDate
        _currentShortCardNumber = shortCardNumber
        self.isCheckinEnabled = true
        if timerCheckIn == nil {
            timerCheckIn = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.timerFireMethod), userInfo: nil, repeats: true)
        }
    }
    @objc func shortCardExpiredNotification(_ notification: Notification?) {
        if APPSHARE.locationNearby != nil && APPSHARE.locationNearby.count > 0 {
            if let firstLocation = APPSHARE.locationNearby[0] as? PXStoreInformation {
                if notification?.userInfo != nil, firstLocation.code == notification?.userInfo!["storeCode"] as? String {
                    self.clearCheckin()
                }
            }
        }
    }
    //MARK:- timerFireMethod
    
    @objc func timerFireMethod(_ theTimer: Timer?) {
        if _currentShortCardNumber != nil && _currentExpirationTime != nil {
            self.isCheckinEnabled  = true
            let secondsLeft: TimeInterval = _currentExpirationTime!.timeIntervalSinceNow
            let minutesLeft = Double((secondsLeft / 60.0))
            if floor(minutesLeft) > 0 {
                self.ExpirationText = HomeScreenSettings.shared().checkinExpirationText().replacingOccurrences(of: "{remainingTime}", with: "\(Int(ceil(minutesLeft))) minutes")
                collectionDashBoardMenu.reloadData()
            } else if secondsLeft < 60 {
                if secondsLeft > 0 && secondsLeft >= 10 {
                    self.ExpirationText = HomeScreenSettings.shared().checkinExpirationText().replacingOccurrences(of: "{remainingTime}", with: "00:\(Int(secondsLeft)) seconds")
                    collectionDashBoardMenu.reloadData()
                } else if secondsLeft > 0 && secondsLeft < 10 {
                    self.ExpirationText = HomeScreenSettings.shared().checkinExpirationText().replacingOccurrences(of: "{remainingTime}", with: "00:0\(Int(secondsLeft)) seconds")
                    collectionDashBoardMenu.reloadData()
                } else {
                    clearCheckin()
                    
                }
            }
        } else {
            clearCheckin()
        }
    }
    func clearCheckin() {
        ExpirationText = ""
        if timerCheckIn != nil {
            timerCheckIn?.invalidate()
            timerCheckIn = nil
        }
        _currentExpirationTime = nil
        _currentShortCardNumber = nil
        self.isCheckinEnabled = false
        collectionDashBoardMenu.reloadData()
    }
    @objc func getCheckinDetails() {
        if APPSHARE.locationNearby != nil && APPSHARE.locationNearby.count > 0 {
            if let firstLocation = APPSHARE.locationNearby[0] as? PXStoreInformation, PaytronixAppDelegate.currentAccount() != nil {
                let shortCardNumber: PXShortCardNumber? = PaytronixAppDelegate.currentAccount().shortCardNumber(forStoreCode: firstLocation.code)
                if shortCardNumber != nil {
                    if Double((shortCardNumber?.expirationDate.timeIntervalSinceNow)!) < 0 {
                        PaytronixAppDelegate.currentAccount().expireShortCardNumber(forStoreCode: firstLocation.code)
                    }else {
                        print(shortCardNumber?.shortCardNumber as Any)
                        self.checkInSuccess(withShortCode: shortCardNumber?.shortCardNumber, expiresAt: shortCardNumber?.expirationDate)
                    }
                }
            }
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.hideCustomAlert()
        if ((AppSettings.shared().isOloThemeOneEnabled() || !self.hasCards()) &&
            (!OnlineOrderClientAPI.isOnlineOrderEnabled || !self.hasCards())){
            self.navigationController?.navigationBar.barTintColor = AppSettings.shared().barColor()
            self.navigationController?.navigationBar.isTranslucent = false
            self.navigationController?.navigationBar.isHidden = false
        }else{
            self.navigationController?.navigationBar.isTranslucent = true
            self.navigationController?.navigationBar.isHidden = false
        }
    }
    
    func showDimView(){
        self.dimView = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height))
        self.dimView.backgroundColor = UIColor.black
        self.dimView.tag = 999
        self.dimView.alpha = 0.5
        UIApplication.shared.keyWindow?.rootViewController?.view.addSubview(self.dimView)
        //UIApplication.shared.keyWindow?.addSubview(self.dimView)
        //self.view.addSubview(self.dimView)
    }
}

//MARK:- Tier Program setup
extension OloDashBoardViewController {
    private func setupDashboardUI(withTierFeatureEnabled tierEnabled: Bool) {
        if tierEnabled {
            viewEarnRewardBG.isHidden = true
            viewEarnRewardValue.isHidden = true
            viewEarnRewardEarnRewards.isHidden = true
            
            //Show Tier Container
            tierProgressContainerView.isHidden = false
            tierProgressContainerBottom.isActive = !tierProgressContainerView.isHidden
            pointsProgressTextBottom.isActive = tierProgressContainerView.isHidden
            orderNowButtonContainer.isHidden = false
            collectionViewLeadingSpace.constant = 20
            collectionViewTrailingSpace.constant = 20
            collectionViewBottomSpaceToOrderNow.isActive = true
            collectionViewBottomSpaceToSuperView.isActive = false
            
            //Tier Container
            tierShadowView.shadowView()
            tierImageContainer.layer.cornerRadius = tierShadowView.layer.cornerRadius
            tierImageContainer.layer.masksToBounds = true
            tierWrapperContainer.isHidden = true

            //Tier Image
            tierImageView.contentMode = .scaleAspectFill
            
            //Tier Wrapper
            tierLevelLabel.font = UIFont.oloFontSecondaryBold(17)
            tierLevelLabel.textColor = AppSettings.shared()?.highContrastColor() ?? .white
            tierLevelLabel.adjustsFontSizeToFitWidth = true
            
            //Benefits Button
            benefitsButton.titleLabel?.font = UIFont.oloFontPrimary(16)
            benefitsButton.setTitleColor(AppSettings.shared()?.highContrastColor() ?? .white, for: .normal)
            
            var benefitsButtonTitle = VWOManager.isVWOEnabled ?  VWOManager.dashboardBenefitsButtonTitle : OloDisplayText.textTierBenefitButtonTitle()
            if benefitsButtonTitle.lowercased().contains("tier_level") {
                benefitsButtonTitle = OloDisplayText.textTierBenefitButtonTitle()
            }
            benefitsButton.setTitle(benefitsButtonTitle, for: .normal)
            benefitsButton.backgroundColor = UIColor.oloColorTheme()
            benefitsButton.layer.cornerRadius = 5.0
            benefitsButton.isExclusiveTouch = true
            
            //Setup New Dashboard Menu Cell
            self.collectionDashBoardMenu.register(UINib.init(nibName: "OLODashboardMenuCell", bundle: nil), forCellWithReuseIdentifier: "OLODashboardMenuCell")
            
            // Order Now Button Setup
            orderNowButtonContainer.backgroundColor = UIColor.oloColorTheme()
            orderNowArrowIconView.image = UIImage(named: "iconOrderNowRightArrow")?.withRenderingMode(.alwaysTemplate)
            orderNowArrowIconView.tintColor = AppSettings.shared()?.highContrastColor()
            
            let orderNowButtonTitle = VWOManager.isVWOEnabled ? VWOManager.dashboardOrderNowButtonTitle : OloDisplayText.textThemeOneOrderNowButtonTitle()
            orderNowButtonLabel.text = orderNowButtonTitle
            orderNowButtonLabel.font = UIFont.oloFontPrimary(20)
            orderNowButtonLabel.backgroundColor = UIColor.clear
            orderNowButtonLabel.textColor = AppSettings.shared().highContrastColor()
            orderNowButton.isExclusiveTouch = true
            //Accessbility
            orderNowButtonLabel.isAccessibilityElement = false
            accessibilityVoiceOver(type: orderNowButton, title: orderNowButtonTitle, hint: OloDisplayText.SignInSignUpHomeOrderNowButtonAccessibilityHint())
            //Accessibility
            tierImageView.isAccessibilityElement = true
            accessibilityVoiceOver(type: tierImageView, title: OloDisplayText.DashboardTierCardImage(), hint: "")
            
            //Add space around sticky footer for iPhone X series devices
            if isiPhoneXSeries {
                AppDetails.shared.addSpaceAroundFooterView(forView: orderNowButtonContainer, constraints: stickyFooterConstaintsArray)
            }
            
            //Fetch Configured Tier Levels
            tierLevels = OloValues.fetchTierLevels()

            loadTierData()
            
        } else {
            //Hide Tier Progress Container
            tierProgressContainerView.isHidden = true
            tierProgressContainerBottom.isActive = !tierProgressContainerView.isHidden
            pointsProgressTextBottom.isActive = tierProgressContainerView.isHidden
            orderNowButtonContainer.isHidden = true
            collectionViewLeadingSpace.constant = 0
            collectionViewTrailingSpace.constant = 0
            collectionViewBottomSpaceToOrderNow.isActive = false
            collectionViewBottomSpaceToSuperView.isActive = true
            collectionViewBottomSpaceToSuperView.constant = isiPhoneXSeries ? AppDetails.shared.deviceSafeAreaBottomHeight() - 10 : 0

        }
    }
    
    private func loadTierData() {
        //Inital Load Data
        tierImageView.image = UIImage(named: "no_tierimage")
        
        for tierLevel in self.tierLevels {
            let tierCode = AppSettings.shared()?.isProductionPointedBuild() ?? false ? tierLevel.productionTierCode : tierLevel.fujiTierCode
            if tierCode == currentUserTierCode {
                var benefitsButtonTitle = VWOManager.isVWOEnabled ?  VWOManager.dashboardBenefitsButtonTitle : OloDisplayText.textTierBenefitButtonTitle()
                if benefitsButtonTitle.lowercased().contains("tier_level") {
                    benefitsButtonTitle = benefitsButtonTitle.lowercased().replacingOccurrences(of: "tier_level", with: tierLevel.tierTitle).uppercased()
                    benefitsButton.setTitle(benefitsButtonTitle, for: .normal)
                }

                tierImageView.image = UIImage(named: tierLevel.tierImage)
            }
        }
        
        logoImageView.image = UIImage()//UIImage(named: "pfc_rewards_white")
        tierWrapperContainer.backgroundColor = UIColor.clear//UIColor.HexToColor(hexString: tierLevels[0].tierWrapperColor)
        tierLevelLabel.text = ""//tierLevels[0].tierTitle
    }
    
    //Update tier level active status based on user tier level
    private func updatedTiersBasedOnActive(withTierLevels: [TierLevel]) -> [TierLevel] {
        let currentTierLevel = self.tierLevels.filter{(AppSettings.shared()?.isProductionPointedBuild() ?? false ? $0.productionTierCode : $0.fujiTierCode) == currentUserTierCode}
        if self.tierLevels.count > 0 && currentTierLevel.count > 0 {
            let lastTierCode = AppSettings.shared()?.isProductionPointedBuild() ?? false ? self.tierLevels.last?.productionTierCode : self.tierLevels.last?.fujiTierCode
            let firstTierCode = AppSettings.shared()?.isProductionPointedBuild() ?? false ? self.tierLevels.first?.productionTierCode : self.tierLevels.first?.fujiTierCode
            if currentUserTierCode == lastTierCode {
                self.tierLevels = self.tierLevels.map({ (tierLevel: TierLevel) -> TierLevel in
                    var activeTierLevel = tierLevel
                    activeTierLevel.isActive = true
                    return activeTierLevel
                })
            } else if currentUserTierCode == firstTierCode {
                self.tierLevels[0].isActive = true
            } else {
                for (index, tierLevel) in self.tierLevels.enumerated() {
                    self.tierLevels[index].isActive = true
                    let tierCode = AppSettings.shared()?.isProductionPointedBuild() ?? false ? tierLevel.productionTierCode : tierLevel.fujiTierCode
                    if currentUserTierCode == tierCode {
                        break
                    }
                }
            }
        }
        return tierLevels
   }
}
//MAR:- Apple Sign-In alert popup
extension OloDashBoardViewController {
    func appleSignInLinkedAlert(complition: @escaping ((_ status: Bool) -> Void)) {
        if #available(iOS 13.0, *) {
            if !AppleSignIn.isPXSAssociatedToAS && AppleSignIn.isASAuthenticationSuccess {
                DispatchQueue.main.async {
                    if let hasCurrentAccount = self.appDelegate.currentAccount, let hasOauth = hasCurrentAccount.oauthAuthentication, let hasRefreshToken = hasOauth.refreshToken {
                        AppleSignIn.isPXSAssociatedToAS = true
                        AppleSignIn.refereshTockenPXS = hasRefreshToken
                        AppleSignIn.shared.updateRefereshTocken(tocken: hasRefreshToken)
                        if OloDisplayText.themeOneTouchIdOrFaceIdShowConfirmSuccessAlert() {
                            self.showAlert(title: OloDisplayText.ThemeOneAppleSignInLinkedMessageTitle(), description: OloDisplayText.ThemeOneAppleSignInLinkedMessageDescription(), rightButton: OloDisplayText.ThemeOneAppleSignInLinkedMessageButtonTitle(), leftButton: nil) { (status) in
                                complition(true)
                            }
                        }else {
                            complition(false)
                        }
                    }else {
                        complition(false)
                    }
                }
            }else {
                complition(false)
            }
        }else {
            complition(false)
        }
    }
}
//End Apple Sign-In
struct ModelOloHomeMenu {
    var title:String = ""
    var image:String = ""
    var url:String = ""
    var type:OloMenuHomeType = .none
    // for internel broweser SSO,OLO,MultiSSO
    var shouldUseOlo:Bool?
    var browserTitle:String?
    var shouldUseMultipleSSO:Bool?
    var ssoIndex:Int?
    var shouldUseThirdPartySSO:Bool?
    var shouldUseSSO:Bool?
    var AccessbilityVoiceOverTitle: String?
    var AccessbilityVoiceOverHint: String?
    
    init(title:String, image:String, url:String, type:OloMenuHomeType, shouldUseOlo:Bool? = nil, browserTitle:String? = nil, shouldUseMultipleSSO:Bool? = nil, ssoIndex:Int? = nil, shouldUseThirdPartySSO:Bool? = nil, shouldUseSSO:Bool? = nil){
        self.title = title
        self.image = image
        self.url = url
        self.type = type
        self.shouldUseOlo = shouldUseOlo
        self.browserTitle = browserTitle
        self.shouldUseMultipleSSO = shouldUseMultipleSSO
        self.ssoIndex = ssoIndex
        self.shouldUseThirdPartySSO = shouldUseThirdPartySSO
        self.shouldUseSSO = shouldUseSSO
    }
}
enum OloMenuHomeType:String {
    case none
    case nearby
    case checkin
    case checkinandqr
    case checkinandbar
    case recentOrder
    case favourites
    case basket
    case reward
    case transactionhistory
    case referafriend
    case myaccount
    case cardsettings
    case locationsettings
    case security
    case ExternalBrowser
    case InternalBrowser
    case recharge
    case editAccount
    case switchAccount
    case logout
    case message
    case popdeem
    case rewardYourself
}

